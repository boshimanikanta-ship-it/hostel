"""Structured data models for Hostel Maintenance Tracker."""

from dataclasses import asdict, dataclass, field
from typing import Optional


@dataclass
class ComplaintRecord:
    complaint_id: str
    student_name: str
    student_id: str
    hostel_name: str
    block_number: str
    room_number: str
    category: str
    description: str
    priority: str
    submission_date: str
    expected_resolution_date: str
    status: str = "Pending"
    assigned_staff: str = ""
    resolution_notes: str = ""
    in_progress_at: Optional[str] = None
    completed_at: Optional[str] = None
    created_at: str = ""
    updated_at: str = ""
    id: Optional[int] = None
    warning_level: str = field(default="Normal")
    warning_reasons: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class UserRecord:
    username: str
    full_name: str
    role: str
    email: str = ""
    department: str = "General Maintenance"
    is_active: bool = True
    created_at: str = ""
    id: Optional[int] = None

    def to_dict(self) -> dict:
        return asdict(self)
