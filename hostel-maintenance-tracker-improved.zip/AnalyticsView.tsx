import { useCallback, useEffect, useState } from 'react';
import { RotateCcw } from 'lucide-react';
import { apiRequest, ApiError } from '../api';
import { HOSTEL_OPTIONS, type AnalyticsSummary, type ThemeId } from '../types';
import {
  CategoryBarChart,
  MonthlyTrendsLineChart,
  PriorityDistributionChart,
  StatusDoughnutChart,
} from './Charts';

interface AnalyticsViewProps {
  token: string;
  themeId: ThemeId;
}

export function AnalyticsView({ token, themeId }: AnalyticsViewProps) {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [hostelName, setHostelName] = useState('');
  const [data, setData] = useState<AnalyticsSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');

  const loadAnalytics = useCallback(async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      const params = new URLSearchParams();
      if (startDate) params.set('start_date', startDate);
      if (endDate) params.set('end_date', endDate);
      if (hostelName) params.set('hostel_name', hostelName);
      params.set('scope', 'all');
      const res = await apiRequest<AnalyticsSummary>(`/api/analytics?${params.toString()}`, {
        token,
      });
      setData(res);
    } catch (err) {
      setErrorMsg(err instanceof ApiError ? err.message : 'Failed to compute analytics.');
    } finally {
      setLoading(false);
    }
  }, [token, startDate, endDate, hostelName]);

  useEffect(() => {
    loadAnalytics();
  }, [loadAnalytics]);

  return (
    <div className="space-y-6">
      {/* Date-Range & Hostel Filter Controls */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-lg font-bold text-slate-900">
            Analytics & Executive Summary
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time metrics calculated from SQLite records with interactive date-range filtering.
          </p>
        </div>

        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label htmlFor="an-start" className="block text-xs font-medium text-slate-600 mb-1">
              From Date
            </label>
            <input
              id="an-start"
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-mono text-slate-900"
            />
          </div>
          <div>
            <label htmlFor="an-end" className="block text-xs font-medium text-slate-600 mb-1">
              To Date
            </label>
            <input
              id="an-end"
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-mono text-slate-900"
            />
          </div>
          <div>
            <label htmlFor="an-hostel" className="block text-xs font-medium text-slate-600 mb-1">
              Hostel
            </label>
            <select
              id="an-hostel"
              value={hostelName}
              onChange={(e) => setHostelName(e.target.value)}
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs text-slate-900"
            >
              <option value="">All Hostels</option>
              {HOSTEL_OPTIONS.map((h) => (
                <option key={h} value={h}>
                  {h}
                </option>
              ))}
            </select>
          </div>
          {(startDate || endDate || hostelName) && (
            <button
              type="button"
              onClick={() => {
                setStartDate('');
                setEndDate('');
                setHostelName('');
              }}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Reset</span>
            </button>
          )}
        </div>
      </section>

      {errorMsg && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {errorMsg}
        </div>
      )}

      {loading || !data ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="h-72 bg-white border border-slate-200 rounded-xl animate-pulse" />
          <div className="h-72 bg-white border border-slate-200 rounded-xl animate-pulse" />
        </div>
      ) : (
        <>
          {/* Executive KPI Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
            {[
              { label: 'Total', value: data.total_complaints },
              { label: 'Pending', value: data.pending_complaints },
              { label: 'In Progress', value: data.in_progress_complaints },
              { label: 'Completed', value: data.completed_complaints },
              { label: 'Overdue', value: data.overdue_complaints },
              { label: 'Completion %', value: `${data.completion_percentage}%` },
              { label: 'Avg Resolution', value: `${data.average_resolution_days}d` },
            ].map((m) => (
              <div
                key={m.label}
                className="bg-white border border-slate-200 rounded-xl p-4"
              >
                <span className="text-xs text-slate-500 block">{m.label}</span>
                <span className="font-display text-2xl font-bold text-slate-900 tabular-nums mt-1 block">
                  {m.value}
                </span>
              </div>
            ))}
          </div>

          {/* 4 Chart.js Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <section className="bg-white border border-slate-200 rounded-xl p-5">
              <h2 className="font-display text-sm font-semibold text-slate-900 mb-4">
                Status Breakdown
              </h2>
              <StatusDoughnutChart breakdown={data.status_breakdown} themeId={themeId} />
            </section>

            <section className="bg-white border border-slate-200 rounded-xl p-5">
              <h2 className="font-display text-sm font-semibold text-slate-900 mb-4">
                Category-Wise Totals
              </h2>
              <CategoryBarChart breakdown={data.category_breakdown} themeId={themeId} />
            </section>

            <section className="bg-white border border-slate-200 rounded-xl p-5">
              <h2 className="font-display text-sm font-semibold text-slate-900 mb-4">
                Monthly Complaint Trends
              </h2>
              <MonthlyTrendsLineChart trends={data.monthly_trends} themeId={themeId} />
            </section>

            <section className="bg-white border border-slate-200 rounded-xl p-5">
              <h2 className="font-display text-sm font-semibold text-slate-900 mb-4">
                Priority-Wise Totals
              </h2>
              <PriorityDistributionChart breakdown={data.priority_breakdown} />
            </section>
          </div>

          {/* Quantitative Breakdown Tables */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="px-5 py-3.5 border-b border-slate-200">
                <h2 className="font-display text-sm font-semibold text-slate-900">
                  Category Performance Table
                </h2>
              </div>
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
                    <th className="py-2.5 px-4">Category</th>
                    <th className="py-2.5 px-4 text-right">Requests</th>
                    <th className="py-2.5 px-4 text-right">Share</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {Object.entries(data.category_breakdown).map(([cat, count]) => (
                    <tr key={cat}>
                      <td className="py-2.5 px-4 font-medium text-slate-800">{cat}</td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-900">
                        {count}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-500">
                        {data.total_complaints > 0
                          ? `${((count / data.total_complaints) * 100).toFixed(1)}%`
                          : '0.0%'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>

            <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="px-5 py-3.5 border-b border-slate-200">
                <h2 className="font-display text-sm font-semibold text-slate-900">
                  Hostel Residence Distribution
                </h2>
              </div>
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
                    <th className="py-2.5 px-4">Hostel Residence</th>
                    <th className="py-2.5 px-4 text-right">Requests</th>
                    <th className="py-2.5 px-4 text-right">Share</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {Object.entries(data.hostel_breakdown).map(([hostel, count]) => (
                    <tr key={hostel}>
                      <td className="py-2.5 px-4 font-medium text-slate-800">{hostel}</td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-900">
                        {count}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-500">
                        {data.total_complaints > 0
                          ? `${((count / data.total_complaints) * 100).toFixed(1)}%`
                          : '0.0%'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>
          </div>
        </>
      )}
    </div>
  );
}
