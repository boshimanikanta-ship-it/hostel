"""Multi-format report generator (CSV, JSON, Markdown, Plain-Text audit logs)."""

import json
from pathlib import Path
from typing import Any

from backend.analytics import compute_analytics
from backend.complaint_service import list_complaints
from backend.database import get_connection, utc_now_iso
from backend.import_export import export_complaints_csv
from config import EXPORTS_DIR


def generate_report_bundle(
    fmt: str,
    *,
    start_date: str = "",
    end_date: str = "",
    status: str = "",
    db_path: Path | None = None,
    save_to_disk: bool = False,
) -> tuple[str, str, str]:
    """Return (content, mime_type, filename) for csv | json | markdown | txt."""
    normalized_fmt = fmt.lower().strip()
    generated_at = utc_now_iso()
    analytics = compute_analytics(
        start_date=start_date, end_date=end_date, db_path=db_path
    )
    records = list_complaints(
        start_date=start_date,
        end_date=end_date,
        status=status,
        per_page=500,
        db_path=db_path,
    )["items"]

    stamp = generated_at[:10]
    if normalized_fmt == "csv":
        content = export_complaints_csv(records)
        mime = "text/csv; charset=utf-8"
        fname = f"hostel_maintenance_report_{stamp}.csv"
    elif normalized_fmt == "json":
        payload = {
            "report_generated_at": generated_at,
            "filters": {"start_date": start_date or None, "end_date": end_date or None, "status": status or None},
            "executive_summary": {
                "total_complaints": analytics["total_complaints"],
                "pending_complaints": analytics["pending_complaints"],
                "in_progress_complaints": analytics["in_progress_complaints"],
                "completed_complaints": analytics["completed_complaints"],
                "overdue_complaints": analytics["overdue_complaints"],
                "completion_percentage": analytics["completion_percentage"],
                "average_resolution_days": analytics["average_resolution_days"],
                "category_breakdown": analytics["category_breakdown"],
                "priority_breakdown": analytics["priority_breakdown"],
            },
            "records": records,
        }
        content = json.dumps(payload, indent=2)
        mime = "application/json; charset=utf-8"
        fname = f"hostel_maintenance_report_{stamp}.json"
    elif normalized_fmt in ("md", "markdown"):
        lines = [
            "# Hostel Maintenance Executive Report",
            "",
            f"- **Report Generated:** {generated_at}",
            f"- **Date Range:** {start_date or 'All'} to {end_date or 'Present'}",
            f"- **Total Complaints:** {analytics['total_complaints']}",
            f"- **Pending:** {analytics['pending_complaints']}",
            f"- **In Progress:** {analytics['in_progress_complaints']}",
            f"- **Completed:** {analytics['completed_complaints']} ({analytics['completion_percentage']}%)",
            f"- **Overdue:** {analytics['overdue_complaints']}",
            f"- **Average Resolution Time:** {analytics['average_resolution_days']} days",
            "",
            "## Category Breakdown",
            "",
            "| Category | Count |",
            "| --- | ---: |",
        ]
        for cat, count in analytics["category_breakdown"].items():
            lines.append(f"| {cat} | {count} |")

        lines.extend(
            [
                "",
                "## Priority Breakdown",
                "",
                "| Priority | Count |",
                "| --- | ---: |",
            ]
        )
        for pri, count in analytics["priority_breakdown"].items():
            lines.append(f"| {pri} | {count} |")

        lines.extend(
            [
                "",
                "## Maintenance Records",
                "",
                "| ID | Student | Hostel / Room | Category | Priority | Status | Warning | Expected |",
                "| --- | --- | --- | --- | --- | --- | --- | --- |",
            ]
        )
        for rec in records:
            lines.append(
                f"| {rec['complaint_id']} | {rec['student_name']} ({rec['student_id']}) | "
                f"{rec['hostel_name']} {rec['block_number']}-{rec['room_number']} | "
                f"{rec['category']} | {rec['priority']} | {rec['status']} | "
                f"{rec['warning_level']} | {rec['expected_resolution_date']} |"
            )

        content = "\n".join(lines) + "\n"
        mime = "text/markdown; charset=utf-8"
        fname = f"hostel_maintenance_report_{stamp}.md"
    elif normalized_fmt in ("txt", "text", "audit"):
        conn = get_connection(db_path)
        try:
            audit_rows = conn.execute(
                "SELECT * FROM audit_logs ORDER BY id DESC LIMIT 100"
            ).fetchall()
        finally:
            conn.close()

        lines = [
            "==========================================================================",
            "HOSTEL MAINTENANCE TRACKER — PLAIN-TEXT EXECUTIVE & AUDIT REPORT",
            "==========================================================================",
            f"Generated At       : {generated_at}",
            f"Date Filter        : {start_date or 'All'} -> {end_date or 'Present'}",
            f"Total Complaints   : {analytics['total_complaints']}",
            f"Pending            : {analytics['pending_complaints']}",
            f"In Progress        : {analytics['in_progress_complaints']}",
            f"Completed          : {analytics['completed_complaints']} ({analytics['completion_percentage']}%)",
            f"Overdue            : {analytics['overdue_complaints']}",
            f"Avg Resolution     : {analytics['average_resolution_days']} days",
            "",
            "CATEGORY BREAKDOWN:",
        ]
        for cat, count in analytics["category_breakdown"].items():
            lines.append(f"  - {cat:<16}: {count}")
        lines.append("")
        lines.append("PRIORITY BREAKDOWN:")
        for pri, count in analytics["priority_breakdown"].items():
            lines.append(f"  - {pri:<16}: {count}")
        lines.append("")
        lines.append("RELEVANT MAINTENANCE RECORDS:")
        lines.append("-" * 74)
        for rec in records:
            lines.append(
                f"[{rec['complaint_id']}] {rec['status']:<11} | {rec['priority']:<8} | "
                f"{rec['warning_level']:<18} | {rec['category']:<14} | "
                f"{rec['hostel_name']} {rec['block_number']}-{rec['room_number']} | "
                f"Due {rec['expected_resolution_date']} | {rec['student_name']}"
            )
        lines.append("")
        lines.append("RECENT SYSTEM AUDIT TRAIL:")
        lines.append("-" * 74)
        for a in audit_rows:
            lines.append(
                f"{a['created_at']} | {a['actor']:<14} | {a['action']:<18} | {a['target_id']} | {a['details']}"
            )
        content = "\n".join(lines) + "\n"
        mime = "text/plain; charset=utf-8"
        fname = f"hostel_audit_report_{stamp}.txt"
    else:
        raise ValueError(f"Unsupported report format: {fmt}")

    if save_to_disk:
        EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
        safe_fname = Path(fname).name
        target = (EXPORTS_DIR / safe_fname).resolve()
        if str(target).startswith(str(EXPORTS_DIR.resolve()) + "/"):
            target.write_text(content, encoding="utf-8")

    return content, mime, fname
