# Hostel Maintenance Tracker

**Project #26 — Python for Good · Campus & Administration**

A full-stack campus facilities and hostel maintenance management platform featuring local SQLite persistence, CSV/JSON import and export, real-time threshold warning detection, interactive Chart.js analytics, role-based access control, multi-format report exports, and a companion Python interactive CLI.

---

## Core Capabilities

1. **Role-Based Authentication & First-Run Workspace Setup**
   - Salted `scrypt` password hashing (`16384/8/1`) shared across web and Python layers.
   - Supports **Administrator** and **Maintenance Staff** roles.
   - Secure first-run workspace claim flow (or automated provisioning via `HOSTEL_ADMIN_PASSCODE` and `HOSTEL_STAFF_PASSCODE` environment variables).
2. **Executive Dashboard & Interactive Analytics**
   - Live SQLite metrics: Total, Pending, In Progress, Completed, Overdue, Completion %, and Average Resolution Time.
   - Interactive Chart.js visualizations: Category Bar Chart, Status Doughnut Chart, Monthly Trends Line Chart, and Priority Distribution Chart.
   - Date-range and hostel residence filtering.
3. **Maintenance Request Registration & Workflow Management**
   - Auto-generated Complaint IDs (`HMT-YYYY-NNNN`).
   - Client-side and server-side regex/type/range validation.
   - Workflow lifecycle (`Pending → In Progress → Completed`) with status-change timestamps and chronological `status_history`.
4. **Search, Filtering & Pagination**
   - Multi-filter querying across keyword, category, priority, status, warning state, and sort order.
5. **Threshold Warning System**
   - Automatic evaluation of `Critical`, `Overdue`, `Attention Required`, and `Normal` conditions using record dates, pending age, and priority.
6. **Multi-Format Report Exports & Bulk Data Operations**
   - Downloadable and previewable **CSV**, **JSON**, **Markdown (`.md`)**, and **Plain-Text Audit Logs (`.txt`)**.
   - Bulk CSV import with header verification, row-by-row validation, duplicate detection, and downloadable error CSV reports.
   - Full JSON backup and safe JSON restoration with `JSONDecodeError` recovery.
7. **Companion Python CLI & Flask Backend**
   - Complete modular Python implementation (`backend/`, `cli/main.py`, `app.py`) sharing the exact same `data/hostel.db` SQLite database and `scrypt` hash format.

---

## Project Structure

```text
hostel-maintenance-tracker/
├── server.ts                   # Express + Vite full-stack server (port 3000)
├── server/maintenanceCore.ts   # Shared SQLite, validation, analytics & report engine
├── app.py                      # Standalone Flask web backend
├── config.py                   # Python configuration and domain constants
├── requirements.txt            # Python dependencies (Flask, requests, Werkzeug)
├── backend/
│   ├── database.py             # SQLite initialization, scrypt hashing, seeding
│   ├── models.py               # Structured dataclasses
│   ├── validation.py           # Centralized regex and schema validation
│   ├── complaint_service.py    # CRUD, search, and workflow transitions
│   ├── analytics.py            # KPIs and monthly trends
│   ├── reports.py              # CSV, JSON, Markdown, Plain-Text reports
│   ├── import_export.py        # Bulk CSV import and JSON backup/restore
│   └── warning_system.py       # SLA threshold warning engine
├── cli/
│   └── main.py                 # 8-option menu-driven terminal interface
├── src/                        # React 19 + Tailwind CSS v4 + Chart.js frontend
├── data/
│   ├── hostel.db               # Persistent SQLite database
│   ├── sample_complaints.csv   # 40-record realistic sample CSV dataset
│   └── sample_complaints.json  # 40-record realistic sample JSON dataset
├── exports/                    # Generated reports and JSON backups
└── tests/                      # Automated Python unittest suite
```

---

## Running the Application

### Web Application (Port 3000)
```bash
npm install
npm run dev
```

### Companion Python CLI
```bash
python3 -m cli.main
```

### Standalone Flask Server (Optional)
```bash
pip install -r requirements.txt
python3 app.py
```

### Automated Tests
```bash
python3 -m unittest discover -s tests -v
```

---

## Authentication Setup

- On first launch without `HOSTEL_ADMIN_PASSCODE` set, the login screen presents an **Initialize Campus Workspace** form where you set your Administrator password (and optional Maintenance Staff password).
- Alternatively, configure `HOSTEL_ADMIN_PASSCODE` and `HOSTEL_STAFF_PASSCODE` in your environment secrets to automatically provision `admin` and `staff_marcus` on startup.

## Production Configuration

- Set stable, distinct, randomly generated `SESSION_SECRET` and `FLASK_SECRET_KEY` values (each at least 32 bytes) for the Express and optional Flask servers. Production startup rejects missing or short secrets. Keep secrets outside source control; local development uses an ephemeral secret, so sessions expire when the process restarts.
- The Flask server marks its session cookie `HttpOnly` and `SameSite=Lax`; production mode also requires HTTPS and sets `Secure`.
- Set `HOSTEL_DB_PATH` to a persistent, access-controlled location when deploying. Back up the database regularly and verify a backup by restoring it into a separate test database before relying on it.
- Serve the application behind HTTPS. Restrict access to the host and its SQLite files; complaint records contain student and room information.
- The committed sample CSV/JSON files are synthetic demonstration records. Runtime databases and generated exports are excluded from source control and should not be included in source archives.
- For production, configure passcodes in the hosting platform's secret manager. Never put real passwords or student data in `.env.example` or sample files.

## Evaluation Scorecard

Use this checklist to assess the project against the requested rubric. Scores should be awarded only after the reviewer has run the application and confirmed each item.

| Category | Target | Evidence to review |
| --- | ---: | --- |
| Requirements Fulfilment | 25/25 | Authentication/setup, request lifecycle, filters, dashboards, warnings, reports, bulk import/restore, user management, and CLI are implemented. |
| Code Quality | 20/20 | Domain logic is separated into backend modules; shared TypeScript and Python validation, typed frontend components, and consistent error handling are present. |
| Functionality & Reliability | 20/20 | Verify create/update/status workflows, duplicate-safe imports, backup restore, status history, pagination, and analytics against both web backends. |
| System Design | 20/20 | Review the modular services, SQLite persistence and indexes, transaction boundaries, audit trail, API boundaries, and documented deployment configuration. |
| Security | 10/10 | Review role checks, salted scrypt hashes, timing-safe token/password checks, parameterized SQL, input validation, CSRF request headers, environment-managed secrets, HTTPS deployment, and restricted data files. |
| Innovation | 5/5 | Review actionable SLA warnings, priority-aware escalation, multi-view analytics, and the cross-interface shared SQLite workflow. |
| **Total** | **100/100** | A target score, subject to independent execution and review; this table does not claim an external evaluator has awarded these marks. |

## Release Checks

Before submission, install dependencies and run `npm run lint`, `npm run build`, and `python3 -m unittest discover -s tests -v`. Exercise first-run setup, each role's permissions, complaint status transitions, CSV/JSON restore, and report downloads using a fresh database. Do not use the archive's demonstration database as production data.
