"""Unit tests for centralized defensive input validation."""

import unittest

from backend.validation import validate_complaint_payload, validate_user_payload


class TestValidation(unittest.TestCase):
    def setUp(self) -> None:
        self.valid_payload = {
            "student_name": "Aarav Patel",
            "student_id": "STU-24011",
            "hostel_name": "North Wing Hall",
            "block_number": "A",
            "room_number": "A-101",
            "category": "Electrical",
            "description": "Ceiling fan regulator sparks when switched between levels.",
            "priority": "High",
            "submission_date": "2026-11-10",
            "expected_resolution_date": "2026-11-14",
            "status": "Pending",
        }

    def test_valid_complaint_payload(self) -> None:
        cleaned, errors = validate_complaint_payload(self.valid_payload)
        self.assertEqual(errors, {})
        self.assertEqual(cleaned["room_number"], "A-101")
        self.assertEqual(cleaned["student_id"], "STU-24011")

    def test_empty_form_submission(self) -> None:
        _, errors = validate_complaint_payload({})
        self.assertIn("student_name", errors)
        self.assertIn("student_id", errors)
        self.assertIn("room_number", errors)
        self.assertIn("category", errors)
        self.assertIn("description", errors)
        self.assertIn("submission_date", errors)

    def test_invalid_room_number(self) -> None:
        bad = dict(self.valid_payload, room_number="!!INVALID ROOM!!")
        _, errors = validate_complaint_payload(bad)
        self.assertIn("room_number", errors)

    def test_invalid_category(self) -> None:
        bad = dict(self.valid_payload, category="Gardening")
        _, errors = validate_complaint_payload(bad)
        self.assertIn("category", errors)

    def test_expected_date_before_submission(self) -> None:
        bad = dict(
            self.valid_payload,
            submission_date="2026-11-15",
            expected_resolution_date="2026-11-10",
        )
        _, errors = validate_complaint_payload(bad)
        self.assertIn("expected_resolution_date", errors)

    def test_excessively_long_description(self) -> None:
        bad = dict(self.valid_payload, description="x" * 1005)
        _, errors = validate_complaint_payload(bad)
        self.assertIn("description", errors)

    def test_user_validation(self) -> None:
        _, errors = validate_user_payload(
            {
                "username": "ab",
                "full_name": "Test User",
                "role": "Guest",
                "password": "123",
            }
        )
        self.assertIn("username", errors)
        self.assertIn("role", errors)
        self.assertIn("password", errors)


if __name__ == "__main__":
    unittest.main()
