import { Building2 } from 'lucide-react';

interface BrandEmblem3DProps {
  size?: 'sm' | 'md' | 'lg';
}

export function BrandEmblem3D({ size = 'md' }: BrandEmblem3DProps) {
  const dims =
    size === 'sm'
      ? 'h-8 w-8 rounded-lg'
      : size === 'lg'
        ? 'h-12 w-12 rounded-xl'
        : 'h-9 w-9 rounded-lg';

  const iconDims =
    size === 'sm' ? 'h-4 w-4' : size === 'lg' ? 'h-6 w-6' : 'h-5 w-5';

  return (
    <div
      className={`brand-emblem-3d relative ${dims} flex items-center justify-center text-white shrink-0 border-t border-white/45`}
    >
      <Building2 className={`${iconDims} drop-shadow-xs`} aria-hidden="true" />
    </div>
  );
}

interface BrandTitle3DProps {
  text?: string;
  variant?: 'header' | 'sidebar' | 'hero';
  className?: string;
}

export function BrandTitle3D({
  text = 'Hostel Maintenance Tracker',
  variant = 'header',
  className = '',
}: BrandTitle3DProps) {
  const sizeClass =
    variant === 'hero'
      ? 'text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight'
      : variant === 'sidebar'
        ? 'text-sm font-extrabold tracking-tight leading-snug'
        : 'text-lg sm:text-xl font-extrabold tracking-tight whitespace-nowrap';

  const faceClass =
    variant === 'hero'
      ? 'bg-gradient-to-r from-white via-cyan-100 to-amber-100'
      : 'brand-face-gradient';

  const extrusionClass =
    variant === 'hero'
      ? 'brand-text-3d-hero'
      : variant === 'sidebar'
        ? 'brand-text-3d-compact'
        : 'brand-text-3d-header';

  return (
    <span className={`relative inline-block font-display ${sizeClass} ${className}`}>
      <span
        aria-hidden="true"
        className={`pointer-events-none select-none absolute inset-0 ${extrusionClass}`}
      >
        {text}
      </span>
      <span className={`relative z-10 ${faceClass} bg-clip-text text-transparent`}>
        {text}
      </span>
    </span>
  );
}
