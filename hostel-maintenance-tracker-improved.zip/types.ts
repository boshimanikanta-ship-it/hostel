export const CATEGORIES = [
  'Electrical',
  'Plumbing',
  'Cleaning',
  'Furniture',
  'Internet/Wi-Fi',
  'Bathroom',
  'Water Supply',
  'Other',
] as const;

export const PRIORITIES = ['Low', 'Medium', 'High', 'Critical'] as const;

export const STATUSES = ['Pending', 'In Progress', 'Completed'] as const;

export const WARNING_LEVELS = [
  'Normal',
  'Attention Required',
  'Overdue',
  'Critical',
] as const;

export const HOSTEL_OPTIONS = [
  'North Wing Hall',
  'South Courtyard',
  'East Horizon',
  'West Pine Hall',
] as const;

export type ThemeId =
  | 'indigo-horizon'
  | 'emerald-campus'
  | 'sunset-courtyard'
  | 'violet-aurora';

export interface ThemeOption {
  id: ThemeId;
  label: string;
  swatch: [string, string, string];
}

export const THEME_OPTIONS: readonly ThemeOption[] = [
  {
    id: 'indigo-horizon',
    label: 'Indigo Horizon',
    swatch: ['#4F46E5', '#2563EB', '#06B6D4'],
  },
  {
    id: 'emerald-campus',
    label: 'Emerald Campus',
    swatch: ['#059669', '#0D9488', '#0284C7'],
  },
  {
    id: 'sunset-courtyard',
    label: 'Sunset Courtyard',
    swatch: ['#EA580C', '#E11D48', '#7C3AED'],
  },
  {
    id: 'violet-aurora',
    label: 'Violet Aurora',
    swatch: ['#7C3AED', '#C026D4', '#06B6D4'],
  },
] as const;

export type UserRole = 'Administrator' | 'Maintenance Staff';

export interface AuthUser {
  id: number;
  username: string;
  full_name: string;
  email: string;
  role: UserRole;
  department: string;
}

export interface StatusHistoryEntry {
  id: number;
  complaint_id: string;
  old_status: string | null;
  new_status: string;
  changed_by: string;
  notes: string;
  changed_at: string;
}

export interface Complaint {
  id: number;
  complaint_id: string;
  student_name: string;
  student_id: string;
  hostel_name: string;
  block_number: string;
  room_number: string;
  category: string;
  description: string;
  priority: string;
  submission_date: string;
  expected_resolution_date: string;
  status: 'Pending' | 'In Progress' | 'Completed';
  assigned_staff: string;
  resolution_notes: string;
  in_progress_at: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
  warning_level: 'Normal' | 'Attention Required' | 'Overdue' | 'Critical';
  warning_reasons: string[];
  history?: StatusHistoryEntry[];
}

export interface PaginatedComplaints {
  items: Complaint[];
  total: number;
  page: number;
  per_page: number;
  total_pages: number;
}

export interface AnalyticsSummary {
  total_complaints: number;
  pending_complaints: number;
  in_progress_complaints: number;
  completed_complaints: number;
  overdue_complaints: number;
  completion_percentage: number;
  average_resolution_days: number;
  status_breakdown: Record<string, number>;
  category_breakdown: Record<string, number>;
  priority_breakdown: Record<string, number>;
  warning_breakdown: Record<string, number>;
  hostel_breakdown: Record<string, number>;
  monthly_trends: Array<{
    month: string;
    total: number;
    completed: number;
    pending: number;
    in_progress: number;
  }>;
  flagged_warnings: Complaint[];
  recent_audit: Array<{
    id: number;
    action: string;
    actor: string;
    target_id: string;
    details: string;
    created_at: string;
  }>;
}

export interface BulkImportResult {
  imported_count: number;
  rejected_count: number;
  total_processed: number;
  errors: Array<{
    row: number;
    complaint_id: string;
    error: string;
  }>;
}

export interface StaffDirectoryItem {
  id: number;
  username: string;
  full_name: string;
  department: string;
  role: UserRole;
  email?: string;
  is_active?: number;
  created_at?: string;
}
