"""Standalone Flask application exposing Hostel Maintenance Tracker APIs and server routes."""

import os
import secrets
from functools import wraps

from flask import Flask, Response, jsonify, request, session

from backend.analytics import compute_analytics
from backend.complaint_service import (
    create_complaint,
    delete_complaint,
    get_complaint_detail,
    list_complaints,
    update_complaint,
    update_complaint_status,
)
from backend.database import get_connection, hash_password, init_db, seed_sample_data, utc_now_iso, verify_password
from backend.import_export import create_json_backup, import_csv_content, restore_json_backup
from backend.reports import generate_report_bundle
from backend.validation import validate_user_payload
from backend.warning_system import summarize_warnings
from config import SECRET_KEY

app = Flask(__name__)
app.secret_key = SECRET_KEY
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("FLASK_ENV") == "production",
)


def require_auth(roles: tuple[str, ...] | None = None):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user = session.get("user")
            if not user:
                return jsonify({"error": "Authentication required."}), 401
            if roles and user.get("role") not in roles:
                return jsonify({"error": "Insufficient permissions for this action."}), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator


@app.before_request
def verify_csrf_header():
    if request.method in ("POST", "PUT", "PATCH", "DELETE") and request.path.startswith("/api/"):
        if request.headers.get("X-Requested-With") != "XMLHttpRequest":
            return jsonify({"error": "Missing CSRF verification header."}), 403


@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "service": "hostel-maintenance-tracker"})


@app.route("/api/auth/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip().lower()
    password = str(data.get("password", ""))
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    finally:
        conn.close()
    if not row or not row["is_active"] or not verify_password(password, row["password_hash"]):
        return jsonify({"error": "Invalid username or password."}), 401
    user_payload = {
        "id": row["id"],
        "username": row["username"],
        "full_name": row["full_name"],
        "role": row["role"],
        "department": row["department"],
    }
    session["user"] = user_payload
    session["csrf_token"] = secrets.token_hex(16)
    return jsonify({"user": user_payload})


@app.route("/api/auth/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify({"ok": True})


@app.route("/api/complaints", methods=["GET", "POST"])
@require_auth()
def complaints_collection():
    if request.method == "GET":
        res = list_complaints(
            keyword=request.args.get("keyword", ""),
            category=request.args.get("category", ""),
            priority=request.args.get("priority", ""),
            status=request.args.get("status", ""),
            warning_level=request.args.get("warning_level", ""),
            sort_by=request.args.get("sort_by", "submission_date"),
            sort_dir=request.args.get("sort_dir", "desc"),
            page=int(request.args.get("page", 1)),
            per_page=int(request.args.get("per_page", 50)),
        )
        return jsonify(res)

    user = session["user"]
    payload = request.get_json(silent=True) or {}
    created, errors = create_complaint(payload, actor=user["username"])
    if errors:
        return jsonify({"errors": errors}), 400
    return jsonify(created), 201


@app.route("/api/complaints/<complaint_id>", methods=["GET", "PUT", "DELETE"])
@require_auth()
def complaint_item(complaint_id: str):
    if request.method == "GET":
        item = get_complaint_detail(complaint_id)
        if not item:
            return jsonify({"error": "Complaint not found."}), 404
        return jsonify(item)

    user = session["user"]
    if user["role"] != "Administrator":
        return jsonify({"error": "Administrator access required."}), 403

    if request.method == "PUT":
        payload = request.get_json(silent=True) or {}
        updated, errors = update_complaint(complaint_id, payload, actor=user["username"])
        if errors:
            return jsonify({"errors": errors}), 400
        return jsonify(updated)

    deleted = delete_complaint(complaint_id, actor=user["username"])
    if not deleted:
        return jsonify({"error": "Complaint not found."}), 404
    return jsonify({"ok": True})


@app.route("/api/complaints/<complaint_id>/status", methods=["PATCH"])
@require_auth()
def complaint_status_route(complaint_id: str):
    user = session["user"]
    payload = request.get_json(silent=True) or {}
    updated, errors = update_complaint_status(
        complaint_id,
        payload.get("status", ""),
        assigned_staff=payload.get("assigned_staff"),
        resolution_notes=payload.get("resolution_notes"),
        actor=user["username"],
    )
    if errors:
        return jsonify({"errors": errors}), 400
    return jsonify(updated)


@app.route("/api/analytics")
@require_auth()
def analytics_route():
    summary = compute_analytics(
        start_date=request.args.get("start_date", ""),
        end_date=request.args.get("end_date", ""),
    )
    items = list_complaints(per_page=500)["items"]
    summary["warnings"] = summarize_warnings(items)
    return jsonify(summary)


@app.route("/api/reports/<fmt>")
@require_auth()
def report_export_route(fmt: str):
    try:
        content, mime, fname = generate_report_bundle(
            fmt,
            start_date=request.args.get("start_date", ""),
            end_date=request.args.get("end_date", ""),
            status=request.args.get("status", ""),
            save_to_disk=True,
        )
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    return Response(
        content,
        mimetype=mime,
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )


@app.route("/api/import/csv", methods=["POST"])
@require_auth(roles=("Administrator",))
def import_csv_route():
    user = session["user"]
    payload = request.get_json(silent=True) or {}
    csv_text = payload.get("csv_text", "")
    result = import_csv_content(csv_text, actor=user["username"])
    return jsonify(result)


@app.route("/api/backup/json", methods=["GET", "POST"])
@require_auth(roles=("Administrator",))
def backup_json_route():
    if request.method == "GET":
        _, content = create_json_backup()
        return Response(
            content,
            mimetype="application/json",
            headers={"Content-Disposition": 'attachment; filename="hostel_backup.json"'},
        )
    user = session["user"]
    payload = request.get_json(silent=True) or {}
    result = restore_json_backup(payload.get("json_text", ""), actor=user["username"])
    status_code = 200 if result.get("success") else 400
    return jsonify(result), status_code


@app.route("/api/users", methods=["GET", "POST"])
@require_auth(roles=("Administrator",))
def users_route():
    if request.method == "GET":
        conn = get_connection()
        try:
            rows = conn.execute(
                "SELECT id, username, full_name, email, role, department, is_active, created_at FROM users ORDER BY id ASC"
            ).fetchall()
        finally:
            conn.close()
        return jsonify([dict(r) for r in rows])

    payload = request.get_json(silent=True) or {}
    cleaned, errors = validate_user_payload(payload)
    if errors:
        return jsonify({"errors": errors}), 400
    conn = get_connection()
    try:
        conn.execute(
            """
            INSERT INTO users (username, full_name, email, role, department, password_hash, is_active, created_at)
            VALUES (?, ?, ?, ?, ?, ?, 1, ?)
            """,
            (
                cleaned["username"],
                cleaned["full_name"],
                cleaned["email"],
                cleaned["role"],
                cleaned["department"],
                hash_password(cleaned["password"]),
                utc_now_iso(),
            ),
        )
        conn.commit()
    except Exception as exc:
        return jsonify({"error": f"Unable to create user: {exc}"}), 400
    finally:
        conn.close()
    return jsonify({"ok": True}), 201


if __name__ == "__main__":
    init_db()
    seed_sample_data()
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=False)
