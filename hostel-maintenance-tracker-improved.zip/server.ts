import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import dotenv from 'dotenv';
import express from 'express';
import type { NextFunction, Request, Response } from 'express';
import {
  ALLOWED_ROLES,
  ALLOWED_STATUSES,
  CSV_REQUIRED_COLUMNS,
  computeAnalyticsFromRows,
  enrichComplaint,
  generateNextComplaintId,
  getDb,
  hashPassword,
  parseCsvRows,
  resolveSafeExportPath,
  sanitizeText,
  seedSampleRecords,
  serializeCsv,
  utcNowIso,
  validateComplaintPayload,
  verifyPassword,
  buildReport,
} from './server/maintenanceCore.ts';
import type { ComplaintRow, UserRow } from './server/maintenanceCore.ts';

dotenv.config();

const PORT = Number(process.env.PORT || 3000);
const configuredSessionSecret = (process.env.SESSION_SECRET || '').trim();
if (process.env.NODE_ENV === 'production' && Buffer.byteLength(configuredSessionSecret) < 32) {
  throw new Error('Production requires SESSION_SECRET with at least 32 bytes.');
}
const SESSION_SECRET = configuredSessionSecret || crypto.randomBytes(32).toString('hex');

interface AuthUser {
  id: number;
  username: string;
  full_name: string;
  email: string;
  role: 'Administrator' | 'Maintenance Staff';
  department: string;
}

interface AuthenticatedRequest extends Request {
  authUser?: AuthUser;
}

function signToken(user: AuthUser): string {
  const payload = {
    id: user.id,
    username: user.username,
    role: user.role,
    exp: Date.now() + 1000 * 60 * 60 * 12,
  };
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encoded)
    .digest('base64url');
  return `${encoded}.${sig}`;
}

function verifyToken(token: string): { id: number; username: string; role: string } | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, sig] = parts;
  const expected = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encoded)
    .digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expected);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    const parsed = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf-8')) as {
      id: number;
      username: string;
      role: string;
      exp: number;
    };
    if (!parsed.exp || Date.now() > parsed.exp) return null;
    return parsed;
  } catch {
    return null;
  }
}

function authenticate(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }
  const token = header.slice(7).trim();
  const decoded = verifyToken(token);
  if (!decoded) {
    res.status(401).json({ error: 'Session expired or invalid.' });
    return;
  }
  const db = getDb();
  const row = db
    .prepare(
      'SELECT id, username, full_name, email, role, department, is_active FROM users WHERE id = ?'
    )
    .get(decoded.id) as UserRow | undefined;
  if (!row || !row.is_active) {
    res.status(401).json({ error: 'User account is disabled or unavailable.' });
    return;
  }
  req.authUser = {
    id: row.id,
    username: row.username,
    full_name: row.full_name,
    email: row.email,
    role: row.role,
    department: row.department,
  };
  next();
}

function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (!req.authUser || req.authUser.role !== 'Administrator') {
    res.status(403).json({ error: 'Administrator permissions required for this action.' });
    return;
  }
  next();
}

async function startServer() {
  const db = getDb();
  const app = express();
  app.use(express.json({ limit: '5mb' }));

  // CSRF check for mutating API endpoints
  app.use('/api', (req, res, next) => {
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
      const requestedWith = req.headers['x-requested-with'];
      if (requestedWith !== 'XMLHttpRequest') {
        res.status(403).json({ error: 'Missing required X-Requested-With header.' });
        return;
      }
    }
    next();
  });

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'Hostel Maintenance Tracker' });
  });

  app.get('/api/auth/status', (_req, res) => {
    const adminCount = (
      db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'Administrator'").get() as {
        c: number;
      }
    ).c;
    const envConfigured = Boolean((process.env.HOSTEL_ADMIN_PASSCODE || '').trim());
    res.json({
      initialized: adminCount > 0,
      envConfigured,
    });
  });

  // One-time atomic first-run workspace setup when no Administrator exists yet
  app.post('/api/auth/setup', (req, res) => {
    const envConfigured = Boolean((process.env.HOSTEL_ADMIN_PASSCODE || '').trim());
    if (envConfigured) {
      res.status(403).json({
        error: 'Workspace credentials are managed via environment configuration.',
      });
      return;
    }

    const adminCount = (
      db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'Administrator'").get() as {
        c: number;
      }
    ).c;
    if (adminCount > 0) {
      res.status(409).json({
        error: 'Workspace administrator has already been claimed. Please sign in.',
      });
      return;
    }

    const body = req.body || {};
    const adminUsername = sanitizeText(body.admin_username || 'admin').toLowerCase();
    const adminFullName = sanitizeText(body.admin_full_name || 'Dr. Elena Mercer');
    const adminPassword = typeof body.admin_password === 'string' ? body.admin_password : '';
    const staffUsername = sanitizeText(body.staff_username || 'staff_marcus').toLowerCase();
    const staffFullName = sanitizeText(body.staff_full_name || 'Marcus Vance');
    const staffPassword = typeof body.staff_password === 'string' ? body.staff_password : '';

    if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(adminUsername)) {
      res.status(400).json({ error: 'Admin username must be 3–32 valid characters.' });
      return;
    }
    if (adminPassword.length < 6) {
      res.status(400).json({ error: 'Admin password must be at least 6 characters.' });
      return;
    }
    if (staffPassword && staffPassword.length < 6) {
      res.status(400).json({ error: 'Staff password must be at least 6 characters.' });
      return;
    }
    if (staffPassword && staffUsername === adminUsername) {
      res.status(400).json({ error: 'Staff username must differ from Admin username.' });
      return;
    }

    const now = utcNowIso();
    let createdAdmin: AuthUser | null = null;

    const tx = db.transaction(() => {
      const checkAgain = (
        db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'Administrator'").get() as {
          c: number;
        }
      ).c;
      if (checkAgain > 0) {
        throw new Error('ALREADY_CLAIMED');
      }
      const adminInsert = db
        .prepare(
          `INSERT INTO users (username, full_name, email, role, department, password_hash, is_active, created_at)
           VALUES (?, ?, ?, 'Administrator', 'Campus Housing Administration', ?, 1, ?)`
        )
        .run(
          adminUsername,
          adminFullName,
          'warden@campus-hostels.edu',
          hashPassword(adminPassword),
          now
        );

      createdAdmin = {
        id: Number(adminInsert.lastInsertRowid),
        username: adminUsername,
        full_name: adminFullName,
        email: 'warden@campus-hostels.edu',
        role: 'Administrator',
        department: 'Campus Housing Administration',
      };

      if (staffPassword) {
        db.prepare(
          `INSERT INTO users (username, full_name, email, role, department, password_hash, is_active, created_at)
           VALUES (?, ?, ?, 'Maintenance Staff', 'Electrical & Plumbing', ?, 1, ?)`
        ).run(
          staffUsername,
          staffFullName,
          'mvance@campus-hostels.edu',
          hashPassword(staffPassword),
          now
        );
      }

      db.prepare(
        'INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)'
      ).run(
        'WORKSPACE_CLAIMED',
        adminUsername,
        'users',
        'Initial administrator workspace account claimed.',
        now
      );
    });

    try {
      tx();
    } catch (err) {
      if (err instanceof Error && err.message === 'ALREADY_CLAIMED') {
        res.status(409).json({ error: 'Workspace administrator has already been claimed.' });
        return;
      }
      throw err;
    }

    const token = signToken(createdAdmin!);
    res.status(201).json({ token, user: createdAdmin });
  });

  app.post('/api/auth/login', (req, res) => {
    const body = req.body || {};
    const username = sanitizeText(body.username).toLowerCase();
    const password = typeof body.password === 'string' ? body.password : '';
    if (!username || !password) {
      res.status(400).json({ error: 'Username and password are required.' });
      return;
    }

    const row = db
      .prepare('SELECT * FROM users WHERE username = ?')
      .get(username) as (UserRow & { password_hash: string }) | undefined;

    if (!row || !row.is_active || !verifyPassword(password, row.password_hash)) {
      res.status(401).json({ error: 'Invalid username or password.' });
      return;
    }

    const user: AuthUser = {
      id: row.id,
      username: row.username,
      full_name: row.full_name,
      email: row.email,
      role: row.role,
      department: row.department,
    };
    const token = signToken(user);
    db.prepare(
      'INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)'
    ).run('USER_LOGIN', user.username, user.role, 'Signed in via web console', utcNowIso());

    res.json({ token, user });
  });

  app.get('/api/auth/me', authenticate, (req: AuthenticatedRequest, res) => {
    res.json({ user: req.authUser });
  });

  app.get('/api/staff-directory', authenticate, (_req, res) => {
    const staffRows = db
      .prepare(
        "SELECT id, username, full_name, department, role FROM users WHERE is_active = 1 ORDER BY full_name ASC"
      )
      .all();
    res.json(staffRows);
  });

  app.get('/api/complaints', authenticate, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const keyword = sanitizeText(req.query.keyword);
    const category = sanitizeText(req.query.category);
    const priority = sanitizeText(req.query.priority);
    const status = sanitizeText(req.query.status);
    const hostel = sanitizeText(req.query.hostel_name);
    const block = sanitizeText(req.query.block_number);
    const warningLevel = sanitizeText(req.query.warning_level);
    const startDate = sanitizeText(req.query.start_date);
    const endDate = sanitizeText(req.query.end_date);
    const sortBy = sanitizeText(req.query.sort_by || 'submission_date');
    const sortDir = sanitizeText(req.query.sort_dir || 'desc');
    const scope = sanitizeText(req.query.scope || (user.role === 'Maintenance Staff' ? 'assigned' : 'all'));
    const page = Math.max(1, Number.parseInt(String(req.query.page || '1'), 10) || 1);
    const perPage = Math.min(
      500,
      Math.max(1, Number.parseInt(String(req.query.per_page || '25'), 10) || 25)
    );

    const clauses: string[] = [];
    const params: string[] = [];

    if (user.role === 'Maintenance Staff' && scope === 'assigned') {
      clauses.push("(assigned_staff = ? OR assigned_staff = '' OR assigned_staff IS NULL)");
      params.push(user.full_name);
    }

    if (keyword) {
      const kw = `%${keyword}%`;
      clauses.push(
        `(complaint_id LIKE ? OR student_name LIKE ? OR student_id LIKE ?
          OR room_number LIKE ? OR block_number LIKE ? OR hostel_name LIKE ?
          OR category LIKE ? OR description LIKE ? OR status LIKE ?)`
      );
      params.push(kw, kw, kw, kw, kw, kw, kw, kw, kw);
    }
    if (category) {
      clauses.push('category = ?');
      params.push(category);
    }
    if (priority) {
      clauses.push('priority = ?');
      params.push(priority);
    }
    if (status) {
      clauses.push('status = ?');
      params.push(status);
    }
    if (hostel) {
      clauses.push('hostel_name = ?');
      params.push(hostel);
    }
    if (block) {
      clauses.push('block_number = ?');
      params.push(block);
    }
    if (startDate) {
      clauses.push('submission_date >= ?');
      params.push(startDate);
    }
    if (endDate) {
      clauses.push('submission_date <= ?');
      params.push(endDate);
    }

    const sortMap: Record<string, string> = {
      submission_date: 'submission_date',
      expected_resolution_date: 'expected_resolution_date',
      priority:
        "CASE priority WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 WHEN 'Medium' THEN 3 ELSE 4 END",
      complaint_id: 'complaint_id',
      updated_at: 'updated_at',
    };
    const sortExpr = sortMap[sortBy] || 'submission_date';
    const dir = sortDir.toLowerCase() === 'asc' ? 'ASC' : 'DESC';
    const whereSql = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';

    const rows = db
      .prepare(`SELECT * FROM complaints ${whereSql} ORDER BY ${sortExpr} ${dir}, id DESC`)
      .all(...params) as ComplaintRow[];

    let enriched = rows.map(enrichComplaint);
    if (warningLevel) {
      enriched = enriched.filter((r) => r.warning_level === warningLevel);
    }

    const total = enriched.length;
    const totalPages = Math.max(1, Math.ceil(total / perPage));
    const safePage = Math.min(page, totalPages);
    const start = (safePage - 1) * perPage;
    const items = enriched.slice(start, start + perPage);

    res.json({
      items,
      total,
      page: safePage,
      per_page: perPage,
      total_pages: totalPages,
    });
  });

  app.get('/api/complaints/next-id', authenticate, (req, res) => {
    const year = Number.parseInt(String(req.query.year || new Date().getFullYear()), 10);
    res.json({ next_id: generateNextComplaintId(db, year || new Date().getFullYear()) });
  });

  app.get('/api/complaints/:id', authenticate, (req: AuthenticatedRequest, res) => {
    const cid = sanitizeText(req.params.id);
    const row = db
      .prepare('SELECT * FROM complaints WHERE complaint_id = ?')
      .get(cid) as ComplaintRow | undefined;
    if (!row) {
      res.status(404).json({ error: `Complaint '${cid}' not found.` });
      return;
    }
    const history = db
      .prepare('SELECT * FROM status_history WHERE complaint_id = ? ORDER BY id ASC')
      .all(cid);
    res.json({ ...enrichComplaint(row), history });
  });

  app.post('/api/complaints', authenticate, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const { cleaned, errors } = validateComplaintPayload(req.body || {});
    if (Object.keys(errors).length > 0) {
      res.status(400).json({ errors });
      return;
    }

    const now = utcNowIso();
    let cid = cleaned.complaint_id || '';
    if (!cid) {
      const subYear = Number.parseInt((cleaned.submission_date || '2026').slice(0, 4), 10);
      cid = generateNextComplaintId(db, subYear);
    } else {
      const dup = db.prepare('SELECT 1 FROM complaints WHERE complaint_id = ?').get(cid);
      if (dup) {
        res.status(409).json({ errors: { complaint_id: `Complaint ID '${cid}' already exists.` } });
        return;
      }
    }

    const status = cleaned.status || 'Pending';
    const inProgressAt = status === 'In Progress' || status === 'Completed' ? now : null;
    const completedAt = status === 'Completed' ? now : null;

    const tx = db.transaction(() => {
      db.prepare(
        `INSERT INTO complaints (
          complaint_id, student_name, student_id, hostel_name,
          block_number, room_number, category, description,
          priority, submission_date, expected_resolution_date,
          status, assigned_staff, resolution_notes,
          in_progress_at, completed_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        cid,
        cleaned.student_name,
        cleaned.student_id,
        cleaned.hostel_name,
        cleaned.block_number,
        cleaned.room_number,
        cleaned.category,
        cleaned.description,
        cleaned.priority,
        cleaned.submission_date,
        cleaned.expected_resolution_date,
        status,
        cleaned.assigned_staff,
        cleaned.resolution_notes,
        inProgressAt,
        completedAt,
        now,
        now
      );
      db.prepare(
        `INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes, changed_at)
         VALUES (?, ?, ?, ?, ?, ?)`
      ).run(cid, null, status, user.username, 'Complaint registered', now);
      db.prepare(
        'INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)'
      ).run(
        'CREATE_COMPLAINT',
        user.username,
        cid,
        `Registered ${cleaned.category} request for ${cleaned.hostel_name} ${cleaned.room_number}`,
        now
      );
    });
    tx();

    const created = db
      .prepare('SELECT * FROM complaints WHERE complaint_id = ?')
      .get(cid) as ComplaintRow;
    res.status(201).json(enrichComplaint(created));
  });

  app.put('/api/complaints/:id', authenticate, requireAdmin, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const cid = sanitizeText(req.params.id);
    const existing = db
      .prepare('SELECT * FROM complaints WHERE complaint_id = ?')
      .get(cid) as ComplaintRow | undefined;
    if (!existing) {
      res.status(404).json({ error: `Complaint '${cid}' not found.` });
      return;
    }

    const merged = { ...existing, ...(req.body || {}), complaint_id: cid };
    const { cleaned, errors } = validateComplaintPayload(merged, { requireComplaintId: true });
    if (Object.keys(errors).length > 0) {
      res.status(400).json({ errors });
      return;
    }

    const now = utcNowIso();
    const newStatus = cleaned.status || existing.status;
    let inProgressAt = existing.in_progress_at;
    let completedAt = existing.completed_at;
    if (newStatus === 'In Progress' && !inProgressAt) inProgressAt = now;
    if (newStatus === 'Completed') {
      if (!inProgressAt) inProgressAt = now;
      if (!completedAt) completedAt = now;
    } else {
      completedAt = null;
    }

    const tx = db.transaction(() => {
      db.prepare(
        `UPDATE complaints SET
          student_name = ?, student_id = ?, hostel_name = ?,
          block_number = ?, room_number = ?, category = ?,
          description = ?, priority = ?, submission_date = ?,
          expected_resolution_date = ?, status = ?, assigned_staff = ?,
          resolution_notes = ?, in_progress_at = ?, completed_at = ?,
          updated_at = ?
         WHERE complaint_id = ?`
      ).run(
        cleaned.student_name,
        cleaned.student_id,
        cleaned.hostel_name,
        cleaned.block_number,
        cleaned.room_number,
        cleaned.category,
        cleaned.description,
        cleaned.priority,
        cleaned.submission_date,
        cleaned.expected_resolution_date,
        newStatus,
        cleaned.assigned_staff,
        cleaned.resolution_notes,
        inProgressAt,
        completedAt,
        now,
        cid
      );
      if (existing.status !== newStatus) {
        db.prepare(
          `INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes, changed_at)
           VALUES (?, ?, ?, ?, ?, ?)`
        ).run(
          cid,
          existing.status,
          newStatus,
          user.username,
          cleaned.resolution_notes || `Status updated from ${existing.status} to ${newStatus}`,
          now
        );
      }
      db.prepare(
        'INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)'
      ).run('UPDATE_COMPLAINT', user.username, cid, `Updated record (status: ${newStatus})`, now);
    });
    tx();

    const updated = db
      .prepare('SELECT * FROM complaints WHERE complaint_id = ?')
      .get(cid) as ComplaintRow;
    const history = db
      .prepare('SELECT * FROM status_history WHERE complaint_id = ? ORDER BY id ASC')
      .all(cid);
    res.json({ ...enrichComplaint(updated), history });
  });

  app.patch('/api/complaints/:id/status', authenticate, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const cid = sanitizeText(req.params.id);
    const existing = db
      .prepare('SELECT * FROM complaints WHERE complaint_id = ?')
      .get(cid) as ComplaintRow | undefined;
    if (!existing) {
      res.status(404).json({ error: `Complaint '${cid}' not found.` });
      return;
    }

    if (
      user.role === 'Maintenance Staff' &&
      existing.assigned_staff &&
      existing.assigned_staff !== user.full_name
    ) {
      res.status(403).json({
        error: 'Maintenance Staff can only update complaints assigned to them or unassigned.',
      });
      return;
    }

    const body = req.body || {};
    const newStatus = sanitizeText(body.status);
    if (!(ALLOWED_STATUSES as readonly string[]).includes(newStatus)) {
      res.status(400).json({ error: `Invalid status. Use: ${ALLOWED_STATUSES.join(', ')}.` });
      return;
    }

    const nextStaff =
      body.assigned_staff !== undefined
        ? sanitizeText(body.assigned_staff).slice(0, 80)
        : existing.assigned_staff;
    const nextNotes =
      body.resolution_notes !== undefined
        ? sanitizeText(body.resolution_notes).slice(0, 1000)
        : existing.resolution_notes;

    const now = utcNowIso();
    let inProgressAt = existing.in_progress_at;
    let completedAt = existing.completed_at;
    if (newStatus === 'In Progress' && !inProgressAt) inProgressAt = now;
    if (newStatus === 'Completed') {
      if (!inProgressAt) inProgressAt = now;
      completedAt = now;
    } else {
      completedAt = null;
    }

    const tx = db.transaction(() => {
      db.prepare(
        `UPDATE complaints
         SET status = ?, assigned_staff = ?, resolution_notes = ?,
             in_progress_at = ?, completed_at = ?, updated_at = ?
         WHERE complaint_id = ?`
      ).run(newStatus, nextStaff, nextNotes, inProgressAt, completedAt, now, cid);
      db.prepare(
        `INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes, changed_at)
         VALUES (?, ?, ?, ?, ?, ?)`
      ).run(
        cid,
        existing.status,
        newStatus,
        user.username,
        nextNotes || `Status changed to ${newStatus}`,
        now
      );
      db.prepare(
        'INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)'
      ).run('STATUS_UPDATE', user.username, cid, `${existing.status} -> ${newStatus}`, now);
    });
    tx();

    const updated = db
      .prepare('SELECT * FROM complaints WHERE complaint_id = ?')
      .get(cid) as ComplaintRow;
    const history = db
      .prepare('SELECT * FROM status_history WHERE complaint_id = ? ORDER BY id ASC')
      .all(cid);
    res.json({ ...enrichComplaint(updated), history });
  });

  app.delete('/api/complaints/:id', authenticate, requireAdmin, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const cid = sanitizeText(req.params.id);
    const tx = db.transaction(() => {
      const info = db.prepare('DELETE FROM complaints WHERE complaint_id = ?').run(cid);
      if (info.changes === 0) return false;
      db.prepare('DELETE FROM status_history WHERE complaint_id = ?').run(cid);
      db.prepare(
        'INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)'
      ).run('DELETE_COMPLAINT', user.username, cid, 'Deleted maintenance record', utcNowIso());
      return true;
    });
    const deleted = tx();
    if (!deleted) {
      res.status(404).json({ error: `Complaint '${cid}' not found.` });
      return;
    }
    res.json({ ok: true });
  });

  app.get('/api/analytics', authenticate, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const startDate = sanitizeText(req.query.start_date);
    const endDate = sanitizeText(req.query.end_date);
    const hostelName = sanitizeText(req.query.hostel_name);
    const clauses: string[] = [];
    const params: string[] = [];

    if (user.role === 'Maintenance Staff' && req.query.scope !== 'all') {
      clauses.push("(assigned_staff = ? OR assigned_staff = '' OR assigned_staff IS NULL)");
      params.push(user.full_name);
    }
    if (startDate) {
      clauses.push('submission_date >= ?');
      params.push(startDate);
    }
    if (endDate) {
      clauses.push('submission_date <= ?');
      params.push(endDate);
    }
    if (hostelName) {
      clauses.push('hostel_name = ?');
      params.push(hostelName);
    }

    const whereSql = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
    const rows = db
      .prepare(`SELECT * FROM complaints ${whereSql} ORDER BY submission_date ASC`)
      .all(...params) as ComplaintRow[];

    const summary = computeAnalyticsFromRows(rows);
    const enriched = rows.map(enrichComplaint);
    const rank: Record<string, number> = { Critical: 0, Overdue: 1, 'Attention Required': 2 };
    const flagged = enriched
      .filter((r) => r.warning_level !== 'Normal')
      .sort((a, b) => {
        const ra = rank[a.warning_level || 'Normal'] ?? 9;
        const rb = rank[b.warning_level || 'Normal'] ?? 9;
        if (ra !== rb) return ra - rb;
        return a.expected_resolution_date.localeCompare(b.expected_resolution_date);
      });

    const recentAudit = db
      .prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 20')
      .all();

    res.json({ ...summary, flagged_warnings: flagged, recent_audit: recentAudit });
  });

  app.get('/api/reports/:fmt', authenticate, (req, res) => {
    const fmt = sanitizeText(req.params.fmt);
    const startDate = sanitizeText(req.query.start_date);
    const endDate = sanitizeText(req.query.end_date);
    const status = sanitizeText(req.query.status);
    try {
      const bundle = buildReport(db, fmt, {
        start_date: startDate || undefined,
        end_date: endDate || undefined,
        status: status || undefined,
      });
      if (req.query.preview === '1') {
        res.json({
          filename: bundle.filename,
          mimeType: bundle.mimeType,
          content: bundle.content,
        });
        return;
      }
      res.setHeader('Content-Type', bundle.mimeType);
      res.setHeader('Content-Disposition', `attachment; filename="${bundle.filename}"`);
      res.send(bundle.content);
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Report error' });
    }
  });

  app.get('/api/export/csv', authenticate, (_req, res) => {
    const rows = db.prepare('SELECT * FROM complaints ORDER BY id ASC').all() as ComplaintRow[];
    const csv = serializeCsv(rows);
    const fname = `hostel_complaints_${utcNowIso().slice(0, 10)}.csv`;
    fs.writeFileSync(resolveSafeExportPath(fname), csv, 'utf-8');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${fname}"`);
    res.send(csv);
  });

  app.get('/api/backup/json', authenticate, requireAdmin, (_req, res) => {
    const rows = db.prepare('SELECT * FROM complaints ORDER BY id ASC').all() as ComplaintRow[];
    const content = JSON.stringify(
      {
        exported_at: utcNowIso(),
        record_count: rows.length,
        records: rows,
      },
      null,
      2
    );
    const fname = `hostel_backup_${utcNowIso().replace(/:/g, '-')}.json`;
    fs.writeFileSync(resolveSafeExportPath(fname), content, 'utf-8');
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${fname}"`);
    res.send(content);
  });

  app.post('/api/backup/restore', authenticate, requireAdmin, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const jsonText = typeof req.body?.json_text === 'string' ? req.body.json_text : '';
    let parsed: unknown;
    try {
      parsed = JSON.parse(jsonText);
    } catch (err) {
      res.status(400).json({
        success: false,
        error: `Corrupted or invalid JSON file: ${err instanceof Error ? err.message : 'parse failed'}`,
      });
      return;
    }

    const records = Array.isArray(parsed)
      ? parsed
      : parsed && typeof parsed === 'object' && Array.isArray((parsed as { records?: unknown[] }).records)
        ? (parsed as { records: unknown[] }).records
        : null;

    if (!records) {
      res.status(400).json({
        success: false,
        error: "JSON backup must be an array or an object containing a 'records' array.",
      });
      return;
    }

    const existingIds = new Set(
      (db.prepare('SELECT complaint_id FROM complaints').all() as Array<{ complaint_id: string }>).map(
        (r) => r.complaint_id
      )
    );
    const seenIds = new Set<string>();
    const toInsert: Array<Record<string, string | null>> = [];
    const errors: Array<{ row: number; complaint_id: string; error: string }> = [];
    let skippedDuplicates = 0;

    records.forEach((raw, idx) => {
      if (!raw || typeof raw !== 'object') {
        errors.push({ row: idx + 1, complaint_id: '', error: 'Record is not a JSON object.' });
        return;
      }
      const rawObj = raw as Record<string, unknown>;
      const { cleaned, errors: rowErrs } = validateComplaintPayload(rawObj, {
        requireComplaintId: true,
      });
      if (Object.keys(rowErrs).length > 0) {
        errors.push({
          row: idx + 1,
          complaint_id: String(rawObj.complaint_id || ''),
          error: Object.entries(rowErrs)
            .map(([k, v]) => `${k}: ${v}`)
            .join('; '),
        });
        return;
      }
      const cid = cleaned.complaint_id || '';
      if (existingIds.has(cid) || seenIds.has(cid)) {
        skippedDuplicates += 1;
        return;
      }
      seenIds.add(cid);
      toInsert.push(cleaned);
    });

    const now = utcNowIso();
    if (toInsert.length > 0) {
      const insertStmt = db.prepare(`
        INSERT INTO complaints (
          complaint_id, student_name, student_id, hostel_name,
          block_number, room_number, category, description,
          priority, submission_date, expected_resolution_date,
          status, assigned_staff, resolution_notes,
          in_progress_at, completed_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      const insertHistory = db.prepare(`
        INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes, changed_at)
        VALUES (?, NULL, ?, ?, ?, ?)
      `);
      const tx = db.transaction(() => {
        for (const item of toInsert) {
          const status = item.status || 'Pending';
          const inProgressAt = item.in_progress_at ||
            (status === 'In Progress' || status === 'Completed' ? now : null);
          const completedAt = item.completed_at || (status === 'Completed' ? now : null);
          insertStmt.run(
            item.complaint_id,
            item.student_name,
            item.student_id,
            item.hostel_name,
            item.block_number,
            item.room_number,
            item.category,
            item.description,
            item.priority,
            item.submission_date,
            item.expected_resolution_date,
            status,
            item.assigned_staff || '',
            item.resolution_notes || '',
            inProgressAt,
            completedAt,
            now,
            now
          );
          insertHistory.run(item.complaint_id, status, user.username, 'Restored from JSON backup', now);
        }
        db.prepare(
          'INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)'
        ).run(
          'JSON_RESTORE',
          user.username,
          'complaints',
          `Restored ${toInsert.length} records (${skippedDuplicates} existing preserved).`,
          now
        );
      });
      tx();
    }

    res.json({
      success: true,
      restored_count: toInsert.length,
      skipped_duplicates: skippedDuplicates,
      rejected_count: errors.length,
      errors,
    });
  });

  app.post('/api/import/csv', authenticate, requireAdmin, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const csvText = typeof req.body?.csv_text === 'string' ? req.body.csv_text : '';
    if (!csvText.trim()) {
      res.status(400).json({
        imported_count: 0,
        rejected_count: 0,
        total_processed: 0,
        errors: [{ row: 0, complaint_id: '', error: 'Uploaded CSV file is empty.' }],
      });
      return;
    }

    const { headers, rows } = parseCsvRows(csvText);
    if (headers.length === 0) {
      res.status(400).json({
        imported_count: 0,
        rejected_count: 0,
        total_processed: 0,
        errors: [{ row: 0, complaint_id: '', error: 'Missing CSV header row.' }],
      });
      return;
    }

    const missingCols = CSV_REQUIRED_COLUMNS.filter((c) => !headers.includes(c));
    if (missingCols.length > 0) {
      res.status(400).json({
        imported_count: 0,
        rejected_count: 0,
        total_processed: 0,
        errors: [
          {
            row: 0,
            complaint_id: '',
            error: `Missing required CSV columns: ${missingCols.join(', ')}`,
          },
        ],
      });
      return;
    }

    const existingIds = new Set(
      (db.prepare('SELECT complaint_id FROM complaints').all() as Array<{ complaint_id: string }>).map(
        (r) => r.complaint_id
      )
    );
    const seenInFile = new Set<string>();
    const validRows: Array<Record<string, string | null>> = [];
    const rowErrors: Array<{ row: number; complaint_id: string; error: string }> = [];

    rows.forEach((rawRow, index) => {
      const rowNum = index + 2;
      const cidRaw = rawRow.complaint_id || '';
      const { cleaned, errors } = validateComplaintPayload(rawRow, {
        requireComplaintId: true,
      });
      if (Object.keys(errors).length > 0) {
        rowErrors.push({
          row: rowNum,
          complaint_id: cidRaw,
          error: Object.entries(errors)
            .map(([k, v]) => `${k}: ${v}`)
            .join('; '),
        });
        return;
      }
      const cid = cleaned.complaint_id || '';
      if (existingIds.has(cid)) {
        rowErrors.push({
          row: rowNum,
          complaint_id: cid,
          error: 'Duplicate complaint_id already exists in database.',
        });
        return;
      }
      if (seenInFile.has(cid)) {
        rowErrors.push({
          row: rowNum,
          complaint_id: cid,
          error: 'Duplicate complaint_id within uploaded CSV file.',
        });
        return;
      }
      seenInFile.add(cid);
      validRows.push(cleaned);
    });

    const now = utcNowIso();
    if (validRows.length > 0) {
      const insertStmt = db.prepare(`
        INSERT INTO complaints (
          complaint_id, student_name, student_id, hostel_name,
          block_number, room_number, category, description,
          priority, submission_date, expected_resolution_date,
          status, assigned_staff, resolution_notes,
          in_progress_at, completed_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      const insertHist = db.prepare(`
        INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes, changed_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `);
      const tx = db.transaction(() => {
        for (const item of validRows) {
          const st = item.status || 'Pending';
          const inProg =
            item.in_progress_at || (st === 'In Progress' || st === 'Completed' ? now : null);
          const compAt = item.completed_at || (st === 'Completed' ? now : null);
          insertStmt.run(
            item.complaint_id,
            item.student_name,
            item.student_id,
            item.hostel_name,
            item.block_number,
            item.room_number,
            item.category,
            item.description,
            item.priority,
            item.submission_date,
            item.expected_resolution_date,
            st,
            item.assigned_staff || '',
            item.resolution_notes || '',
            inProg,
            compAt,
            now,
            now
          );
          insertHist.run(
            item.complaint_id,
            null,
            st,
            user.username,
            'Imported via CSV bulk upload',
            now
          );
        }
        db.prepare(
          'INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)'
        ).run(
          'CSV_BULK_IMPORT',
          user.username,
          'complaints',
          `Imported ${validRows.length} records, rejected ${rowErrors.length} records.`,
          now
        );
      });
      tx();
    }

    res.json({
      imported_count: validRows.length,
      rejected_count: rowErrors.length,
      total_processed: rows.length,
      errors: rowErrors,
    });
  });

  app.post('/api/seed-sample', authenticate, requireAdmin, (req: AuthenticatedRequest, res) => {
    const result = seedSampleRecords(db, req.authUser!.username);
    res.json(result);
  });

  app.get('/api/users', authenticate, requireAdmin, (_req, res) => {
    const rows = db
      .prepare(
        'SELECT id, username, full_name, email, role, department, is_active, created_at FROM users ORDER BY id ASC'
      )
      .all();
    res.json(rows);
  });

  app.post('/api/users', authenticate, requireAdmin, (req: AuthenticatedRequest, res) => {
    const body = req.body || {};
    const username = sanitizeText(body.username).toLowerCase();
    const fullName = sanitizeText(body.full_name);
    const email = sanitizeText(body.email);
    const role = sanitizeText(body.role || 'Maintenance Staff');
    const department = sanitizeText(body.department || 'General Maintenance') || 'General Maintenance';
    const password = typeof body.password === 'string' ? body.password : '';

    const errors: Record<string, string> = {};
    if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username)) {
      errors.username = 'Username must be 3–32 alphanumeric/._- characters.';
    }
    if (!/^[A-Za-z][A-Za-z\s'.-]{1,79}$/.test(fullName)) {
      errors.full_name = 'Full name must be 2–80 valid characters.';
    }
    if (!(ALLOWED_ROLES as readonly string[]).includes(role)) {
      errors.role = `Role must be one of: ${ALLOWED_ROLES.join(', ')}.`;
    }
    if (password.length < 6) {
      errors.password = 'Password must be at least 6 characters.';
    }
    if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      errors.email = 'Invalid email address.';
    }

    if (Object.keys(errors).length > 0) {
      res.status(400).json({ errors });
      return;
    }

    const exists = db.prepare('SELECT 1 FROM users WHERE username = ?').get(username);
    if (exists) {
      res.status(409).json({ errors: { username: `Username '${username}' already exists.` } });
      return;
    }

    const now = utcNowIso();
    const info = db
      .prepare(
        `INSERT INTO users (username, full_name, email, role, department, password_hash, is_active, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 1, ?)`
      )
      .run(username, fullName, email, role, department, hashPassword(password), now);

    db.prepare(
      'INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)'
    ).run('CREATE_USER', req.authUser!.username, username, `Provisioned ${role} account`, now);

    const created = db
      .prepare(
        'SELECT id, username, full_name, email, role, department, is_active, created_at FROM users WHERE id = ?'
      )
      .get(info.lastInsertRowid);
    res.status(201).json(created);
  });

  app.patch('/api/users/:id/toggle', authenticate, requireAdmin, (req: AuthenticatedRequest, res) => {
    const targetId = Number.parseInt(req.params.id, 10);
    if (targetId === req.authUser!.id) {
      res.status(400).json({ error: 'Cannot deactivate your own active administrator account.' });
      return;
    }
    const target = db
      .prepare('SELECT id, username, is_active FROM users WHERE id = ?')
      .get(targetId) as { id: number; username: string; is_active: number } | undefined;
    if (!target) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }
    const nextState = target.is_active ? 0 : 1;
    db.prepare('UPDATE users SET is_active = ? WHERE id = ?').run(nextState, targetId);
    db.prepare(
      'INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)'
    ).run(
      'TOGGLE_USER',
      req.authUser!.username,
      target.username,
      nextState ? 'Activated account' : 'Deactivated account',
      utcNowIso()
    );
    res.json({ id: targetId, is_active: nextState });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Hostel Maintenance Tracker running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
