import { useState } from 'react';
import { AlertTriangle, CheckCircle2, Eye } from 'lucide-react';
import type { AnalyticsSummary } from '../types';

interface WarningsViewProps {
  analytics: AnalyticsSummary | null;
  onInspectComplaint: (complaintId: string) => void;
}

export function WarningsView({ analytics, onInspectComplaint }: WarningsViewProps) {
  const [selectedLevel, setSelectedLevel] = useState<string>('ALL');

  if (!analytics) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-sm text-slate-500">
        Loading threshold warning evaluation...
      </div>
    );
  }

  const counts = analytics.warning_breakdown;
  const flagged = analytics.flagged_warnings;
  const visible =
    selectedLevel === 'ALL'
      ? flagged
      : flagged.filter((item) => item.warning_level === selectedLevel);

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-lg font-bold text-slate-900">
            Threshold Warning System
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Automatic SLA evaluation based on submission age, priority severity, and expected resolution dates.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
          {(['ALL', 'Critical', 'Overdue', 'Attention Required'] as const).map((lvl) => (
            <button
              key={lvl}
              type="button"
              onClick={() => setSelectedLevel(lvl)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                selectedLevel === lvl
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lvl === 'ALL' ? `All Flagged (${flagged.length})` : `${lvl} (${counts[lvl] || 0})`}
            </button>
          ))}
        </div>
      </div>

      {/* Summary Counts */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <span className="text-xs font-medium text-red-700">Critical Escalations</span>
          <div className="font-display text-3xl font-bold text-red-700 tabular-nums mt-1.5">
            {counts['Critical'] || 0}
          </div>
          <p className="text-xs text-slate-500 mt-1.5">
            Critical priority or overdue beyond 3 days
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <span className="text-xs font-medium text-rose-600">Overdue Requests</span>
          <div className="font-display text-3xl font-bold text-rose-600 tabular-nums mt-1.5">
            {counts['Overdue'] || 0}
          </div>
          <p className="text-xs text-slate-500 mt-1.5">Past expected resolution date</p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <span className="text-xs font-medium text-amber-700">Attention Required</span>
          <div className="font-display text-3xl font-bold text-amber-700 tabular-nums mt-1.5">
            {counts['Attention Required'] || 0}
          </div>
          <p className="text-xs text-slate-500 mt-1.5">
            Due within 48h or pending over 5 days
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <span className="text-xs font-medium text-emerald-700">Normal / Nominal</span>
          <div className="font-display text-3xl font-bold text-emerald-700 tabular-nums mt-1.5">
            {counts['Normal'] || 0}
          </div>
          <p className="text-xs text-slate-500 mt-1.5">Completed or within SLA schedule</p>
        </div>
      </div>

      {/* Warning Table */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        {visible.length === 0 ? (
          <div className="p-12 text-center space-y-2">
            <CheckCircle2 className="h-8 w-8 text-emerald-600 mx-auto" aria-hidden="true" />
            <p className="text-sm font-medium text-slate-800">
              No records currently flagged in this warning category.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
                  <th className="py-3 px-4">Warning State</th>
                  <th className="py-3 px-4">Complaint ID</th>
                  <th className="py-3 px-4">Location & Student</th>
                  <th className="py-3 px-4">Trigger Condition</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Expected Date</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {visible.map((item) => (
                  <tr key={item.complaint_id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-1.5 text-xs font-semibold ${
                          item.warning_level === 'Critical'
                            ? 'text-red-700'
                            : item.warning_level === 'Overdue'
                              ? 'text-rose-600'
                              : 'text-amber-700'
                        }`}
                      >
                        <AlertTriangle className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>{item.warning_level}</span>
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-xs font-semibold text-indigo-700 tabular-nums whitespace-nowrap">
                      {item.complaint_id}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900">
                        {item.hostel_name} · {item.block_number}-{item.room_number}
                      </div>
                      <div className="text-xs text-slate-500">
                        {item.student_name} · {item.category}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-700">
                      {item.warning_reasons.join(' · ')}
                    </td>
                    <td className="py-3 px-4 text-xs font-medium text-slate-700 whitespace-nowrap">
                      {item.status}
                    </td>
                    <td className="py-3 px-4 font-mono text-xs text-slate-600 tabular-nums whitespace-nowrap">
                      {item.expected_resolution_date}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => onInspectComplaint(item.complaint_id)}
                        className="inline-flex items-center gap-1 text-xs font-medium text-indigo-700 hover:text-indigo-800 cursor-pointer"
                      >
                        <Eye className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Inspect</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
