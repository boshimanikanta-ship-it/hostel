import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';

export const ROOT_DIR = process.cwd();
export const DATA_DIR = path.resolve(ROOT_DIR, 'data');
export const EXPORTS_DIR = path.resolve(ROOT_DIR, 'exports');
export const DB_PATH = path.resolve(
  process.env.HOSTEL_DB_PATH || path.join(DATA_DIR, 'hostel.db')
);
export const SAMPLE_JSON_PATH = path.resolve(DATA_DIR, 'sample_complaints.json');

export const ALLOWED_CATEGORIES = [
  'Electrical',
  'Plumbing',
  'Cleaning',
  'Furniture',
  'Internet/Wi-Fi',
  'Bathroom',
  'Water Supply',
  'Other',
] as const;

export const ALLOWED_PRIORITIES = ['Low', 'Medium', 'High', 'Critical'] as const;
export const ALLOWED_STATUSES = ['Pending', 'In Progress', 'Completed'] as const;
export const ALLOWED_ROLES = ['Administrator', 'Maintenance Staff'] as const;

export const CSV_REQUIRED_COLUMNS = [
  'complaint_id',
  'student_name',
  'student_id',
  'hostel_name',
  'block_number',
  'room_number',
  'category',
  'description',
  'priority',
  'submission_date',
  'expected_resolution_date',
  'status',
] as const;

const EXPORT_COLUMNS = [
  'complaint_id',
  'student_name',
  'student_id',
  'hostel_name',
  'block_number',
  'room_number',
  'category',
  'description',
  'priority',
  'submission_date',
  'expected_resolution_date',
  'status',
  'assigned_staff',
  'resolution_notes',
  'in_progress_at',
  'completed_at',
  'created_at',
  'updated_at',
] as const;

export interface ComplaintRow {
  id: number;
  complaint_id: string;
  student_name: string;
  student_id: string;
  hostel_name: string;
  block_number: string;
  room_number: string;
  category: string;
  description: string;
  priority: string;
  submission_date: string;
  expected_resolution_date: string;
  status: string;
  assigned_staff: string;
  resolution_notes: string;
  in_progress_at: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
  warning_level?: string;
  warning_reasons?: string[];
}

export interface UserRow {
  id: number;
  username: string;
  full_name: string;
  email: string;
  role: 'Administrator' | 'Maintenance Staff';
  department: string;
  password_hash?: string;
  is_active: number;
  created_at: string;
}

export function utcNowIso(): string {
  return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
}

export function hashPassword(password: string, existingSalt?: string): string {
  const salt = existingSalt || crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt:${salt}:${derived.toString('hex')}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  if (!storedHash || !storedHash.startsWith('scrypt:')) return false;
  const parts = storedHash.split(':');
  if (parts.length !== 3) return false;
  const [, salt, expectedHex] = parts;
  const candidate = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 });
  const expectedBuf = Buffer.from(expectedHex, 'hex');
  if (candidate.length !== expectedBuf.length) return false;
  return crypto.timingSafeEqual(candidate, expectedBuf);
}

let dbInstance: Database.Database | null = null;

export function getDb(): Database.Database {
  if (dbInstance) return dbInstance;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(EXPORTS_DIR, { recursive: true });
  const db = new Database(DB_PATH);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      full_name TEXT NOT NULL,
      email TEXT DEFAULT '',
      role TEXT NOT NULL CHECK(role IN ('Administrator', 'Maintenance Staff')),
      department TEXT DEFAULT 'General Maintenance',
      password_hash TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS complaints (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      complaint_id TEXT UNIQUE NOT NULL,
      student_name TEXT NOT NULL,
      student_id TEXT NOT NULL,
      hostel_name TEXT NOT NULL,
      block_number TEXT NOT NULL,
      room_number TEXT NOT NULL,
      category TEXT NOT NULL CHECK(category IN (
        'Electrical', 'Plumbing', 'Cleaning', 'Furniture',
        'Internet/Wi-Fi', 'Bathroom', 'Water Supply', 'Other'
      )),
      description TEXT NOT NULL,
      priority TEXT NOT NULL CHECK(priority IN ('Low', 'Medium', 'High', 'Critical')),
      submission_date TEXT NOT NULL,
      expected_resolution_date TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending', 'In Progress', 'Completed')),
      assigned_staff TEXT DEFAULT '',
      resolution_notes TEXT DEFAULT '',
      in_progress_at TEXT DEFAULT NULL,
      completed_at TEXT DEFAULT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS status_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      complaint_id TEXT NOT NULL,
      old_status TEXT,
      new_status TEXT NOT NULL,
      changed_by TEXT NOT NULL,
      notes TEXT DEFAULT '',
      changed_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      action TEXT NOT NULL,
      actor TEXT NOT NULL,
      target_id TEXT DEFAULT '',
      details TEXT DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_complaints_status ON complaints(status);
    CREATE INDEX IF NOT EXISTS idx_complaints_category ON complaints(category);
    CREATE INDEX IF NOT EXISTS idx_complaints_priority ON complaints(priority);
    CREATE INDEX IF NOT EXISTS idx_complaints_sub_date ON complaints(submission_date);
  `);

  provisionEnvAccounts(db);
  seedSampleIfEmpty(db);
  dbInstance = db;
  return db;
}

function provisionEnvAccounts(db: Database.Database): void {
  const adminPass = (process.env.HOSTEL_ADMIN_PASSCODE || '').trim();
  if (adminPass) {
    const existing = db.prepare('SELECT id FROM users WHERE username = ?').get('admin');
    const pwHash = hashPassword(adminPass);
    if (existing) {
      db.prepare('UPDATE users SET password_hash = ?, is_active = 1 WHERE username = ?').run(
        pwHash,
        'admin'
      );
    } else {
      db.prepare(
        `INSERT INTO users (username, full_name, email, role, department, password_hash, is_active, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 1, ?)`
      ).run(
        'admin',
        'Dr. Elena Mercer',
        'warden@campus-hostels.edu',
        'Administrator',
        'Campus Housing Administration',
        pwHash,
        utcNowIso()
      );
    }
  }

  const staffPass = (process.env.HOSTEL_STAFF_PASSCODE || '').trim();
  if (staffPass) {
    const existing = db.prepare('SELECT id FROM users WHERE username = ?').get('staff_marcus');
    const pwHash = hashPassword(staffPass);
    if (existing) {
      db.prepare('UPDATE users SET password_hash = ?, is_active = 1 WHERE username = ?').run(
        pwHash,
        'staff_marcus'
      );
    } else {
      db.prepare(
        `INSERT INTO users (username, full_name, email, role, department, password_hash, is_active, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 1, ?)`
      ).run(
        'staff_marcus',
        'Marcus Vance',
        'mvance@campus-hostels.edu',
        'Maintenance Staff',
        'Electrical & Plumbing',
        pwHash,
        utcNowIso()
      );
    }
  }
}

export function seedSampleIfEmpty(db: Database.Database): {
  inserted: number;
  skipped: number;
  total: number;
} {
  const countRow = db.prepare('SELECT COUNT(*) AS count FROM complaints').get() as {
    count: number;
  };
  if (countRow.count > 0) {
    return { inserted: 0, skipped: countRow.count, total: countRow.count };
  }
  return seedSampleRecords(db, 'system');
}

export function seedSampleRecords(
  db: Database.Database,
  actor = 'admin'
): { inserted: number; skipped: number; total: number } {
  if (!fs.existsSync(SAMPLE_JSON_PATH)) {
    return { inserted: 0, skipped: 0, total: 0 };
  }
  const raw = fs.readFileSync(SAMPLE_JSON_PATH, 'utf-8');
  const records = JSON.parse(raw) as Array<Record<string, string | null>>;
  const now = utcNowIso();
  let inserted = 0;
  let skipped = 0;

  const insertComplaint = db.prepare(`
    INSERT INTO complaints (
      complaint_id, student_name, student_id, hostel_name,
      block_number, room_number, category, description,
      priority, submission_date, expected_resolution_date,
      status, assigned_staff, resolution_notes,
      in_progress_at, completed_at, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const insertHistory = db.prepare(`
    INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes, changed_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  const checkExists = db.prepare('SELECT 1 FROM complaints WHERE complaint_id = ?');

  const tx = db.transaction(() => {
    for (const item of records) {
      const cid = String(item.complaint_id || '').trim();
      if (!cid || checkExists.get(cid)) {
        skipped += 1;
        continue;
      }
      insertComplaint.run(
        cid,
        item.student_name,
        item.student_id,
        item.hostel_name,
        item.block_number,
        item.room_number,
        item.category,
        item.description,
        item.priority,
        item.submission_date,
        item.expected_resolution_date,
        item.status || 'Pending',
        item.assigned_staff || '',
        item.resolution_notes || '',
        item.in_progress_at || null,
        item.completed_at || null,
        item.created_at || now,
        item.updated_at || now
      );
      insertHistory.run(
        cid,
        null,
        item.status || 'Pending',
        actor,
        'Seeded from sample dataset',
        item.created_at || now
      );
      inserted += 1;
    }
    if (inserted > 0) {
      db.prepare(
        'INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)'
      ).run(
        'SEED_SAMPLE_DATA',
        actor,
        'complaints',
        `Inserted ${inserted} sample records (${skipped} skipped).`,
        now
      );
    }
  });
  tx();

  return { inserted, skipped, total: records.length };
}

export function sanitizeText(value: unknown): string {
  if (value === null || value === undefined) return '';
  return String(value).trim().replace(/\s+/g, ' ');
}

export function parseIsoDate(value: string): Date | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const [y, m, d] = value.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  if (
    dt.getUTCFullYear() !== y ||
    dt.getUTCMonth() !== m - 1 ||
    dt.getUTCDate() !== d
  ) {
    return null;
  }
  return dt;
}

export function validateComplaintPayload(
  payload: Record<string, unknown>,
  options: { requireComplaintId?: boolean } = {}
): { cleaned: Record<string, string | null>; errors: Record<string, string> } {
  const errors: Record<string, string> = {};
  const complaintId = sanitizeText(payload.complaint_id);
  const complaintIdRe = /^HMT-\d{4}-\d{4,6}$/;
  if (options.requireComplaintId) {
    if (!complaintId) errors.complaint_id = 'Complaint ID is required.';
    else if (!complaintIdRe.test(complaintId))
      errors.complaint_id = 'Complaint ID must match HMT-YYYY-NNNN.';
  } else if (complaintId && !complaintIdRe.test(complaintId)) {
    errors.complaint_id = 'Complaint ID must match HMT-YYYY-NNNN.';
  }

  const studentName = sanitizeText(payload.student_name);
  if (!studentName) errors.student_name = 'Student name is required.';
  else if (!/^[A-Za-z][A-Za-z\s'.-]{1,79}$/.test(studentName)) {
    errors.student_name =
      'Student name must be 2–80 characters (letters, spaces, hyphens, apostrophes).';
  }

  const studentId = sanitizeText(payload.student_id).toUpperCase();
  if (!studentId) errors.student_id = 'Student ID is required.';
  else if (!/^[A-Za-z0-9][A-Za-z0-9\-_]{2,23}$/.test(studentId)) {
    errors.student_id = 'Student ID must be 3–24 alphanumeric characters.';
  }

  const hostelName = sanitizeText(payload.hostel_name);
  if (!hostelName) errors.hostel_name = 'Hostel name is required.';
  else if (!/^[A-Za-z0-9][A-Za-z0-9\s&'.-]{1,79}$/.test(hostelName)) {
    errors.hostel_name = 'Hostel name must be 2–80 valid characters.';
  }

  const blockNumber = sanitizeText(payload.block_number).toUpperCase();
  if (!blockNumber) errors.block_number = 'Block number is required.';
  else if (!/^[A-Za-z0-9][A-Za-z0-9\s-]{0,15}$/.test(blockNumber)) {
    errors.block_number = 'Block number must be 1–16 alphanumeric characters.';
  }

  const roomNumber = sanitizeText(payload.room_number).toUpperCase();
  if (!roomNumber) errors.room_number = 'Room number is required.';
  else if (!/^[A-Za-z0-9][A-Za-z0-9\-]{0,11}$/.test(roomNumber)) {
    errors.room_number = 'Room number must be 1–12 alphanumeric characters (e.g., 104 or A-204).';
  }

  const category = sanitizeText(payload.category);
  if (!(ALLOWED_CATEGORIES as readonly string[]).includes(category)) {
    errors.category = `Category must be one of: ${ALLOWED_CATEGORIES.join(', ')}.`;
  }

  const description = sanitizeText(payload.description);
  if (!description) errors.description = 'Problem description is required.';
  else if (description.length < 10)
    errors.description = 'Problem description must be at least 10 characters.';
  else if (description.length > 1000)
    errors.description = 'Problem description cannot exceed 1000 characters.';

  const priority = sanitizeText(payload.priority);
  if (!(ALLOWED_PRIORITIES as readonly string[]).includes(priority)) {
    errors.priority = `Priority must be one of: ${ALLOWED_PRIORITIES.join(', ')}.`;
  }

  const submissionDate = sanitizeText(payload.submission_date);
  const subDt = parseIsoDate(submissionDate);
  if (!subDt) errors.submission_date = 'Submission date must be a valid YYYY-MM-DD date.';

  const expectedDate = sanitizeText(payload.expected_resolution_date);
  const expDt = parseIsoDate(expectedDate);
  if (!expDt) {
    errors.expected_resolution_date =
      'Expected resolution date must be a valid YYYY-MM-DD date.';
  } else if (subDt && expDt.getTime() < subDt.getTime()) {
    errors.expected_resolution_date =
      'Expected resolution date cannot be earlier than submission date.';
  }

  const status = sanitizeText(payload.status || 'Pending') || 'Pending';
  if (!(ALLOWED_STATUSES as readonly string[]).includes(status)) {
    errors.status = `Status must be one of: ${ALLOWED_STATUSES.join(', ')}.`;
  }

  return {
    cleaned: {
      complaint_id: complaintId,
      student_name: studentName,
      student_id: studentId,
      hostel_name: hostelName,
      block_number: blockNumber,
      room_number: roomNumber,
      category,
      description,
      priority,
      submission_date: submissionDate,
      expected_resolution_date: expectedDate,
      status,
      assigned_staff: sanitizeText(payload.assigned_staff).slice(0, 80),
      resolution_notes: sanitizeText(payload.resolution_notes).slice(0, 1000),
      in_progress_at: payload.in_progress_at ? String(payload.in_progress_at) : null,
      completed_at: payload.completed_at ? String(payload.completed_at) : null,
    },
    errors,
  };
}

export function evaluateRecordWarning(
  record: Pick<
    ComplaintRow,
    'status' | 'priority' | 'submission_date' | 'expected_resolution_date'
  >,
  referenceIsoDate?: string
): { warning_level: string; warning_reasons: string[] } {
  const todayStr = referenceIsoDate || new Date().toISOString().slice(0, 10);
  const todayDt = parseIsoDate(todayStr)!;
  const subDt = parseIsoDate(record.submission_date || '');
  const expDt = parseIsoDate(record.expected_resolution_date || '');
  const reasons: string[] = [];

  if (!subDt || !expDt) {
    return {
      warning_level: 'Attention Required',
      warning_reasons: ['Invalid or missing date format'],
    };
  }

  if (expDt.getTime() < subDt.getTime()) {
    return {
      warning_level: 'Critical',
      warning_reasons: ['Expected date precedes submission date'],
    };
  }

  if (record.status === 'Completed') {
    return { warning_level: 'Normal', warning_reasons: [] };
  }

  const msPerDay = 86400000;
  const daysOverdue = Math.round((todayDt.getTime() - expDt.getTime()) / msPerDay);
  const daysUntilDue = Math.round((expDt.getTime() - todayDt.getTime()) / msPerDay);
  const pendingAge = Math.round((todayDt.getTime() - subDt.getTime()) / msPerDay);

  if (daysOverdue > 3 || (record.priority === 'Critical' && daysOverdue > 0)) {
    reasons.push(`Overdue by ${daysOverdue} day${daysOverdue === 1 ? '' : 's'}`);
    if (record.priority === 'Critical') reasons.push('Critical priority');
    return { warning_level: 'Critical', warning_reasons: reasons };
  }

  if (record.priority === 'Critical') {
    reasons.push('Critical priority');
    if (daysUntilDue <= 1) reasons.push('Immediate deadline');
    return { warning_level: 'Critical', warning_reasons: reasons };
  }

  if (daysOverdue > 0) {
    reasons.push(`Overdue by ${daysOverdue} day${daysOverdue === 1 ? '' : 's'}`);
    return { warning_level: 'Overdue', warning_reasons: reasons };
  }

  if (daysUntilDue <= 2) {
    reasons.push(
      daysUntilDue === 0
        ? 'Due today'
        : `Due in ${daysUntilDue} day${daysUntilDue === 1 ? '' : 's'}`
    );
  }

  if (record.status === 'Pending' && pendingAge > 5) {
    reasons.push(`Pending for ${pendingAge} days`);
  }

  if (
    record.priority === 'High' &&
    daysUntilDue <= 3 &&
    !reasons.some((r) => r.startsWith('Due'))
  ) {
    reasons.push('High priority approaching target');
  }

  if (reasons.length > 0) {
    return { warning_level: 'Attention Required', warning_reasons: reasons };
  }

  return { warning_level: 'Normal', warning_reasons: [] };
}

export function enrichComplaint(row: ComplaintRow): ComplaintRow {
  const { warning_level, warning_reasons } = evaluateRecordWarning(row);
  return { ...row, warning_level, warning_reasons };
}

export function generateNextComplaintId(db: Database.Database, year: number): string {
  const prefix = `HMT-${year}-`;
  const rows = db
    .prepare('SELECT complaint_id FROM complaints WHERE complaint_id LIKE ?')
    .all(`${prefix}%`) as Array<{ complaint_id: string }>;
  let maxSeq = 0;
  for (const r of rows) {
    const seq = Number.parseInt(r.complaint_id.split('-').pop() || '0', 10);
    if (!Number.isNaN(seq) && seq > maxSeq) maxSeq = seq;
  }
  return `${prefix}${String(maxSeq + 1).padStart(4, '0')}`;
}

export function computeAnalyticsFromRows(rows: ComplaintRow[]) {
  const todayStr = new Date().toISOString().slice(0, 10);
  const todayDt = parseIsoDate(todayStr)!;
  const enriched = rows.map(enrichComplaint);
  const total = enriched.length;

  const statusBreakdown: Record<string, number> = {
    Pending: 0,
    'In Progress': 0,
    Completed: 0,
  };
  const categoryBreakdown: Record<string, number> = {};
  for (const c of ALLOWED_CATEGORIES) categoryBreakdown[c] = 0;
  const priorityBreakdown: Record<string, number> = {};
  for (const p of ALLOWED_PRIORITIES) priorityBreakdown[p] = 0;
  const warningBreakdown: Record<string, number> = {
    Normal: 0,
    'Attention Required': 0,
    Overdue: 0,
    Critical: 0,
  };
  const hostelBreakdown: Record<string, number> = {};
  const monthlyMap = new Map<
    string,
    { total: number; completed: number; pending: number; in_progress: number }
  >();
  const resolutionDays: number[] = [];
  let overdueTotal = 0;

  for (const rec of enriched) {
    statusBreakdown[rec.status] = (statusBreakdown[rec.status] || 0) + 1;
    categoryBreakdown[rec.category] = (categoryBreakdown[rec.category] || 0) + 1;
    priorityBreakdown[rec.priority] = (priorityBreakdown[rec.priority] || 0) + 1;
    const wl = rec.warning_level || 'Normal';
    warningBreakdown[wl] = (warningBreakdown[wl] || 0) + 1;
    hostelBreakdown[rec.hostel_name] = (hostelBreakdown[rec.hostel_name] || 0) + 1;

    if (rec.status !== 'Completed') {
      const expDt = parseIsoDate(rec.expected_resolution_date);
      if (expDt && expDt.getTime() < todayDt.getTime()) overdueTotal += 1;
    }

    const monthKey = rec.submission_date.slice(0, 7);
    if (!monthlyMap.has(monthKey)) {
      monthlyMap.set(monthKey, { total: 0, completed: 0, pending: 0, in_progress: 0 });
    }
    const m = monthlyMap.get(monthKey)!;
    m.total += 1;
    if (rec.status === 'Completed') m.completed += 1;
    else if (rec.status === 'In Progress') m.in_progress += 1;
    else m.pending += 1;

    if (rec.status === 'Completed') {
      const subDt = parseIsoDate(rec.submission_date);
      const compDate = (rec.completed_at || rec.updated_at || '').slice(0, 10);
      const compDt = parseIsoDate(compDate);
      if (subDt && compDt) {
        resolutionDays.push(Math.max(0, (compDt.getTime() - subDt.getTime()) / 86400000));
      }
    }
  }

  const avgResolutionDays =
    resolutionDays.length > 0
      ? Math.round(
          (resolutionDays.reduce((a, b) => a + b, 0) / resolutionDays.length) * 100
        ) / 100
      : 0;
  const completionPct =
    total > 0 ? Math.round((statusBreakdown.Completed / total) * 1000) / 10 : 0;

  const monthlyTrends = Array.from(monthlyMap.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([month, counts]) => ({ month, ...counts }));

  return {
    total_complaints: total,
    pending_complaints: statusBreakdown.Pending,
    in_progress_complaints: statusBreakdown['In Progress'],
    completed_complaints: statusBreakdown.Completed,
    overdue_complaints: overdueTotal,
    completion_percentage: completionPct,
    average_resolution_days: avgResolutionDays,
    status_breakdown: statusBreakdown,
    category_breakdown: categoryBreakdown,
    priority_breakdown: priorityBreakdown,
    warning_breakdown: warningBreakdown,
    hostel_breakdown: hostelBreakdown,
    monthly_trends: monthlyTrends,
  };
}

function escapeCsvCell(val: string): string {
  if (val.includes(',') || val.includes('"') || val.includes('\n') || val.includes('\r')) {
    return `"${val.replace(/"/g, '""')}"`;
  }
  return val;
}

export function serializeCsv(records: ComplaintRow[]): string {
  const header = EXPORT_COLUMNS.join(',');
  const lines = records.map((rec) =>
    EXPORT_COLUMNS.map((col) => {
      const raw = (rec as unknown as Record<string, unknown>)[col];
      return escapeCsvCell(raw === null || raw === undefined ? '' : String(raw));
    }).join(',')
  );
  return [header, ...lines].join('\n') + '\n';
}

export function parseCsvRows(csvText: string): { headers: string[]; rows: Record<string, string>[] } {
  const cleaned = csvText.replace(/^\uFEFF/, '');
  const records: string[][] = [];
  let currentRow: string[] = [];
  let currentField = '';
  let inQuotes = false;

  for (let i = 0; i < cleaned.length; i += 1) {
    const ch = cleaned[i];
    if (inQuotes) {
      if (ch === '"') {
        if (cleaned[i + 1] === '"') {
          currentField += '"';
          i += 1;
        } else {
          inQuotes = false;
        }
      } else {
        currentField += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === ',') {
      currentRow.push(currentField);
      currentField = '';
    } else if (ch === '\r') {
      if (cleaned[i + 1] === '\n') i += 1;
      currentRow.push(currentField);
      records.push(currentRow);
      currentRow = [];
      currentField = '';
    } else if (ch === '\n') {
      currentRow.push(currentField);
      records.push(currentRow);
      currentRow = [];
      currentField = '';
    } else {
      currentField += ch;
    }
  }
  if (currentField.length > 0 || currentRow.length > 0) {
    currentRow.push(currentField);
    records.push(currentRow);
  }

  const nonEmpty = records.filter((r) => r.some((cell) => cell.trim() !== ''));
  if (nonEmpty.length === 0) return { headers: [], rows: [] };
  const headers = nonEmpty[0].map((h) => h.trim());
  const rows = nonEmpty.slice(1).map((cells) => {
    const obj: Record<string, string> = {};
    headers.forEach((h, idx) => {
      if (h) obj[h] = (cells[idx] ?? '').trim();
    });
    return obj;
  });
  return { headers, rows };
}

export function resolveSafeExportPath(filename: string): string {
  fs.mkdirSync(EXPORTS_DIR, { recursive: true });
  const baseName = path.basename(filename);
  const resolved = path.resolve(EXPORTS_DIR, baseName);
  if (!resolved.startsWith(EXPORTS_DIR + path.sep)) {
    throw new Error('Invalid export path.');
  }
  return resolved;
}

export function buildReport(
  db: Database.Database,
  fmt: string,
  filters: { start_date?: string; end_date?: string; status?: string }
): { content: string; mimeType: string; filename: string } {
  const clauses: string[] = [];
  const params: string[] = [];
  if (filters.start_date) {
    clauses.push('submission_date >= ?');
    params.push(filters.start_date);
  }
  if (filters.end_date) {
    clauses.push('submission_date <= ?');
    params.push(filters.end_date);
  }
  const whereAnalytics = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  const analyticsRows = db
    .prepare(`SELECT * FROM complaints ${whereAnalytics} ORDER BY submission_date ASC`)
    .all(...params) as ComplaintRow[];
  const analytics = computeAnalyticsFromRows(analyticsRows);

  const recClauses = [...clauses];
  const recParams = [...params];
  if (filters.status) {
    recClauses.push('status = ?');
    recParams.push(filters.status);
  }
  const whereRecords = recClauses.length ? `WHERE ${recClauses.join(' AND ')}` : '';
  const records = (
    db
      .prepare(`SELECT * FROM complaints ${whereRecords} ORDER BY submission_date DESC, id DESC`)
      .all(...recParams) as ComplaintRow[]
  ).map(enrichComplaint);

  const generatedAt = utcNowIso();
  const stamp = generatedAt.slice(0, 10);
  const normalizedFmt = fmt.toLowerCase();

  let content = '';
  let mimeType = 'text/plain; charset=utf-8';
  let filename = `hostel_maintenance_report_${stamp}.txt`;

  if (normalizedFmt === 'csv') {
    content = serializeCsv(records);
    mimeType = 'text/csv; charset=utf-8';
    filename = `hostel_maintenance_report_${stamp}.csv`;
  } else if (normalizedFmt === 'json') {
    content = JSON.stringify(
      {
        report_generated_at: generatedAt,
        filters,
        executive_summary: {
          total_complaints: analytics.total_complaints,
          pending_complaints: analytics.pending_complaints,
          in_progress_complaints: analytics.in_progress_complaints,
          completed_complaints: analytics.completed_complaints,
          overdue_complaints: analytics.overdue_complaints,
          completion_percentage: analytics.completion_percentage,
          average_resolution_days: analytics.average_resolution_days,
          category_breakdown: analytics.category_breakdown,
          priority_breakdown: analytics.priority_breakdown,
        },
        records,
      },
      null,
      2
    );
    mimeType = 'application/json; charset=utf-8';
    filename = `hostel_maintenance_report_${stamp}.json`;
  } else if (normalizedFmt === 'markdown' || normalizedFmt === 'md') {
    const lines: string[] = [
      '# Hostel Maintenance Executive Report',
      '',
      `- **Report Generated:** ${generatedAt}`,
      `- **Date Range:** ${filters.start_date || 'All'} to ${filters.end_date || 'Present'}`,
      `- **Total Complaints:** ${analytics.total_complaints}`,
      `- **Pending:** ${analytics.pending_complaints}`,
      `- **In Progress:** ${analytics.in_progress_complaints}`,
      `- **Completed:** ${analytics.completed_complaints} (${analytics.completion_percentage}%)`,
      `- **Overdue:** ${analytics.overdue_complaints}`,
      `- **Average Resolution Time:** ${analytics.average_resolution_days} days`,
      '',
      '## Category Breakdown',
      '',
      '| Category | Count |',
      '| --- | ---: |',
      ...Object.entries(analytics.category_breakdown).map(([k, v]) => `| ${k} | ${v} |`),
      '',
      '## Priority Breakdown',
      '',
      '| Priority | Count |',
      '| --- | ---: |',
      ...Object.entries(analytics.priority_breakdown).map(([k, v]) => `| ${k} | ${v} |`),
      '',
      '## Maintenance Records',
      '',
      '| ID | Student | Hostel / Room | Category | Priority | Status | Warning | Expected |',
      '| --- | --- | --- | --- | --- | --- | --- | --- |',
      ...records.map(
        (r) =>
          `| ${r.complaint_id} | ${r.student_name} (${r.student_id}) | ${r.hostel_name} ${r.block_number}-${r.room_number} | ${r.category} | ${r.priority} | ${r.status} | ${r.warning_level} | ${r.expected_resolution_date} |`
      ),
    ];
    content = lines.join('\n') + '\n';
    mimeType = 'text/markdown; charset=utf-8';
    filename = `hostel_maintenance_report_${stamp}.md`;
  } else if (normalizedFmt === 'txt' || normalizedFmt === 'audit') {
    const auditRows = db
      .prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 100')
      .all() as Array<{
      created_at: string;
      actor: string;
      action: string;
      target_id: string;
      details: string;
    }>;
    const lines: string[] = [
      '==========================================================================',
      'HOSTEL MAINTENANCE TRACKER — PLAIN-TEXT EXECUTIVE & AUDIT REPORT',
      '==========================================================================',
      `Generated At       : ${generatedAt}`,
      `Date Filter        : ${filters.start_date || 'All'} -> ${filters.end_date || 'Present'}`,
      `Total Complaints   : ${analytics.total_complaints}`,
      `Pending            : ${analytics.pending_complaints}`,
      `In Progress        : ${analytics.in_progress_complaints}`,
      `Completed          : ${analytics.completed_complaints} (${analytics.completion_percentage}%)`,
      `Overdue            : ${analytics.overdue_complaints}`,
      `Avg Resolution     : ${analytics.average_resolution_days} days`,
      '',
      'CATEGORY BREAKDOWN:',
      ...Object.entries(analytics.category_breakdown).map(
        ([k, v]) => `  - ${k.padEnd(16)}: ${v}`
      ),
      '',
      'PRIORITY BREAKDOWN:',
      ...Object.entries(analytics.priority_breakdown).map(
        ([k, v]) => `  - ${k.padEnd(16)}: ${v}`
      ),
      '',
      'RELEVANT MAINTENANCE RECORDS:',
      '-'.repeat(74),
      ...records.map(
        (r) =>
          `[${r.complaint_id}] ${r.status.padEnd(11)} | ${r.priority.padEnd(8)} | ${(r.warning_level || 'Normal').padEnd(18)} | ${r.category.padEnd(14)} | ${r.hostel_name} ${r.block_number}-${r.room_number} | Due ${r.expected_resolution_date} | ${r.student_name}`
      ),
      '',
      'RECENT SYSTEM AUDIT TRAIL:',
      '-'.repeat(74),
      ...auditRows.map(
        (a) =>
          `${a.created_at} | ${a.actor.padEnd(14)} | ${a.action.padEnd(18)} | ${a.target_id} | ${a.details}`
      ),
    ];
    content = lines.join('\n') + '\n';
    mimeType = 'text/plain; charset=utf-8';
    filename = `hostel_audit_report_${stamp}.txt`;
  } else {
    throw new Error(`Unsupported report format: ${fmt}`);
  }

  const targetPath = resolveSafeExportPath(filename);
  fs.writeFileSync(targetPath, content, 'utf-8');
  return { content, mimeType, filename };
}
