import { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';
import type { ThemeId } from '../types';

const THEME_CHART_PALETTES: Record<
  ThemeId,
  {
    barColors: string[];
    lineTotal: string;
    lineFill: string;
    lineDone: string;
    statusColors: [string, string, string];
  }
> = {
  'indigo-horizon': {
    barColors: ['#4F46E5', '#2563EB', '#0284C7', '#0891B2', '#6366F1', '#3B82F6', '#06B6D4', '#7C3AED'],
    lineTotal: '#4F46E5',
    lineFill: 'rgba(79, 70, 229, 0.1)',
    lineDone: '#16A34A',
    statusColors: ['#D97706', '#2563EB', '#16A34A'],
  },
  'emerald-campus': {
    barColors: ['#059669', '#0D9488', '#0284C7', '#10B981', '#14B8A6', '#0EA5E9', '#16A34A', '#0891B2'],
    lineTotal: '#059669',
    lineFill: 'rgba(5, 150, 105, 0.1)',
    lineDone: '#0284C7',
    statusColors: ['#D97706', '#0284C7', '#059669'],
  },
  'sunset-courtyard': {
    barColors: ['#EA580C', '#E11D48', '#7C3AED', '#F59E0B', '#EC4899', '#8B5CF6', '#F97316', '#DB2777'],
    lineTotal: '#E11D48',
    lineFill: 'rgba(225, 29, 72, 0.1)',
    lineDone: '#059669',
    statusColors: ['#EA580C', '#7C3AED', '#059669'],
  },
  'violet-aurora': {
    barColors: ['#7C3AED', '#C026D3', '#06B6D4', '#8B5CF6', '#D946EF', '#0891B2', '#6366F1', '#EC4899'],
    lineTotal: '#7C3AED',
    lineFill: 'rgba(124, 58, 237, 0.1)',
    lineDone: '#0891B2',
    statusColors: ['#D97706', '#C026D3', '#059669'],
  },
};

interface StatusDoughnutProps {
  breakdown: Record<string, number>;
  themeId?: ThemeId;
}

export function StatusDoughnutChart({
  breakdown,
  themeId = 'indigo-horizon',
}: StatusDoughnutProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const palette = THEME_CHART_PALETTES[themeId];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const chart = new Chart(canvas, {
      type: 'doughnut',
      data: {
        labels: ['Pending', 'In Progress', 'Completed'],
        datasets: [
          {
            data: [
              breakdown['Pending'] || 0,
              breakdown['In Progress'] || 0,
              breakdown['Completed'] || 0,
            ],
            backgroundColor: palette.statusColors,
            borderColor: '#FFFFFF',
            borderWidth: 2,
            hoverOffset: 5,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '66%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              usePointStyle: true,
              boxWidth: 8,
              padding: 16,
              color: '#334155',
              font: { family: 'DM Sans, sans-serif', size: 12 },
            },
          },
        },
      },
    });
    return () => chart.destroy();
  }, [breakdown, palette]);

  return (
    <div className="relative h-64 w-full">
      <canvas ref={canvasRef} aria-label="Complaint status distribution chart" />
    </div>
  );
}

interface CategoryBarProps {
  breakdown: Record<string, number>;
  themeId?: ThemeId;
}

export function CategoryBarChart({
  breakdown,
  themeId = 'indigo-horizon',
}: CategoryBarProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const palette = THEME_CHART_PALETTES[themeId];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const labels = Object.keys(breakdown);
    const values = Object.values(breakdown);

    const chart = new Chart(canvas, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: 'Requests',
            data: values,
            backgroundColor: labels.map(
              (_, idx) => palette.barColors[idx % palette.barColors.length]
            ),
            borderRadius: 6,
            maxBarThickness: 36,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: {
              color: '#475569',
              font: { family: 'DM Sans, sans-serif', size: 11 },
            },
          },
          y: {
            beginAtZero: true,
            ticks: {
              precision: 0,
              color: '#64748B',
              font: { family: 'JetBrains Mono, monospace', size: 11 },
            },
            grid: { color: '#F1F5F9' },
          },
        },
      },
    });
    return () => chart.destroy();
  }, [breakdown, palette]);

  return (
    <div className="relative h-64 w-full">
      <canvas ref={canvasRef} aria-label="Complaint category distribution chart" />
    </div>
  );
}

interface MonthlyTrendsProps {
  trends: Array<{
    month: string;
    total: number;
    completed: number;
    pending: number;
    in_progress: number;
  }>;
  themeId?: ThemeId;
}

export function MonthlyTrendsLineChart({
  trends,
  themeId = 'indigo-horizon',
}: MonthlyTrendsProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const palette = THEME_CHART_PALETTES[themeId];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const chart = new Chart(canvas, {
      type: 'line',
      data: {
        labels: trends.map((t) => t.month),
        datasets: [
          {
            label: 'Total Logged',
            data: trends.map((t) => t.total),
            borderColor: palette.lineTotal,
            backgroundColor: palette.lineFill,
            fill: true,
            tension: 0.3,
            pointRadius: 4,
            pointBackgroundColor: palette.lineTotal,
          },
          {
            label: 'Completed',
            data: trends.map((t) => t.completed),
            borderColor: palette.lineDone,
            backgroundColor: 'transparent',
            tension: 0.3,
            pointRadius: 4,
            pointBackgroundColor: palette.lineDone,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              usePointStyle: true,
              boxWidth: 8,
              padding: 16,
              color: '#334155',
              font: { family: 'DM Sans, sans-serif', size: 12 },
            },
          },
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: {
              color: '#475569',
              font: { family: 'JetBrains Mono, monospace', size: 11 },
            },
          },
          y: {
            beginAtZero: true,
            ticks: {
              precision: 0,
              color: '#64748B',
              font: { family: 'JetBrains Mono, monospace', size: 11 },
            },
            grid: { color: '#F1F5F9' },
          },
        },
      },
    });
    return () => chart.destroy();
  }, [trends, palette]);

  return (
    <div className="relative h-64 w-full">
      <canvas ref={canvasRef} aria-label="Monthly complaint trends chart" />
    </div>
  );
}

interface PriorityChartProps {
  breakdown: Record<string, number>;
}

export function PriorityDistributionChart({ breakdown }: PriorityChartProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const chart = new Chart(canvas, {
      type: 'bar',
      data: {
        labels: ['Low', 'Medium', 'High', 'Critical'],
        datasets: [
          {
            label: 'Complaints',
            data: [
              breakdown['Low'] || 0,
              breakdown['Medium'] || 0,
              breakdown['High'] || 0,
              breakdown['Critical'] || 0,
            ],
            backgroundColor: ['#64748B', '#0284C7', '#D97706', '#DC2626'],
            borderRadius: 6,
            maxBarThickness: 28,
          },
        ],
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
        },
        scales: {
          x: {
            beginAtZero: true,
            ticks: {
              precision: 0,
              color: '#64748B',
              font: { family: 'JetBrains Mono, monospace', size: 11 },
            },
            grid: { color: '#F1F5F9' },
          },
          y: {
            grid: { display: false },
            ticks: {
              color: '#334155',
              font: { family: 'DM Sans, sans-serif', size: 12 },
            },
          },
        },
      },
    });
    return () => chart.destroy();
  }, [breakdown]);

  return (
    <div className="relative h-64 w-full">
      <canvas ref={canvasRef} aria-label="Priority distribution chart" />
    </div>
  );
}
