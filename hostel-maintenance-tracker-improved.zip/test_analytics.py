"""Unit tests for analytics calculations and threshold warning engine."""

import tempfile
import unittest
from datetime import date
from pathlib import Path

from backend.analytics import compute_analytics
from backend.complaint_service import list_complaints
from backend.database import init_db, seed_sample_data
from backend.warning_system import evaluate_record_warning, summarize_warnings


class TestAnalyticsAndWarnings(unittest.TestCase):
    def setUp(self) -> None:
        self.tmpdir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.tmpdir.name) / "test_analytics.db"
        init_db(self.db_path)
        seed_sample_data(db_path=self.db_path)

    def tearDown(self) -> None:
        self.tmpdir.cleanup()

    def test_analytics_metrics_on_40_sample_records(self) -> None:
        ref = date(2026, 11, 21)
        summary = compute_analytics(reference_date=ref, db_path=self.db_path)
        self.assertEqual(summary["total_complaints"], 40)
        self.assertEqual(
            summary["pending_complaints"]
            + summary["in_progress_complaints"]
            + summary["completed_complaints"],
            40,
        )
        self.assertGreater(summary["overdue_complaints"], 0)
        self.assertGreater(summary["average_resolution_days"], 0)
        self.assertGreaterEqual(len(summary["monthly_trends"]), 6)

    def test_overdue_and_critical_warning_generation(self) -> None:
        ref = date(2026, 11, 21)
        level, reasons = evaluate_record_warning(
            {
                "status": "Pending",
                "priority": "Critical",
                "submission_date": "2026-11-08",
                "expected_resolution_date": "2026-11-10",
            },
            reference_date=ref,
        )
        self.assertEqual(level, "Critical")
        self.assertTrue(any("Overdue" in r for r in reasons))

        items = list_complaints(per_page=100, db_path=self.db_path)["items"]
        summary = summarize_warnings(items, reference_date=ref)
        self.assertGreater(summary["counts"]["Critical"], 0)
        self.assertGreater(summary["counts"]["Overdue"], 0)


if __name__ == "__main__":
    unittest.main()
