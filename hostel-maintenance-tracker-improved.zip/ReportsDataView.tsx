import { useState, type ChangeEvent } from 'react';
import {
  Database,
  Download,
  FileCode2,
  FileSpreadsheet,
  FileText,
  RefreshCw,
  Upload,
} from 'lucide-react';
import { apiRequest, ApiError, downloadAuthenticatedFile } from '../api';
import { STATUSES, type AuthUser, type BulkImportResult } from '../types';

interface ReportsDataViewProps {
  token: string;
  user: AuthUser;
  onDataChanged: (message: string) => void;
}

export function ReportsDataView({ token, user, onDataChanged }: ReportsDataViewProps) {
  // Report generator state
  const [reportStart, setReportStart] = useState('');
  const [reportEnd, setReportEnd] = useState('');
  const [reportStatus, setReportStatus] = useState('');
  const [previewFormat, setPreviewFormat] = useState<string>('markdown');
  const [previewContent, setPreviewContent] = useState<string>('');
  const [previewFilename, setPreviewFilename] = useState<string>('');
  const [previewLoading, setPreviewLoading] = useState(false);

  // Bulk CSV import state
  const [csvFileName, setCsvFileName] = useState('');
  const [csvText, setCsvText] = useState('');
  const [importResult, setImportResult] = useState<BulkImportResult | null>(null);
  const [importing, setImporting] = useState(false);

  // JSON restore state
  const [jsonRestoreResult, setJsonRestoreResult] = useState<{
    success: boolean;
    error?: string;
    restored_count?: number;
    skipped_duplicates?: number;
    rejected_count?: number;
  } | null>(null);
  const [restoring, setRestoring] = useState(false);
  const [actionError, setActionError] = useState('');

  function buildReportUrl(fmt: string, preview = false) {
    const params = new URLSearchParams();
    if (reportStart) params.set('start_date', reportStart);
    if (reportEnd) params.set('end_date', reportEnd);
    if (reportStatus) params.set('status', reportStatus);
    if (preview) params.set('preview', '1');
    const qs = params.toString();
    return `/api/reports/${fmt}${qs ? `?${qs}` : ''}`;
  }

  async function handleDownloadReport(fmt: string) {
    setActionError('');
    try {
      await downloadAuthenticatedFile(
        buildReportUrl(fmt, false),
        token,
        `hostel_report.${fmt === 'markdown' ? 'md' : fmt}`
      );
      onDataChanged(`Downloaded ${fmt.toUpperCase()} report.`);
    } catch (err) {
      setActionError(err instanceof ApiError ? err.message : 'Report download failed.');
    }
  }

  async function handlePreviewReport(fmt: string) {
    setPreviewFormat(fmt);
    setPreviewLoading(true);
    setActionError('');
    try {
      const res = await apiRequest<{ filename: string; content: string }>(
        buildReportUrl(fmt, true),
        { token }
      );
      setPreviewContent(res.content);
      setPreviewFilename(res.filename);
    } catch (err) {
      setActionError(err instanceof ApiError ? err.message : 'Preview failed.');
    } finally {
      setPreviewLoading(false);
    }
  }

  function handleCsvFileSelect(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setCsvFileName(file.name);
    setImportResult(null);
    const reader = new FileReader();
    reader.onload = () => {
      setCsvText(typeof reader.result === 'string' ? reader.result : '');
    };
    reader.readAsText(file);
  }

  async function handleBulkImport() {
    if (!csvText.trim()) {
      setActionError('Please select a CSV file or paste CSV content first.');
      return;
    }
    setImporting(true);
    setActionError('');
    try {
      const res = await apiRequest<BulkImportResult>('/api/import/csv', {
        method: 'POST',
        token,
        body: { csv_text: csvText },
      });
      setImportResult(res);
      if (res.imported_count > 0) {
        onDataChanged(`Imported ${res.imported_count} complaint record(s) from CSV.`);
      }
    } catch (err) {
      if (err instanceof ApiError && err.status === 400) {
        try {
          const fallback = await fetch('/api/import/csv', {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${token}`,
              'X-Requested-With': 'XMLHttpRequest',
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ csv_text: csvText }),
          });
          const data = (await fallback.json()) as BulkImportResult;
          setImportResult(data);
        } catch {
          setActionError(err.message);
        }
      } else {
        setActionError(err instanceof ApiError ? err.message : 'CSV import failed.');
      }
    } finally {
      setImporting(false);
    }
  }

  function downloadErrorReportCsv() {
    if (!importResult || importResult.errors.length === 0) return;
    const header = 'row,complaint_id,error\n';
    const lines = importResult.errors.map(
      (e) =>
        `${e.row},"${(e.complaint_id || '').replace(/"/g, '""')}","${e.error.replace(/"/g, '""')}"`
    );
    const blob = new Blob([header + lines.join('\n') + '\n'], {
      type: 'text/csv;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'csv_import_errors.csv';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  function downloadCsvTemplate() {
    const sample = [
      'complaint_id,student_name,student_id,hostel_name,block_number,room_number,category,description,priority,submission_date,expected_resolution_date,status,assigned_staff',
      'HMT-2026-8001,Jordan Blake,STU-25001,North Wing Hall,A,A-105,Electrical,Desk lamp wall socket loose and sparks occasionally.,High,2026-11-21,2026-11-24,Pending,Marcus Vance',
    ].join('\n');
    const blob = new Blob([sample + '\n'], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'hostel_import_template.csv';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  async function handleJsonBackupDownload() {
    setActionError('');
    try {
      await downloadAuthenticatedFile('/api/backup/json', token, 'hostel_backup.json');
      onDataChanged('Downloaded full JSON backup archive.');
    } catch (err) {
      setActionError(err instanceof ApiError ? err.message : 'Backup download failed.');
    }
  }

  function handleJsonRestoreSelect(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setRestoring(true);
    setJsonRestoreResult(null);
    setActionError('');
    const reader = new FileReader();
    reader.onload = async () => {
      const jsonText = typeof reader.result === 'string' ? reader.result : '';
      try {
        const res = await apiRequest<{
          success: boolean;
          error?: string;
          restored_count: number;
          skipped_duplicates: number;
          rejected_count: number;
        }>('/api/backup/restore', {
          method: 'POST',
          token,
          body: { json_text: jsonText },
        });
        setJsonRestoreResult(res);
        if (res.restored_count > 0) {
          onDataChanged(`Restored ${res.restored_count} record(s) from JSON backup.`);
        }
      } catch (err) {
        setJsonRestoreResult({
          success: false,
          error: err instanceof ApiError ? err.message : 'Corrupted or invalid JSON backup.',
        });
      } finally {
        setRestoring(false);
      }
    };
    reader.readAsText(file);
  }

  async function handleReseedSample() {
    setActionError('');
    try {
      const res = await apiRequest<{ inserted: number; skipped: number; total: number }>(
        '/api/seed-sample',
        { method: 'POST', token }
      );
      onDataChanged(
        `Sample dataset verified: ${res.inserted} added, ${res.skipped} existing preserved.`
      );
    } catch (err) {
      setActionError(err instanceof ApiError ? err.message : 'Sample seeding failed.');
    }
  }

  return (
    <div className="space-y-6">
      {actionError && (
        <div
          role="alert"
          className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
        >
          {actionError}
        </div>
      )}

      {/* Multi-Format Report Generator */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div className="flex flex-wrap items-end justify-between gap-4 border-b border-slate-200 pb-4">
          <div>
            <h1 className="font-display text-lg font-bold text-slate-900">
              Multi-Format Report Export
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Generate executive summaries, category/priority breakdowns, and maintenance logs in CSV, JSON, Markdown, or Plain-Text audit formats.
            </p>
          </div>

          <div className="flex flex-wrap items-end gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Start Date</label>
              <input
                type="date"
                value={reportStart}
                onChange={(e) => setReportStart(e.target.value)}
                className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">End Date</label>
              <input
                type="date"
                value={reportEnd}
                onChange={(e) => setReportEnd(e.target.value)}
                className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Status Filter</label>
              <select
                value={reportStatus}
                onChange={(e) => setReportStatus(e.target.value)}
                className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs"
              >
                <option value="">All Statuses</option>
                {STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              fmt: 'csv',
              title: 'CSV Dataset',
              desc: 'Spreadsheet-ready UTF-8 records with timestamps',
              icon: FileSpreadsheet,
            },
            {
              fmt: 'json',
              title: 'JSON Executive Bundle',
              desc: 'Structured summary statistics plus full record array',
              icon: FileCode2,
            },
            {
              fmt: 'markdown',
              title: 'Markdown Report',
              desc: 'Formatted executive summary tables for documentation',
              icon: FileText,
            },
            {
              fmt: 'txt',
              title: 'Plain-Text Audit Log',
              desc: 'Human-readable summary and chronological audit trail',
              icon: FileText,
            },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.fmt}
                className="border border-slate-200 rounded-xl p-4 flex flex-col justify-between gap-4"
              >
                <div>
                  <div className="flex items-center gap-2 text-slate-900 font-semibold text-sm">
                    <Icon className="h-4 w-4 text-indigo-600" aria-hidden="true" />
                    <span>{item.title}</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1.5">{item.desc}</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleDownloadReport(item.fmt)}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg theme-btn-primary px-3 py-1.5 text-xs font-semibold cursor-pointer whitespace-nowrap"
                  >
                    <Download className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Download</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePreviewReport(item.fmt)}
                    className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer whitespace-nowrap"
                  >
                    Preview
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {(previewLoading || previewContent) && (
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <div className="bg-slate-50 border-b border-slate-200 px-4 py-2.5 flex items-center justify-between text-xs">
              <span className="font-mono font-medium text-slate-700">
                {previewFilename || `Preview (${previewFormat})`}
              </span>
              <button
                type="button"
                onClick={() => setPreviewContent('')}
                className="text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                Hide Preview
              </button>
            </div>
            <pre className="p-4 text-xs font-mono text-slate-800 bg-white overflow-x-auto max-h-80 leading-relaxed">
              {previewLoading ? 'Generating report preview...' : previewContent}
            </pre>
          </div>
        )}
      </section>

      {/* Admin-Only Data Persistence, Bulk CSV Import & JSON Backup/Restore */}
      {user.role === 'Administrator' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Bulk CSV Import */}
          <section className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="font-display text-base font-bold text-slate-900">
                  Bulk CSV Dataset Import
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Validates headers, dates, categories, priorities, and prevents duplicate complaint IDs.
                </p>
              </div>
              <button
                type="button"
                onClick={downloadCsvTemplate}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer whitespace-nowrap"
              >
                <Download className="h-3.5 w-3.5" aria-hidden="true" />
                <span>CSV Template</span>
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <label className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-slate-50 px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 cursor-pointer">
                <Upload className="h-3.5 w-3.5 text-indigo-600" aria-hidden="true" />
                <span>{csvFileName || 'Choose CSV File'}</span>
                <input
                  type="file"
                  accept=".csv,text/csv"
                  onChange={handleCsvFileSelect}
                  className="sr-only"
                />
              </label>

              <button
                type="button"
                disabled={importing || !csvText.trim()}
                onClick={handleBulkImport}
                className="inline-flex items-center gap-1.5 rounded-lg theme-btn-primary px-4 py-2 text-xs font-semibold disabled:opacity-50 cursor-pointer"
              >
                <Upload className="h-3.5 w-3.5" aria-hidden="true" />
                <span>{importing ? 'Validating & Importing...' : 'Run Bulk Import'}</span>
              </button>
            </div>

            <textarea
              rows={5}
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
              placeholder="Or paste CSV rows here (must include required headers: complaint_id, student_name, student_id, hostel_name, block_number, room_number, category, description, priority, submission_date, expected_resolution_date, status)..."
              className="w-full rounded-lg border border-slate-300 p-3 text-xs font-mono text-slate-800 focus:border-indigo-600 focus:outline-none"
            />

            {importResult && (
              <div className="border border-slate-200 rounded-xl p-4 space-y-3 bg-slate-50">
                <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-4 tabular-nums">
                    <span className="font-semibold text-slate-900">
                      Processed: {importResult.total_processed}
                    </span>
                    <span className="font-semibold text-emerald-700">
                      Imported: {importResult.imported_count}
                    </span>
                    <span className="font-semibold text-red-700">
                      Rejected: {importResult.rejected_count}
                    </span>
                  </div>
                  {importResult.errors.length > 0 && (
                    <button
                      type="button"
                      onClick={downloadErrorReportCsv}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-red-700 hover:underline cursor-pointer"
                    >
                      <Download className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Download Error Report CSV</span>
                    </button>
                  )}
                </div>

                {importResult.errors.length > 0 && (
                  <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-lg bg-white divide-y divide-slate-100 text-xs">
                    {importResult.errors.map((err, idx) => (
                      <div key={idx} className="px-3 py-2 flex items-start gap-3">
                        <span className="font-mono text-slate-500 shrink-0">Row {err.row}</span>
                        <span className="font-mono font-medium text-slate-800 shrink-0">
                          {err.complaint_id || 'N/A'}
                        </span>
                        <span className="text-red-700">{err.error}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </section>

          {/* JSON Backup, Restore & Sample Seeding */}
          <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-5">
            <div>
              <h2 className="font-display text-base font-bold text-slate-900">
                JSON Backup, Restore & Persistence
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Safely archive or restore records without overwriting existing SQLite entries.
              </p>
            </div>

            <div className="space-y-3">
              <button
                type="button"
                onClick={handleJsonBackupDownload}
                className="w-full inline-flex items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-xs font-semibold text-slate-800 hover:bg-slate-50 cursor-pointer"
              >
                <Database className="h-4 w-4 text-indigo-600" aria-hidden="true" />
                <span>Download Full JSON Backup</span>
              </button>

              <label className="w-full inline-flex items-center justify-center gap-2 rounded-lg border border-slate-300 bg-slate-50 px-4 py-2.5 text-xs font-semibold text-slate-800 hover:bg-slate-100 cursor-pointer">
                <Upload className="h-4 w-4 text-blue-600" aria-hidden="true" />
                <span>{restoring ? 'Validating JSON Backup...' : 'Restore from JSON Backup'}</span>
                <input
                  type="file"
                  accept=".json,application/json"
                  onChange={handleJsonRestoreSelect}
                  className="sr-only"
                />
              </label>

              {jsonRestoreResult && (
                <div
                  className={`rounded-lg border px-3.5 py-2.5 text-xs ${
                    jsonRestoreResult.success
                      ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                      : 'border-red-200 bg-red-50 text-red-700'
                  }`}
                >
                  {jsonRestoreResult.success
                    ? `Restored ${jsonRestoreResult.restored_count} record(s). Skipped ${jsonRestoreResult.skipped_duplicates} existing record(s) without overwriting.`
                    : jsonRestoreResult.error}
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-200 space-y-2">
              <span className="text-xs font-semibold text-slate-800 block">
                Sample Dataset Management (40 Records)
              </span>
              <p className="text-xs text-slate-500">
                Verify or re-populate missing sample records idempotently without creating duplicates.
              </p>
              <button
                type="button"
                onClick={handleReseedSample}
                className="w-full inline-flex items-center justify-center gap-2 rounded-lg border border-indigo-200 bg-indigo-50 px-4 py-2 text-xs font-semibold text-indigo-700 hover:bg-indigo-100 cursor-pointer"
              >
                <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Verify / Seed 40 Sample Records</span>
              </button>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
