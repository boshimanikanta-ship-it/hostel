"""CSV and JSON import, export, backup, and restoration utilities."""

import csv
import io
import json
from pathlib import Path
from typing import Any

from backend.database import get_connection, transaction, utc_now_iso
from backend.validation import validate_complaint_payload
from config import CSV_REQUIRED_COLUMNS, EXPORTS_DIR

EXPORT_COLUMNS = [
    "complaint_id",
    "student_name",
    "student_id",
    "hostel_name",
    "block_number",
    "room_number",
    "category",
    "description",
    "priority",
    "submission_date",
    "expected_resolution_date",
    "status",
    "assigned_staff",
    "resolution_notes",
    "in_progress_at",
    "completed_at",
    "created_at",
    "updated_at",
]


def _resolve_export_path(filename: str) -> Path:
    EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
    safe_name = Path(filename).name
    resolved = (EXPORTS_DIR / safe_name).resolve()
    if not str(resolved).startswith(str(EXPORTS_DIR.resolve()) + "/"):
        raise ValueError("Invalid export file path.")
    return resolved


def export_complaints_csv(
    records: list[dict[str, Any]], filename: str | None = None
) -> str:
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=EXPORT_COLUMNS, extrasaction="ignore")
    writer.writeheader()
    for rec in records:
        writer.writerow({col: rec.get(col, "") or "" for col in EXPORT_COLUMNS})
    content = buf.getvalue()
    if filename:
        target = _resolve_export_path(filename)
        target.write_text(content, encoding="utf-8")
    return content


def export_complaints_json(
    records: list[dict[str, Any]], filename: str | None = None
) -> str:
    payload = {
        "exported_at": utc_now_iso(),
        "record_count": len(records),
        "records": [
            {col: rec.get(col) for col in EXPORT_COLUMNS} for rec in records
        ],
    }
    content = json.dumps(payload, indent=2)
    if filename:
        target = _resolve_export_path(filename)
        target.write_text(content, encoding="utf-8")
    return content


def create_json_backup(
    db_path: Path | None = None, filename: str | None = None
) -> tuple[Path, str]:
    conn = get_connection(db_path)
    try:
        rows = conn.execute("SELECT * FROM complaints ORDER BY id ASC").fetchall()
    finally:
        conn.close()
    records = [dict(r) for r in rows]
    target_name = filename or f"hostel_backup_{utc_now_iso().replace(':', '-')}.json"
    content = export_complaints_json(records, filename=target_name)
    return _resolve_export_path(target_name), content


def import_csv_content(
    csv_text: str,
    *,
    actor: str = "admin",
    db_path: Path | None = None,
) -> dict[str, Any]:
    if not csv_text or not csv_text.strip():
        return {
            "imported_count": 0,
            "rejected_count": 0,
            "total_processed": 0,
            "errors": [{"row": 0, "complaint_id": "", "error": "CSV file is empty."}],
        }

    reader = csv.DictReader(io.StringIO(csv_text.lstrip("\ufeff")))
    if not reader.fieldnames:
        return {
            "imported_count": 0,
            "rejected_count": 0,
            "total_processed": 0,
            "errors": [{"row": 0, "complaint_id": "", "error": "Missing CSV header row."}],
        }

    headers = {h.strip() for h in reader.fieldnames if h}
    missing_cols = [col for col in CSV_REQUIRED_COLUMNS if col not in headers]
    if missing_cols:
        return {
            "imported_count": 0,
            "rejected_count": 0,
            "total_processed": 0,
            "errors": [
                {
                    "row": 0,
                    "complaint_id": "",
                    "error": f"Missing required CSV columns: {', '.join(missing_cols)}",
                }
            ],
        }

    conn = get_connection(db_path)
    try:
        existing_ids = {
            r["complaint_id"]
            for r in conn.execute("SELECT complaint_id FROM complaints").fetchall()
        }
    finally:
        conn.close()

    seen_in_file: set[str] = set()
    valid_rows: list[dict[str, Any]] = []
    row_errors: list[dict[str, Any]] = []
    total_processed = 0

    for idx, raw_row in enumerate(reader, start=2):
        total_processed += 1
        normalized_row = {
            k.strip(): (v.strip() if isinstance(v, str) else v)
            for k, v in raw_row.items()
            if k
        }
        cid = normalized_row.get("complaint_id", "")
        cleaned, errs = validate_complaint_payload(
            normalized_row, require_complaint_id=True, allow_any_status=True
        )
        if errs:
            row_errors.append(
                {
                    "row": idx,
                    "complaint_id": cid,
                    "error": "; ".join(f"{k}: {v}" for k, v in errs.items()),
                }
            )
            continue

        if cleaned["complaint_id"] in existing_ids:
            row_errors.append(
                {
                    "row": idx,
                    "complaint_id": cleaned["complaint_id"],
                    "error": "Duplicate complaint_id already exists in database.",
                }
            )
            continue

        if cleaned["complaint_id"] in seen_in_file:
            row_errors.append(
                {
                    "row": idx,
                    "complaint_id": cleaned["complaint_id"],
                    "error": "Duplicate complaint_id within uploaded CSV file.",
                }
            )
            continue

        seen_in_file.add(cleaned["complaint_id"])
        valid_rows.append(cleaned)

    now = utc_now_iso()
    if valid_rows:
        with transaction(db_path) as conn:
            for item in valid_rows:
                status = item["status"]
                in_prog = item.get("in_progress_at") or (
                    now if status in ("In Progress", "Completed") else None
                )
                comp_at = item.get("completed_at") or (
                    now if status == "Completed" else None
                )
                conn.execute(
                    """
                    INSERT INTO complaints (
                        complaint_id, student_name, student_id, hostel_name,
                        block_number, room_number, category, description,
                        priority, submission_date, expected_resolution_date,
                        status, assigned_staff, resolution_notes,
                        in_progress_at, completed_at, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        item["complaint_id"],
                        item["student_name"],
                        item["student_id"],
                        item["hostel_name"],
                        item["block_number"],
                        item["room_number"],
                        item["category"],
                        item["description"],
                        item["priority"],
                        item["submission_date"],
                        item["expected_resolution_date"],
                        status,
                        item.get("assigned_staff", ""),
                        item.get("resolution_notes", ""),
                        in_prog,
                        comp_at,
                        now,
                        now,
                    ),
                )
                conn.execute(
                    """
                    INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes, changed_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (item["complaint_id"], None, status, actor, "Imported via CSV bulk upload", now),
                )
            conn.execute(
                "INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)",
                (
                    "CSV_BULK_IMPORT",
                    actor,
                    "complaints",
                    f"Imported {len(valid_rows)} records, rejected {len(row_errors)} records.",
                    now,
                ),
            )

    return {
        "imported_count": len(valid_rows),
        "rejected_count": len(row_errors),
        "total_processed": total_processed,
        "errors": row_errors,
    }


def restore_json_backup(
    json_text: str,
    *,
    actor: str = "admin",
    db_path: Path | None = None,
) -> dict[str, Any]:
    """Safely restore complaints from a JSON backup without destroying existing records."""
    try:
        parsed = json.loads(json_text)
    except json.JSONDecodeError as exc:
        return {
            "success": False,
            "error": f"Corrupted or invalid JSON structure: {exc.msg} (line {exc.lineno}).",
            "restored_count": 0,
            "skipped_duplicates": 0,
            "rejected_count": 0,
            "errors": [],
        }

    if isinstance(parsed, dict) and isinstance(parsed.get("records"), list):
        records = parsed["records"]
    elif isinstance(parsed, list):
        records = parsed
    else:
        return {
            "success": False,
            "error": "JSON must be a list of records or a backup object with a 'records' array.",
            "restored_count": 0,
            "skipped_duplicates": 0,
            "rejected_count": 0,
            "errors": [],
        }

    conn = get_connection(db_path)
    try:
        existing_ids = {
            r["complaint_id"]
            for r in conn.execute("SELECT complaint_id FROM complaints").fetchall()
        }
    finally:
        conn.close()

    to_insert: list[dict[str, Any]] = []
    skipped_duplicates = 0
    errors: list[dict[str, Any]] = []
    seen_ids: set[str] = set()

    for idx, raw in enumerate(records, start=1):
        if not isinstance(raw, dict):
            errors.append({"row": idx, "complaint_id": "", "error": "Record is not a JSON object."})
            continue
        cleaned, errs = validate_complaint_payload(
            raw, require_complaint_id=True, allow_any_status=True
        )
        if errs:
            errors.append(
                {
                    "row": idx,
                    "complaint_id": str(raw.get("complaint_id", "")),
                    "error": "; ".join(f"{k}: {v}" for k, v in errs.items()),
                }
            )
            continue
        cid = cleaned["complaint_id"]
        if cid in existing_ids or cid in seen_ids:
            skipped_duplicates += 1
            continue
        seen_ids.add(cid)
        to_insert.append(cleaned)

    now = utc_now_iso()
    if to_insert:
        with transaction(db_path) as conn:
            for item in to_insert:
                status = item["status"]
                in_progress_at = item.get("in_progress_at") or (
                    now if status in ("In Progress", "Completed") else None
                )
                completed_at = item.get("completed_at") or (
                    now if status == "Completed" else None
                )
                conn.execute(
                    """
                    INSERT INTO complaints (
                        complaint_id, student_name, student_id, hostel_name,
                        block_number, room_number, category, description,
                        priority, submission_date, expected_resolution_date,
                        status, assigned_staff, resolution_notes,
                        in_progress_at, completed_at, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        item["complaint_id"],
                        item["student_name"],
                        item["student_id"],
                        item["hostel_name"],
                        item["block_number"],
                        item["room_number"],
                        item["category"],
                        item["description"],
                        item["priority"],
                        item["submission_date"],
                        item["expected_resolution_date"],
                        item["status"],
                        item.get("assigned_staff", ""),
                        item.get("resolution_notes", ""),
                        in_progress_at,
                        completed_at,
                        now,
                        now,
                    ),
                )
                conn.execute(
                    """INSERT INTO status_history
                       (complaint_id, old_status, new_status, changed_by, notes, changed_at)
                       VALUES (?, NULL, ?, ?, ?, ?)""",
                    (item["complaint_id"], status, actor, "Restored from JSON backup", now),
                )
            conn.execute(
                "INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)",
                (
                    "JSON_RESTORE",
                    actor,
                    "complaints",
                    f"Restored {len(to_insert)} records ({skipped_duplicates} existing preserved).",
                    now,
                ),
            )

    return {
        "success": True,
        "restored_count": len(to_insert),
        "skipped_duplicates": skipped_duplicates,
        "rejected_count": len(errors),
        "errors": errors,
    }
