import { useEffect, useState, type FormEvent } from 'react';
import { CheckCircle2, ClipboardPlus } from 'lucide-react';
import { apiRequest, ApiError } from '../api';
import {
  CATEGORIES,
  HOSTEL_OPTIONS,
  PRIORITIES,
  type Complaint,
  type StaffDirectoryItem,
} from '../types';

interface RegisterComplaintViewProps {
  token: string;
  staffDirectory: StaffDirectoryItem[];
  onCreated: (complaint: Complaint) => void;
}

export function RegisterComplaintView({
  token,
  staffDirectory,
  onCreated,
}: RegisterComplaintViewProps) {
  const todayIso = new Date().toISOString().slice(0, 10);
  const defaultExpected = new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10);

  const [nextIdPreview, setNextIdPreview] = useState('HMT-2026-XXXX');
  const [studentName, setStudentName] = useState('');
  const [studentId, setStudentId] = useState('');
  const [hostelName, setHostelName] = useState<string>(HOSTEL_OPTIONS[0]);
  const [blockNumber, setBlockNumber] = useState('A');
  const [roomNumber, setRoomNumber] = useState('');
  const [category, setCategory] = useState<string>(CATEGORIES[0]);
  const [priority, setPriority] = useState<string>('Medium');
  const [submissionDate, setSubmissionDate] = useState(todayIso);
  const [expectedDate, setExpectedDate] = useState(defaultExpected);
  const [assignedStaff, setAssignedStaff] = useState('');
  const [description, setDescription] = useState('');

  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const year = submissionDate.slice(0, 4) || String(new Date().getFullYear());
    apiRequest<{ next_id: string }>(`/api/complaints/next-id?year=${year}`, { token })
      .then((res) => setNextIdPreview(res.next_id))
      .catch(() => {});
  }, [token, submissionDate]);

  function runClientValidation(): Record<string, string> {
    const errs: Record<string, string> = {};
    if (!studentName.trim()) {
      errs.student_name = 'Student name is required.';
    } else if (!/^[A-Za-z][A-Za-z\s'.-]{1,79}$/.test(studentName.trim())) {
      errs.student_name = 'Use 2–80 valid name characters (letters, spaces, hyphens).';
    }
    if (!studentId.trim()) {
      errs.student_id = 'Student ID is required.';
    } else if (!/^[A-Za-z0-9][A-Za-z0-9\-_]{2,23}$/.test(studentId.trim())) {
      errs.student_id = 'Student ID must be 3–24 alphanumeric characters.';
    }
    if (!blockNumber.trim()) {
      errs.block_number = 'Block number is required.';
    }
    if (!roomNumber.trim()) {
      errs.room_number = 'Room number is required.';
    } else if (!/^[A-Za-z0-9][A-Za-z0-9\-]{0,11}$/.test(roomNumber.trim())) {
      errs.room_number = 'Room number must be alphanumeric (e.g. 104 or A-204).';
    }
    if (!description.trim() || description.trim().length < 10) {
      errs.description = 'Problem description must be at least 10 characters.';
    } else if (description.trim().length > 1000) {
      errs.description = 'Problem description cannot exceed 1000 characters.';
    }
    if (!submissionDate) {
      errs.submission_date = 'Submission date is required.';
    }
    if (!expectedDate) {
      errs.expected_resolution_date = 'Expected resolution date is required.';
    } else if (submissionDate && expectedDate < submissionDate) {
      errs.expected_resolution_date =
        'Expected resolution date cannot be earlier than submission date.';
    }
    return errs;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError('');
    const clientErrs = runClientValidation();
    if (Object.keys(clientErrs).length > 0) {
      setFieldErrors(clientErrs);
      return;
    }

    setFieldErrors({});
    setSubmitting(true);
    try {
      const created = await apiRequest<Complaint>('/api/complaints', {
        method: 'POST',
        token,
        body: {
          student_name: studentName.trim(),
          student_id: studentId.trim(),
          hostel_name: hostelName.trim(),
          block_number: blockNumber.trim(),
          room_number: roomNumber.trim(),
          category,
          priority,
          submission_date: submissionDate,
          expected_resolution_date: expectedDate,
          assigned_staff: assignedStaff,
          description: description.trim(),
          status: 'Pending',
        },
      });
      setStudentName('');
      setStudentId('');
      setRoomNumber('');
      setDescription('');
      setAssignedStaff('');
      onCreated(created);
    } catch (err) {
      if (err instanceof ApiError && err.fieldErrors) {
        setFieldErrors(err.fieldErrors);
      } else {
        setFormError(err instanceof ApiError ? err.message : 'Unable to register complaint.');
      }
    } finally {
      setSubmitting(false);
    }
  }

  const staffOptions = staffDirectory.filter((u) => u.role === 'Maintenance Staff');

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-lg font-bold text-slate-900">
              Register Maintenance Request
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              All fields are validated client-side and server-side before committing to SQLite.
            </p>
          </div>
          <div className="text-right">
            <span className="block text-xs text-slate-500">Auto-Assigned Complaint ID</span>
            <span className="font-mono text-sm font-semibold text-indigo-700 tabular-nums">
              {nextIdPreview}
            </span>
          </div>
        </div>

        <form onSubmit={handleSubmit} noValidate className="p-6 space-y-6">
          {formError && (
            <div
              role="alert"
              className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
            >
              {formError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label htmlFor="reg-student-name" className="block text-xs font-medium text-slate-700 mb-1">
                Student Name *
              </label>
              <input
                id="reg-student-name"
                type="text"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                placeholder="e.g. Aarav Patel"
                className="w-full rounded-lg border border-slate-300 px-3.5 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
              />
              {fieldErrors.student_name && (
                <p className="mt-1 text-xs text-red-600">{fieldErrors.student_name}</p>
              )}
            </div>

            <div>
              <label htmlFor="reg-student-id" className="block text-xs font-medium text-slate-700 mb-1">
                Student ID *
              </label>
              <input
                id="reg-student-id"
                type="text"
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
                placeholder="e.g. STU-24501"
                className="w-full rounded-lg border border-slate-300 px-3.5 py-2 text-sm font-mono text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
              />
              {fieldErrors.student_id && (
                <p className="mt-1 text-xs text-red-600">{fieldErrors.student_id}</p>
              )}
            </div>

            <div>
              <label htmlFor="reg-hostel" className="block text-xs font-medium text-slate-700 mb-1">
                Hostel Name *
              </label>
              <select
                id="reg-hostel"
                value={hostelName}
                onChange={(e) => setHostelName(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
              >
                {HOSTEL_OPTIONS.map((h) => (
                  <option key={h} value={h}>
                    {h}
                  </option>
                ))}
              </select>
              {fieldErrors.hostel_name && (
                <p className="mt-1 text-xs text-red-600">{fieldErrors.hostel_name}</p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="reg-block" className="block text-xs font-medium text-slate-700 mb-1">
                  Block Number *
                </label>
                <input
                  id="reg-block"
                  type="text"
                  value={blockNumber}
                  onChange={(e) => setBlockNumber(e.target.value)}
                  placeholder="e.g. A"
                  className="w-full rounded-lg border border-slate-300 px-3.5 py-2 text-sm font-mono text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
                />
                {fieldErrors.block_number && (
                  <p className="mt-1 text-xs text-red-600">{fieldErrors.block_number}</p>
                )}
              </div>
              <div>
                <label htmlFor="reg-room" className="block text-xs font-medium text-slate-700 mb-1">
                  Room Number *
                </label>
                <input
                  id="reg-room"
                  type="text"
                  value={roomNumber}
                  onChange={(e) => setRoomNumber(e.target.value)}
                  placeholder="e.g. A-204"
                  className="w-full rounded-lg border border-slate-300 px-3.5 py-2 text-sm font-mono text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
                />
                {fieldErrors.room_number && (
                  <p className="mt-1 text-xs text-red-600">{fieldErrors.room_number}</p>
                )}
              </div>
            </div>

            <div>
              <label htmlFor="reg-category" className="block text-xs font-medium text-slate-700 mb-1">
                Complaint Category *
              </label>
              <select
                id="reg-category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
              {fieldErrors.category && (
                <p className="mt-1 text-xs text-red-600">{fieldErrors.category}</p>
              )}
            </div>

            <div>
              <label htmlFor="reg-priority" className="block text-xs font-medium text-slate-700 mb-1">
                Priority Level *
              </label>
              <select
                id="reg-priority"
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
              >
                {PRIORITIES.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
              {fieldErrors.priority && (
                <p className="mt-1 text-xs text-red-600">{fieldErrors.priority}</p>
              )}
            </div>

            <div>
              <label htmlFor="reg-sub-date" className="block text-xs font-medium text-slate-700 mb-1">
                Submission Date *
              </label>
              <input
                id="reg-sub-date"
                type="date"
                value={submissionDate}
                onChange={(e) => setSubmissionDate(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3.5 py-2 text-sm font-mono text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
              />
              {fieldErrors.submission_date && (
                <p className="mt-1 text-xs text-red-600">{fieldErrors.submission_date}</p>
              )}
            </div>

            <div>
              <label htmlFor="reg-exp-date" className="block text-xs font-medium text-slate-700 mb-1">
                Expected Resolution Date *
              </label>
              <input
                id="reg-exp-date"
                type="date"
                value={expectedDate}
                onChange={(e) => setExpectedDate(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3.5 py-2 text-sm font-mono text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
              />
              {fieldErrors.expected_resolution_date && (
                <p className="mt-1 text-xs text-red-600">{fieldErrors.expected_resolution_date}</p>
              )}
            </div>

            <div>
              <label htmlFor="reg-staff" className="block text-xs font-medium text-slate-700 mb-1">
                Assign Maintenance Staff (Optional)
              </label>
              <select
                id="reg-staff"
                value={assignedStaff}
                onChange={(e) => setAssignedStaff(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
              >
                <option value="">Unassigned (Open Queue)</option>
                {staffOptions.map((s) => (
                  <option key={s.username} value={s.full_name}>
                    {s.full_name} ({s.department})
                  </option>
                ))}
                <option value="Marcus Vance">Marcus Vance (Electrical & Plumbing)</option>
                <option value="Devon Brooks">Devon Brooks (Plumbing & Water)</option>
                <option value="Priya Nair">Priya Nair (Network & Systems)</option>
                <option value="Elena Rostova">Elena Rostova (Carpentry & Fixtures)</option>
                <option value="Tariq Al-Mansoor">Tariq Al-Mansoor (Sanitation)</option>
              </select>
            </div>

            <div>
              <span className="block text-xs font-medium text-slate-700 mb-1">
                Initial Complaint Status
              </span>
              <div className="h-[38px] rounded-lg border border-slate-200 bg-slate-50 px-3.5 flex items-center gap-2 text-sm text-amber-700 font-medium">
                <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                <span>Pending</span>
              </div>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="reg-description" className="block text-xs font-medium text-slate-700">
                Problem Description *
              </label>
              <span className="text-xs font-mono text-slate-400 tabular-nums">
                {description.length}/1000
              </span>
            </div>
            <textarea
              id="reg-description"
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the exact maintenance issue, affected fixtures, and any immediate safety observations (minimum 10 characters)..."
              className="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
            />
            {fieldErrors.description && (
              <p className="mt-1 text-xs text-red-600">{fieldErrors.description}</p>
            )}
          </div>

          <div className="pt-2 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => {
                setStudentName('');
                setStudentId('');
                setRoomNumber('');
                setDescription('');
                setFieldErrors({});
                setFormError('');
              }}
              className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Reset Form
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex items-center gap-2 rounded-lg theme-btn-primary px-5 py-2 text-sm font-semibold disabled:opacity-60 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <ClipboardPlus className="h-4 w-4" aria-hidden="true" />
              <span>{submitting ? 'Submitting...' : 'Submit Maintenance Request'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
