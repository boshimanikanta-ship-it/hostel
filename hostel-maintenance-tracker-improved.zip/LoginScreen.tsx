import { useState, type FormEvent } from 'react';
import { Building2, Lock, Quote, ShieldCheck, UserCheck, Wrench } from 'lucide-react';
import { apiRequest, ApiError } from '../api';
import type { AuthUser, ThemeId } from '../types';
import { BrandEmblem3D, BrandTitle3D } from './BrandTitle3D';
import { ThemeSelector } from './ThemeSelector';

interface LoginScreenProps {
  initialized: boolean;
  envConfigured: boolean;
  theme: ThemeId;
  onThemeChange: (theme: ThemeId) => void;
  onAuthenticated: (token: string, user: AuthUser) => void;
}

export function LoginScreen({
  initialized,
  envConfigured,
  theme,
  onThemeChange,
  onAuthenticated,
}: LoginScreenProps) {
  const [mode, setMode] = useState<'login' | 'setup'>(
    !initialized && !envConfigured ? 'setup' : 'login'
  );
  const [imgFailed, setImgFailed] = useState(false);

  // Login form state
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  // First-run setup form state
  const [adminUsername, setAdminUsername] = useState('admin');
  const [adminFullName, setAdminFullName] = useState('Dr. Elena Mercer');
  const [adminPassword, setAdminPassword] = useState('');
  const [staffUsername, setStaffUsername] = useState('staff_marcus');
  const [staffFullName, setStaffFullName] = useState('Marcus Vance');
  const [staffPassword, setStaffPassword] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  async function handleLogin(e: FormEvent) {
    e.preventDefault();
    setErrorMsg('');
    if (!username.trim() || !password) {
      setErrorMsg('Please enter both username and password.');
      return;
    }
    setSubmitting(true);
    try {
      const res = await apiRequest<{ token: string; user: AuthUser }>('/api/auth/login', {
        method: 'POST',
        body: { username: username.trim(), password },
      });
      onAuthenticated(res.token, res.user);
    } catch (err) {
      setErrorMsg(err instanceof ApiError ? err.message : 'Unable to sign in.');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleSetup(e: FormEvent) {
    e.preventDefault();
    setErrorMsg('');
    if (!adminUsername.trim() || adminPassword.length < 6) {
      setErrorMsg('Administrator username and password (minimum 6 characters) are required.');
      return;
    }
    if (staffPassword && staffPassword.length < 6) {
      setErrorMsg('Optional staff password must be at least 6 characters.');
      return;
    }
    setSubmitting(true);
    try {
      const res = await apiRequest<{ token: string; user: AuthUser }>('/api/auth/setup', {
        method: 'POST',
        body: {
          admin_username: adminUsername.trim(),
          admin_full_name: adminFullName.trim(),
          admin_password: adminPassword,
          staff_username: staffUsername.trim(),
          staff_full_name: staffFullName.trim(),
          staff_password: staffPassword,
        },
      });
      onAuthenticated(res.token, res.user);
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        setMode('login');
      }
      setErrorMsg(err instanceof ApiError ? err.message : 'Setup failed.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen app-canvas-bg text-slate-900 flex flex-col">
      <header className="w-full border-b border-slate-200/80 bg-white/85 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-6 py-3.5 flex items-center justify-between gap-8">
          <div className="flex items-center gap-3 whitespace-nowrap shrink-0">
            <BrandEmblem3D size="md" />
            <BrandTitle3D variant="header" />
          </div>

          <div className="hidden lg:flex items-center gap-6 text-sm text-slate-600">
            <span>Campus Facilities Administration</span>
            <span aria-hidden="true">·</span>
            <span>SQLite + CSV / JSON Persistence</span>
          </div>

          <div className="shrink-0">
            <ThemeSelector theme={theme} onChange={onThemeChange} />
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
        {/* Left editorial & architectural showcase */}
        <section className="lg:col-span-7 flex flex-col justify-between bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="relative h-64 sm:h-80 w-full bg-slate-900 overflow-hidden">
            {!imgFailed ? (
              <img
                src="/src/assets/images/campus_hostel_architecture_1795267070027.jpg"
                alt="Modern campus residential hostel building exterior"
                referrerPolicy="no-referrer"
                onError={() => setImgFailed(true)}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="h-full w-full bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-800 flex items-center justify-center">
                <Building2 className="h-16 w-16 text-indigo-300" aria-hidden="true" />
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/45 to-transparent flex flex-col justify-end p-6 sm:p-8">
              <p className="text-xs font-medium text-cyan-200 tracking-wide mb-2">
                Campus Housing Operations · Python for Good Project
              </p>
              <h1 className="mb-2">
                <BrandTitle3D variant="hero" />
              </h1>
              <p className="text-sm sm:text-base font-medium text-slate-200 leading-snug max-w-xl">
                Unified hostel maintenance tracking, threshold alerts, and audit reporting.
              </p>
            </div>
          </div>

          <div className="p-6 sm:p-8 space-y-6">
            <div className="rounded-xl p-4 border border-slate-200 bg-[var(--accent-soft)]/70 flex items-start gap-3">
              <Quote className="h-5 w-5 shrink-0 mt-0.5 text-[var(--accent-ink)]" aria-hidden="true" />
              <div>
                <p className="text-sm font-medium text-slate-800 leading-relaxed">
                  “Well-kept student halls do more than preserve buildings—they protect peace of mind, late-night study focus, and a welcoming campus home.”
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Campus Residential Stewardship · Python for Good Initiative
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <div className="flex items-center gap-2 text-[var(--accent-ink)] font-semibold text-sm mb-1.5">
                  <ShieldCheck className="h-4 w-4" aria-hidden="true" />
                  <span>Administrator Console</span>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed">
                  Register requests, manage staff assignments, audit overdue SLA thresholds, bulk-import CSV records, and export formatted reports.
                </p>
              </div>
              <div>
                <div className="flex items-center gap-2 text-blue-700 font-semibold text-sm mb-1.5">
                  <Wrench className="h-4 w-4" aria-hidden="true" />
                  <span>Maintenance Staff Queue</span>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed">
                  View assigned residential hall work orders, transition statuses from Pending to Completed, and record technical resolution notes.
                </p>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-200 bg-slate-50/80 px-6 sm:px-8 py-4 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-slate-600">
            <span>40 Pre-Loaded Campus Records</span>
            <span aria-hidden="true">·</span>
            <span>CSV / JSON / Markdown / TXT Exports</span>
            <span aria-hidden="true">·</span>
            <span>Companion Python CLI Included</span>
          </div>
        </section>

        {/* Right Authentication / First-Run Claim Panel */}
        <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col justify-between">
          <div className="h-1.5 w-full theme-gradient-bar" />
          <div className="p-6 sm:p-8 flex-1 flex flex-col justify-center">
          {mode === 'setup' ? (
            <div>
              <div className="mb-6">
                <h2 className="font-display text-xl font-bold text-slate-900">
                  Initialize Campus Workspace
                </h2>
                <p className="text-sm text-slate-600 mt-1">
                  Set your Administrator credentials to unlock the dashboard. Passwords are salted and hashed with scrypt on the server.
                </p>
              </div>

              {errorMsg && (
                <div
                  role="alert"
                  className="mb-5 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
                >
                  {errorMsg}
                </div>
              )}

              <form onSubmit={handleSetup} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="setup-admin-user" className="block text-xs font-medium text-slate-700 mb-1">
                      Admin Username
                    </label>
                    <input
                      id="setup-admin-user"
                      type="text"
                      value={adminUsername}
                      onChange={(e) => setAdminUsername(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="setup-admin-name" className="block text-xs font-medium text-slate-700 mb-1">
                      Administrator Name
                    </label>
                    <input
                      id="setup-admin-name"
                      type="text"
                      value={adminFullName}
                      onChange={(e) => setAdminFullName(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="setup-admin-pass" className="block text-xs font-medium text-slate-700 mb-1">
                    Administrator Password (min 6 chars)
                  </label>
                  <input
                    id="setup-admin-pass"
                    type="password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    placeholder="Choose a strong administrator password"
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
                    required
                    minLength={6}
                  />
                </div>

                <div className="pt-3 border-t border-slate-200">
                  <p className="text-xs font-medium text-slate-700 mb-3">
                    Optional: Provision Maintenance Staff Account
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-3">
                    <div>
                      <label htmlFor="setup-staff-user" className="block text-xs font-medium text-slate-600 mb-1">
                        Staff Username
                      </label>
                      <input
                        id="setup-staff-user"
                        type="text"
                        value={staffUsername}
                        onChange={(e) => setStaffUsername(e.target.value)}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
                      />
                    </div>
                    <div>
                      <label htmlFor="setup-staff-name" className="block text-xs font-medium text-slate-600 mb-1">
                        Staff Name
                      </label>
                      <input
                        id="setup-staff-name"
                        type="text"
                        value={staffFullName}
                        onChange={(e) => setStaffFullName(e.target.value)}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
                      />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="setup-staff-pass" className="block text-xs font-medium text-slate-600 mb-1">
                      Staff Password (leave blank to add later)
                    </label>
                    <input
                      id="setup-staff-pass"
                      type="password"
                      value={staffPassword}
                      onChange={(e) => setStaffPassword(e.target.value)}
                      placeholder="Optional maintenance staff password"
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full mt-2 inline-flex items-center justify-center gap-2 rounded-lg theme-btn-primary px-4 py-2.5 text-sm font-semibold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent-solid)] disabled:opacity-60 cursor-pointer"
                >
                  <UserCheck className="h-4 w-4" aria-hidden="true" />
                  <span>{submitting ? 'Provisioning Workspace...' : 'Claim Admin & Enter Dashboard'}</span>
                </button>
              </form>
            </div>
          ) : (
            <div>
              <div className="mb-6">
                <h2 className="font-display text-xl font-bold text-slate-900">
                  Sign In to Operations Console
                </h2>
                <p className="text-sm text-slate-600 mt-1">
                  Enter your Administrator or Maintenance Staff credentials.
                </p>
              </div>

              {errorMsg && (
                <div
                  role="alert"
                  className="mb-5 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
                >
                  {errorMsg}
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label htmlFor="login-username" className="block text-xs font-medium text-slate-700 mb-1">
                    Username
                  </label>
                  <input
                    id="login-username"
                    type="text"
                    autoComplete="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="e.g. admin or staff_marcus"
                    className="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="login-password" className="block text-xs font-medium text-slate-700 mb-1">
                    Password
                  </label>
                  <input
                    id="login-password"
                    type="password"
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full inline-flex items-center justify-center gap-2 rounded-lg theme-btn-primary px-4 py-2.5 text-sm font-semibold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--accent-solid)] disabled:opacity-60 cursor-pointer"
                >
                  <Lock className="h-4 w-4" aria-hidden="true" />
                  <span>{submitting ? 'Signing In...' : 'Sign In'}</span>
                </button>
              </form>

              <p className="mt-6 text-xs text-slate-500 leading-relaxed">
                Administrators can manage users, records, bulk imports, and multi-format reports from the console after signing in.
              </p>
            </div>
          )}
          </div>
        </section>
      </main>
    </div>
  );
}
