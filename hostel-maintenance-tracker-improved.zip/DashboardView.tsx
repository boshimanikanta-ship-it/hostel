import { useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Clock,
  Compass,
  FileDown,
  Plus,
  RefreshCw,
  Upload,
} from 'lucide-react';
import type { AnalyticsSummary, AuthUser, Complaint, ThemeId } from '../types';
import {
  CategoryBarChart,
  MonthlyTrendsLineChart,
  PriorityDistributionChart,
  StatusDoughnutChart,
} from './Charts';

const CAMPUS_INSPIRATIONS = [
  {
    quote:
      'Every resolved repair turns a dorm room back into a steady space to learn, rest, and thrive.',
    author: 'Campus Facilities Stewardship',
  },
  {
    quote:
      'Preventive maintenance is quiet care in action—fixing small leaks today protects whole communities tomorrow.',
    author: 'Residential Operations Charter',
  },
  {
    quote:
      'Clear records and swift follow-through build trust between students and the staff who keep campus running.',
    author: 'Python for Good · Project #26',
  },
  {
    quote:
      'Great institutions are built in the details: safe wiring, clean water, bright corridors, and timely care.',
    author: 'Student Housing Excellence',
  },
] as const;

interface DashboardViewProps {
  user: AuthUser;
  themeId: ThemeId;
  analytics: AnalyticsSummary | null;
  recentComplaints: Complaint[];
  loading: boolean;
  onNavigate: (tab: string) => void;
  onInspectComplaint: (complaintId: string) => void;
}

export function DashboardView({
  user,
  themeId,
  analytics,
  recentComplaints,
  loading,
  onNavigate,
  onInspectComplaint,
}: DashboardViewProps) {
  const [quoteIdx, setQuoteIdx] = useState(0);
  if (loading || !analytics) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-24 bg-white border border-slate-200 rounded-xl animate-pulse" />
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="h-80 bg-white border border-slate-200 rounded-xl animate-pulse" />
          <div className="h-80 bg-white border border-slate-200 rounded-xl animate-pulse" />
        </div>
      </div>
    );
  }

  const activeQuote = CAMPUS_INSPIRATIONS[quoteIdx % CAMPUS_INSPIRATIONS.length];

  const kpis = [
    {
      label: 'Total Complaints',
      value: analytics.total_complaints,
      note: `${analytics.completion_percentage}% resolution rate`,
      accent: 'text-slate-900',
      stripe: 'theme-gradient-bar',
    },
    {
      label: 'Pending',
      value: analytics.pending_complaints,
      note: 'Awaiting assignment or start',
      accent: 'text-amber-700',
      stripe: 'bg-gradient-to-r from-amber-500 to-orange-500',
    },
    {
      label: 'In Progress',
      value: analytics.in_progress_complaints,
      note: 'Active field work orders',
      accent: 'text-blue-700',
      stripe: 'bg-gradient-to-r from-blue-600 to-cyan-500',
    },
    {
      label: 'Completed',
      value: analytics.completed_complaints,
      note: `${analytics.average_resolution_days}d avg turnaround`,
      accent: 'text-emerald-700',
      stripe: 'bg-gradient-to-r from-emerald-500 to-teal-500',
    },
    {
      label: 'Overdue Requests',
      value: analytics.overdue_complaints,
      note: `${analytics.flagged_warnings.length} flagged warnings`,
      accent: analytics.overdue_complaints > 0 ? 'text-red-700' : 'text-slate-900',
      stripe: 'bg-gradient-to-r from-rose-500 to-red-600',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Inspiring Stewardship Hero + Quick Actions */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="h-1.5 w-full theme-gradient-bar" />
        <div className="p-5 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          <div className="lg:col-span-7 space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-[var(--accent-ink)]">
              <Compass className="h-4 w-4" aria-hidden="true" />
              <span>
                {user.role === 'Administrator'
                  ? 'Campus Maintenance Overview'
                  : 'Maintenance Staff Work Overview'}
              </span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span className="text-slate-500 font-normal">
                Welcome back, {user.full_name}
              </span>
            </div>

            <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900 leading-snug">
              “{activeQuote.quote}”
            </h1>

            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500">
              <span>{activeQuote.author}</span>
              <span aria-hidden="true">·</span>
              <button
                type="button"
                onClick={() => setQuoteIdx((i) => (i + 1) % CAMPUS_INSPIRATIONS.length)}
                className="inline-flex items-center gap-1 font-medium text-[var(--accent-ink)] hover:underline cursor-pointer"
              >
                <RefreshCw className="h-3 w-3" aria-hidden="true" />
                <span>Next Inspiration</span>
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 space-y-4">
            <div className="rounded-xl border border-slate-200 bg-[var(--accent-soft)]/55 p-4 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-slate-700">Campus Resolution Progress</span>
                <span className="font-mono font-bold text-[var(--accent-ink)] tabular-nums">
                  {analytics.completed_complaints}/{analytics.total_complaints} ({analytics.completion_percentage}%)
                </span>
              </div>
              <div className="h-2.5 w-full rounded-full bg-white border border-slate-200 overflow-hidden">
                <div
                  className="h-full theme-gradient-bar transition-all duration-300"
                  style={{ width: `${Math.min(100, Math.max(0, analytics.completion_percentage))}%` }}
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => onNavigate('register')}
                className="inline-flex items-center gap-1.5 rounded-lg theme-btn-primary px-3.5 py-2 text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Register Request</span>
              </button>
              <button
                type="button"
                onClick={() => onNavigate('warnings')}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <AlertTriangle className="h-3.5 w-3.5 text-amber-600" aria-hidden="true" />
                <span>Warnings ({analytics.flagged_warnings.length})</span>
              </button>
              {user.role === 'Administrator' && (
                <>
                  <button
                    type="button"
                    onClick={() => onNavigate('reports')}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <FileDown className="h-3.5 w-3.5 text-[var(--accent-ink)]" aria-hidden="true" />
                    <span>Reports</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onNavigate('reports')}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Upload className="h-3.5 w-3.5 text-slate-600" aria-hidden="true" />
                    <span>Bulk CSV</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* 5 Dynamic Colorful KPI Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {kpis.map((item) => (
          <div
            key={item.label}
            className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col justify-between"
          >
            <div className={`h-1 w-full ${item.stripe}`} />
            <div className="p-5 flex-1 flex flex-col justify-between">
              <span className="text-xs font-medium text-slate-500">{item.label}</span>
              <div className={`font-display text-3xl font-bold tabular-nums mt-2 ${item.accent}`}>
                {item.value}
              </div>
              <span className="text-xs text-slate-500 mt-2">{item.note}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Interactive Chart.js Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-display text-sm font-semibold text-slate-900">
                Complaint Categories
              </h2>
              <p className="text-xs text-slate-500">Volume across hostel maintenance trades</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('analytics')}
              className="text-xs font-medium text-[var(--accent-ink)] hover:underline inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>Deep Analytics</span>
              <ArrowRight className="h-3 w-3" aria-hidden="true" />
            </button>
          </div>
          <CategoryBarChart breakdown={analytics.category_breakdown} themeId={themeId} />
        </section>

        <section className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="mb-4">
            <h2 className="font-display text-sm font-semibold text-slate-900">
              Workflow Status Distribution
            </h2>
            <p className="text-xs text-slate-500">Pending, active in-progress, and resolved ratio</p>
          </div>
          <StatusDoughnutChart breakdown={analytics.status_breakdown} themeId={themeId} />
        </section>

        <section className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="mb-4">
            <h2 className="font-display text-sm font-semibold text-slate-900">
              Monthly Complaint Trends
            </h2>
            <p className="text-xs text-slate-500">Submissions vs completions over time</p>
          </div>
          <MonthlyTrendsLineChart trends={analytics.monthly_trends} themeId={themeId} />
        </section>

        <section className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="mb-4">
            <h2 className="font-display text-sm font-semibold text-slate-900">
              Priority Severity Distribution
            </h2>
            <p className="text-xs text-slate-500">Urgency profile across open and closed requests</p>
          </div>
          <PriorityDistributionChart breakdown={analytics.priority_breakdown} />
        </section>
      </div>

      {/* Bottom Split: Recent Complaints & Threshold Warning Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <section className="lg:col-span-7 bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h2 className="font-display text-sm font-semibold text-slate-900">
                Recent Maintenance Requests
              </h2>
              <p className="text-xs text-slate-500">Latest logged entries in the SQLite ledger</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('complaints')}
              className="text-xs font-medium text-indigo-600 hover:text-indigo-700 inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>Manage All</span>
              <ArrowRight className="h-3 w-3" aria-hidden="true" />
            </button>
          </div>

          {recentComplaints.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">
              No maintenance requests recorded yet.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
                    <th className="py-2.5 px-4">ID</th>
                    <th className="py-2.5 px-4">Location & Issue</th>
                    <th className="py-2.5 px-4">Status</th>
                    <th className="py-2.5 px-4 text-right">Due Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {recentComplaints.slice(0, 6).map((rec) => (
                    <tr
                      key={rec.complaint_id}
                      onClick={() => onInspectComplaint(rec.complaint_id)}
                      className="hover:bg-slate-50 cursor-pointer transition-colors"
                    >
                      <td className="py-3 px-4 font-mono text-xs font-medium text-indigo-700 tabular-nums whitespace-nowrap">
                        {rec.complaint_id}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900 truncate max-w-xs">
                          {rec.hostel_name} · {rec.block_number}-{rec.room_number}
                        </div>
                        <div className="text-xs text-slate-500 truncate max-w-xs">
                          {rec.category} · {rec.student_name}
                        </div>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1.5 text-xs font-medium ${
                            rec.status === 'Completed'
                              ? 'text-emerald-700'
                              : rec.status === 'In Progress'
                                ? 'text-blue-700'
                                : 'text-amber-700'
                          }`}
                        >
                          {rec.status === 'Completed' ? (
                            <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
                          ) : (
                            <Clock className="h-3.5 w-3.5" aria-hidden="true" />
                          )}
                          <span>{rec.status}</span>
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-xs text-slate-600 tabular-nums whitespace-nowrap">
                        {rec.expected_resolution_date}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h2 className="font-display text-sm font-semibold text-slate-900">
                Threshold Warning Alerts
              </h2>
              <p className="text-xs text-slate-500">Overdue, critical, and approaching deadlines</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('warnings')}
              className="text-xs font-medium text-indigo-600 hover:text-indigo-700 inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>View Queue</span>
              <ArrowRight className="h-3 w-3" aria-hidden="true" />
            </button>
          </div>

          {analytics.flagged_warnings.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">
              All active requests are within normal SLA thresholds.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {analytics.flagged_warnings.slice(0, 5).map((item) => (
                <button
                  key={item.complaint_id}
                  type="button"
                  onClick={() => onInspectComplaint(item.complaint_id)}
                  className="w-full text-left px-5 py-3.5 hover:bg-slate-50 transition-colors flex items-start justify-between gap-4 cursor-pointer"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-mono font-semibold text-slate-900 tabular-nums">
                        {item.complaint_id}
                      </span>
                      <span aria-hidden="true" className="text-slate-300">·</span>
                      <span className="text-slate-600 truncate">
                        {item.hostel_name} {item.room_number}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1 truncate">
                      {item.warning_reasons.join(' · ')}
                    </p>
                  </div>
                  <span
                    className={`text-xs font-semibold whitespace-nowrap shrink-0 ${
                      item.warning_level === 'Critical'
                        ? 'text-red-700'
                        : item.warning_level === 'Overdue'
                          ? 'text-rose-600'
                          : 'text-amber-700'
                    }`}
                  >
                    {item.warning_level}
                  </span>
                </button>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
