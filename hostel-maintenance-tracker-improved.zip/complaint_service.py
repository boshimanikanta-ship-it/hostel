"""Core CRUD, search, filtering, and workflow management for hostel complaints."""

from datetime import datetime
from pathlib import Path
from typing import Any

from backend.database import get_connection, transaction, utc_now_iso
from backend.validation import validate_complaint_payload
from backend.warning_system import enrich_records_with_warnings
from config import ALLOWED_STATUSES


def generate_next_complaint_id(conn: Any, year: int | None = None) -> str:
    yr = year or datetime.now().year
    prefix = f"HMT-{yr}-"
    rows = conn.execute(
        "SELECT complaint_id FROM complaints WHERE complaint_id LIKE ?", (f"{prefix}%",)
    ).fetchall()
    max_seq = 0
    for row in rows:
        cid = row["complaint_id"]
        try:
            seq = int(cid.split("-")[-1])
            if seq > max_seq:
                max_seq = seq
        except (ValueError, IndexError):
            continue
    return f"{prefix}{max_seq + 1:04d}"


def create_complaint(
    payload: dict[str, Any],
    *,
    actor: str = "admin",
    db_path: Path | None = None,
) -> tuple[dict[str, Any] | None, dict[str, str]]:
    cleaned, errors = validate_complaint_payload(payload, require_complaint_id=False)
    if errors:
        return None, errors

    now = utc_now_iso()
    with transaction(db_path) as conn:
        cid = cleaned["complaint_id"]
        if not cid:
            sub_year = int(cleaned["submission_date"][:4])
            cid = generate_next_complaint_id(conn, year=sub_year)
        else:
            duplicate = conn.execute(
                "SELECT 1 FROM complaints WHERE complaint_id = ?", (cid,)
            ).fetchone()
            if duplicate:
                return None, {"complaint_id": f"Complaint ID '{cid}' already exists."}

        status = cleaned["status"] or "Pending"
        in_progress_at = now if status in ("In Progress", "Completed") else None
        completed_at = now if status == "Completed" else None

        conn.execute(
            """
            INSERT INTO complaints (
                complaint_id, student_name, student_id, hostel_name,
                block_number, room_number, category, description,
                priority, submission_date, expected_resolution_date,
                status, assigned_staff, resolution_notes,
                in_progress_at, completed_at, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                cid,
                cleaned["student_name"],
                cleaned["student_id"],
                cleaned["hostel_name"],
                cleaned["block_number"],
                cleaned["room_number"],
                cleaned["category"],
                cleaned["description"],
                cleaned["priority"],
                cleaned["submission_date"],
                cleaned["expected_resolution_date"],
                status,
                cleaned["assigned_staff"],
                cleaned["resolution_notes"],
                in_progress_at,
                completed_at,
                now,
                now,
            ),
        )
        conn.execute(
            """
            INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes, changed_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (cid, None, status, actor, "Complaint registered", now),
        )
        conn.execute(
            "INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)",
            ("CREATE_COMPLAINT", actor, cid, f"Registered {cleaned['category']} request for room {cleaned['room_number']}", now),
        )
        row = conn.execute(
            "SELECT * FROM complaints WHERE complaint_id = ?", (cid,)
        ).fetchone()

    enriched = enrich_records_with_warnings([dict(row)])[0]
    return enriched, {}


def list_complaints(
    *,
    keyword: str = "",
    category: str = "",
    priority: str = "",
    status: str = "",
    hostel_name: str = "",
    block_number: str = "",
    warning_level: str = "",
    assigned_staff: str = "",
    start_date: str = "",
    end_date: str = "",
    sort_by: str = "submission_date",
    sort_dir: str = "desc",
    page: int = 1,
    per_page: int = 100,
    db_path: Path | None = None,
) -> dict[str, Any]:
    clauses: list[str] = []
    params: list[Any] = []

    if keyword and keyword.strip():
        kw = f"%{keyword.strip()}%"
        clauses.append(
            """(
                complaint_id LIKE ? OR student_name LIKE ? OR student_id LIKE ?
                OR room_number LIKE ? OR block_number LIKE ? OR hostel_name LIKE ?
                OR category LIKE ? OR description LIKE ? OR status LIKE ?
            )"""
        )
        params.extend([kw] * 9)

    if category:
        clauses.append("category = ?")
        params.append(category)
    if priority:
        clauses.append("priority = ?")
        params.append(priority)
    if status:
        clauses.append("status = ?")
        params.append(status)
    if hostel_name:
        clauses.append("hostel_name = ?")
        params.append(hostel_name)
    if block_number:
        clauses.append("block_number = ?")
        params.append(block_number)
    if assigned_staff:
        clauses.append("assigned_staff = ?")
        params.append(assigned_staff)
    if start_date:
        clauses.append("submission_date >= ?")
        params.append(start_date)
    if end_date:
        clauses.append("submission_date <= ?")
        params.append(end_date)

    allowed_sort = {
        "submission_date": "submission_date",
        "expected_resolution_date": "expected_resolution_date",
        "priority": "CASE priority WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 WHEN 'Medium' THEN 3 ELSE 4 END",
        "complaint_id": "complaint_id",
        "updated_at": "updated_at",
    }
    sort_expr = allowed_sort.get(sort_by, "submission_date")
    direction = "ASC" if str(sort_dir).lower() == "asc" else "DESC"

    where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    sql = f"SELECT * FROM complaints {where_sql} ORDER BY {sort_expr} {direction}, id DESC"

    conn = get_connection(db_path)
    try:
        rows = conn.execute(sql, tuple(params)).fetchall()
    finally:
        conn.close()

    enriched = enrich_records_with_warnings([dict(r) for r in rows])
    if warning_level:
        enriched = [r for r in enriched if r["warning_level"] == warning_level]

    total = len(enriched)
    safe_per_page = max(1, min(per_page, 500))
    safe_page = max(1, page)
    start = (safe_page - 1) * safe_per_page
    paged = enriched[start : start + safe_per_page]

    return {
        "items": paged,
        "total": total,
        "page": safe_page,
        "per_page": safe_per_page,
        "total_pages": max(1, (total + safe_per_page - 1) // safe_per_page),
    }


def get_complaint_detail(
    complaint_id: str, db_path: Path | None = None
) -> dict[str, Any] | None:
    conn = get_connection(db_path)
    try:
        row = conn.execute(
            "SELECT * FROM complaints WHERE complaint_id = ?", (complaint_id,)
        ).fetchone()
        if not row:
            return None
        history = conn.execute(
            "SELECT * FROM status_history WHERE complaint_id = ? ORDER BY id ASC",
            (complaint_id,),
        ).fetchall()
    finally:
        conn.close()

    enriched = enrich_records_with_warnings([dict(row)])[0]
    enriched["history"] = [dict(h) for h in history]
    return enriched


def update_complaint(
    complaint_id: str,
    payload: dict[str, Any],
    *,
    actor: str = "admin",
    db_path: Path | None = None,
) -> tuple[dict[str, Any] | None, dict[str, str]]:
    conn = get_connection(db_path)
    try:
        existing = conn.execute(
            "SELECT * FROM complaints WHERE complaint_id = ?", (complaint_id,)
        ).fetchone()
    finally:
        conn.close()

    if not existing:
        return None, {"complaint_id": f"Complaint '{complaint_id}' not found."}

    merged = dict(existing)
    merged.update(payload)
    merged["complaint_id"] = complaint_id
    cleaned, errors = validate_complaint_payload(
        merged, require_complaint_id=True, allow_any_status=True
    )
    if errors:
        return None, errors

    now = utc_now_iso()
    old_status = existing["status"]
    new_status = cleaned["status"]
    in_progress_at = existing["in_progress_at"]
    completed_at = existing["completed_at"]

    if new_status == "In Progress" and not in_progress_at:
        in_progress_at = now
    if new_status == "Completed":
        if not in_progress_at:
            in_progress_at = now
        if not completed_at:
            completed_at = now
    elif new_status in ("Pending", "In Progress"):
        completed_at = None

    with transaction(db_path) as conn:
        conn.execute(
            """
            UPDATE complaints
            SET student_name = ?, student_id = ?, hostel_name = ?,
                block_number = ?, room_number = ?, category = ?,
                description = ?, priority = ?, submission_date = ?,
                expected_resolution_date = ?, status = ?, assigned_staff = ?,
                resolution_notes = ?, in_progress_at = ?, completed_at = ?,
                updated_at = ?
            WHERE complaint_id = ?
            """,
            (
                cleaned["student_name"],
                cleaned["student_id"],
                cleaned["hostel_name"],
                cleaned["block_number"],
                cleaned["room_number"],
                cleaned["category"],
                cleaned["description"],
                cleaned["priority"],
                cleaned["submission_date"],
                cleaned["expected_resolution_date"],
                new_status,
                cleaned["assigned_staff"],
                cleaned["resolution_notes"],
                in_progress_at,
                completed_at,
                now,
                complaint_id,
            ),
        )
        if old_status != new_status:
            conn.execute(
                """
                INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes, changed_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    complaint_id,
                    old_status,
                    new_status,
                    actor,
                    cleaned["resolution_notes"] or f"Status updated from {old_status} to {new_status}",
                    now,
                ),
            )
        conn.execute(
            "INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)",
            ("UPDATE_COMPLAINT", actor, complaint_id, f"Updated fields (status: {new_status})", now),
        )

    return get_complaint_detail(complaint_id, db_path=db_path), {}


def update_complaint_status(
    complaint_id: str,
    new_status: str,
    *,
    assigned_staff: str | None = None,
    resolution_notes: str | None = None,
    actor: str = "staff",
    db_path: Path | None = None,
) -> tuple[dict[str, Any] | None, dict[str, str]]:
    if new_status not in ALLOWED_STATUSES:
        return None, {"status": f"Invalid status. Choose from {', '.join(ALLOWED_STATUSES)}."}

    conn = get_connection(db_path)
    try:
        existing = conn.execute(
            "SELECT * FROM complaints WHERE complaint_id = ?", (complaint_id,)
        ).fetchone()
    finally:
        conn.close()

    if not existing:
        return None, {"complaint_id": f"Complaint '{complaint_id}' not found."}

    now = utc_now_iso()
    old_status = existing["status"]
    in_progress_at = existing["in_progress_at"]
    completed_at = existing["completed_at"]

    if new_status == "In Progress" and not in_progress_at:
        in_progress_at = now
    if new_status == "Completed":
        if not in_progress_at:
            in_progress_at = now
        completed_at = now
    elif new_status != "Completed":
        completed_at = None

    next_staff = assigned_staff if assigned_staff is not None else existing["assigned_staff"]
    next_notes = resolution_notes if resolution_notes is not None else existing["resolution_notes"]

    with transaction(db_path) as conn:
        conn.execute(
            """
            UPDATE complaints
            SET status = ?, assigned_staff = ?, resolution_notes = ?,
                in_progress_at = ?, completed_at = ?, updated_at = ?
            WHERE complaint_id = ?
            """,
            (new_status, next_staff, next_notes, in_progress_at, completed_at, now, complaint_id),
        )
        conn.execute(
            """
            INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes, changed_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                complaint_id,
                old_status,
                new_status,
                actor,
                next_notes or f"Status transitioned to {new_status}",
                now,
            ),
        )
        conn.execute(
            "INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)",
            ("STATUS_UPDATE", actor, complaint_id, f"{old_status} -> {new_status}", now),
        )

    return get_complaint_detail(complaint_id, db_path=db_path), {}


def delete_complaint(
    complaint_id: str, *, actor: str = "admin", db_path: Path | None = None
) -> bool:
    now = utc_now_iso()
    with transaction(db_path) as conn:
        cur = conn.execute(
            "DELETE FROM complaints WHERE complaint_id = ?", (complaint_id,)
        )
        if cur.rowcount == 0:
            return False
        conn.execute(
            "DELETE FROM status_history WHERE complaint_id = ?", (complaint_id,)
        )
        conn.execute(
            "INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)",
            ("DELETE_COMPLAINT", actor, complaint_id, "Deleted maintenance record", now),
        )
    return True
