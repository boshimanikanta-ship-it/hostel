"""Application configuration for Hostel Maintenance Tracker."""

import os
import secrets
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
EXPORTS_DIR = BASE_DIR / "exports"
DB_PATH = Path(os.environ.get("HOSTEL_DB_PATH", str(DATA_DIR / "hostel.db")))
SAMPLE_CSV_PATH = DATA_DIR / "sample_complaints.csv"
SAMPLE_JSON_PATH = DATA_DIR / "sample_complaints.json"

SECRET_KEY = os.environ.get("FLASK_SECRET_KEY", "").strip()
if os.environ.get("FLASK_ENV") == "production" and len(SECRET_KEY.encode("utf-8")) < 32:
    raise RuntimeError("Production requires FLASK_SECRET_KEY with at least 32 bytes.")
SECRET_KEY = SECRET_KEY or secrets.token_hex(32)

ALLOWED_CATEGORIES = (
    "Electrical",
    "Plumbing",
    "Cleaning",
    "Furniture",
    "Internet/Wi-Fi",
    "Bathroom",
    "Water Supply",
    "Other",
)

ALLOWED_PRIORITIES = ("Low", "Medium", "High", "Critical")

ALLOWED_STATUSES = ("Pending", "In Progress", "Completed")

ALLOWED_ROLES = ("Administrator", "Maintenance Staff")

CSV_REQUIRED_COLUMNS = (
    "complaint_id",
    "student_name",
    "student_id",
    "hostel_name",
    "block_number",
    "room_number",
    "category",
    "description",
    "priority",
    "submission_date",
    "expected_resolution_date",
    "status",
)
