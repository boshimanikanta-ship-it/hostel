import { Palette } from 'lucide-react';
import { THEME_OPTIONS, type ThemeId } from '../types';

interface ThemeSelectorProps {
  theme: ThemeId;
  onChange: (theme: ThemeId) => void;
  compact?: boolean;
}

export function ThemeSelector({ theme, onChange, compact = false }: ThemeSelectorProps) {
  if (compact) {
    return (
      <div className="space-y-1.5">
        <div className="flex items-center gap-1.5 text-xs font-medium text-slate-600">
          <Palette className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
          <span>Color Theme</span>
        </div>
        <div className="grid grid-cols-2 gap-1.5" role="group" aria-label="Color theme switcher">
          {THEME_OPTIONS.map((opt) => {
            const active = theme === opt.id;
            return (
              <button
                key={opt.id}
                type="button"
                onClick={() => onChange(opt.id)}
                title={opt.label}
                className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg border text-xs font-medium transition-colors cursor-pointer truncate ${
                  active
                    ? 'border-slate-900 bg-slate-900 text-white'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                <span
                  className="h-3 w-3 rounded-sm shrink-0"
                  style={{
                    backgroundImage: `linear-gradient(135deg, ${opt.swatch[0]}, ${opt.swatch[1]}, ${opt.swatch[2]})`,
                  }}
                />
                <span className="truncate">{opt.label.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div
      className="inline-flex items-center gap-1 p-1 rounded-lg bg-slate-100 border border-slate-200"
      role="group"
      aria-label="Color theme switcher"
    >
      {THEME_OPTIONS.map((opt) => {
        const active = theme === opt.id;
        return (
          <button
            key={opt.id}
            type="button"
            onClick={() => onChange(opt.id)}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              active
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span
              className="h-2.5 w-2.5 rounded-sm shrink-0"
              style={{
                backgroundImage: `linear-gradient(135deg, ${opt.swatch[0]}, ${opt.swatch[1]}, ${opt.swatch[2]})`,
              }}
            />
            <span className="hidden sm:inline">{opt.label}</span>
          </button>
        );
      })}
    </div>
  );
}
