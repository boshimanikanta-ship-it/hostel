import { useCallback, useEffect, useState } from 'react';
import {
  AlertTriangle,
  BarChart3,
  CheckCircle2,
  ClipboardList,
  ClipboardPlus,
  FileSpreadsheet,
  LayoutDashboard,
  LogOut,
  Menu,
  Users,
  X,
} from 'lucide-react';
import { apiRequest } from './api';
import { AnalyticsView } from './components/AnalyticsView';
import { BrandEmblem3D, BrandTitle3D } from './components/BrandTitle3D';
import { ComplaintsView } from './components/ComplaintsView';
import { DashboardView } from './components/DashboardView';
import { LoginScreen } from './components/LoginScreen';
import { RegisterComplaintView } from './components/RegisterComplaintView';
import { ReportsDataView } from './components/ReportsDataView';
import { ThemeSelector } from './components/ThemeSelector';
import { UsersView } from './components/UsersView';
import { WarningsView } from './components/WarningsView';
import type {
  AnalyticsSummary,
  AuthUser,
  Complaint,
  PaginatedComplaints,
  StaffDirectoryItem,
  ThemeId,
} from './types';

type TabKey =
  | 'overview'
  | 'register'
  | 'complaints'
  | 'warnings'
  | 'analytics'
  | 'reports'
  | 'users';

export default function App() {
  const [bootLoading, setBootLoading] = useState(true);
  const [initialized, setInitialized] = useState(true);
  const [envConfigured, setEnvConfigured] = useState(false);

  // Bearer token held strictly in React memory (never persisted in browser storage)
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<AuthUser | null>(null);

  const [activeTab, setActiveTab] = useState<TabKey>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [inspectComplaintId, setInspectComplaintId] = useState<string | null>(null);

  const [analytics, setAnalytics] = useState<AnalyticsSummary | null>(null);
  const [recentComplaints, setRecentComplaints] = useState<Complaint[]>([]);
  const [staffDirectory, setStaffDirectory] = useState<StaffDirectoryItem[]>([]);
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const [toast, setToast] = useState<string>('');
  const [avatarFailed, setAvatarFailed] = useState(false);
  const [theme, setTheme] = useState<ThemeId>('indigo-horizon');

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  useEffect(() => {
    apiRequest<{ initialized: boolean; envConfigured: boolean }>('/api/auth/status')
      .then((res) => {
        setInitialized(res.initialized);
        setEnvConfigured(res.envConfigured);
      })
      .catch(() => {})
      .finally(() => setBootLoading(false));
  }, []);

  const refreshWorkspace = useCallback(async (authToken: string) => {
    setDashboardLoading(true);
    try {
      const [anRes, recRes, dirRes] = await Promise.all([
        apiRequest<AnalyticsSummary>('/api/analytics', { token: authToken }),
        apiRequest<PaginatedComplaints>('/api/complaints?per_page=8', { token: authToken }),
        apiRequest<StaffDirectoryItem[]>('/api/staff-directory', { token: authToken }),
      ]);
      setAnalytics(anRes);
      setRecentComplaints(recRes.items);
      setStaffDirectory(dirRes);
    } catch {
      // Handled by individual views if needed
    } finally {
      setDashboardLoading(false);
    }
  }, []);

  useEffect(() => {
    if (token && user) {
      refreshWorkspace(token);
    }
  }, [token, user, refreshWorkspace]);

  function showToast(msg: string) {
    setToast(msg);
    setTimeout(() => {
      setToast((curr) => (curr === msg ? '' : curr));
    }, 4500);
  }

  function handleAuthenticated(nextToken: string, nextUser: AuthUser) {
    setToken(nextToken);
    setUser(nextUser);
    setInitialized(true);
    setActiveTab(nextUser.role === 'Administrator' ? 'overview' : 'complaints');
  }

  function handleSignOut() {
    setToken(null);
    setUser(null);
    setAnalytics(null);
    setRecentComplaints([]);
    setActiveTab('overview');
  }

  function handleInspectComplaint(complaintId: string) {
    setInspectComplaintId(complaintId);
    setActiveTab('complaints');
  }

  if (bootLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center text-sm text-slate-500">
        Loading Hostel Maintenance Tracker...
      </div>
    );
  }

  if (!token || !user) {
    return (
      <LoginScreen
        initialized={initialized}
        envConfigured={envConfigured}
        theme={theme}
        onThemeChange={setTheme}
        onAuthenticated={handleAuthenticated}
      />
    );
  }

  const navItems: Array<{ key: TabKey; label: string; icon: typeof LayoutDashboard; adminOnly?: boolean }> = [
    { key: 'overview', label: 'Overview', icon: LayoutDashboard },
    { key: 'register', label: 'Register Request', icon: ClipboardPlus },
    { key: 'complaints', label: 'Complaints', icon: ClipboardList },
    { key: 'warnings', label: 'Warnings', icon: AlertTriangle },
    { key: 'analytics', label: 'Analytics', icon: BarChart3 },
    { key: 'reports', label: 'Reports & Data', icon: FileSpreadsheet },
    { key: 'users', label: 'Staff & Access', icon: Users, adminOnly: true },
  ];

  const visibleNav = navItems.filter((item) => !item.adminOnly || user.role === 'Administrator');
  const activeNavLabel = visibleNav.find((n) => n.key === activeTab)?.label || 'Overview';
  const avatarSrc =
    user.role === 'Administrator'
      ? '/src/assets/images/avatar_hostel_admin_1795267070962.jpg'
      : '/src/assets/images/avatar_maintenance_lead_1795267069759.jpg';

  return (
    <div className="min-h-screen app-canvas-bg text-slate-900 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:shrink-0 bg-white/95 backdrop-blur-sm border-r border-slate-200">
        <div className="px-4 py-4 border-b border-slate-200 flex items-center gap-3">
          <BrandEmblem3D size="sm" />
          <BrandTitle3D variant="sidebar" />
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1" aria-label="Main navigation">
          {visibleNav.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.key;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => setActiveTab(item.key)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-[var(--accent-soft)] text-[var(--accent-ink)]'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                  <span>{item.label}</span>
                </span>
                {item.key === 'warnings' && analytics && analytics.flagged_warnings.length > 0 && (
                  <span className="font-mono text-xs font-semibold text-red-700 tabular-nums">
                    {analytics.flagged_warnings.length}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-200 space-y-4">
          <ThemeSelector theme={theme} onChange={setTheme} compact />

          <div className="pt-3 border-t border-slate-200 flex items-center gap-3">
            {!avatarFailed ? (
              <img
                src={avatarSrc}
                alt={user.full_name}
                referrerPolicy="no-referrer"
                onError={() => setAvatarFailed(true)}
                className="h-9 w-9 rounded-full object-cover border border-slate-200 shrink-0"
              />
            ) : (
              <div className="h-9 w-9 rounded-full bg-[var(--accent-soft)] text-[var(--accent-ink)] flex items-center justify-center text-xs font-bold shrink-0">
                {user.full_name.slice(0, 2).toUpperCase()}
              </div>
            )}
            <div className="min-w-0">
              <div className="text-xs font-semibold text-slate-900 truncate">{user.full_name}</div>
              <div className="text-xs text-slate-500 truncate">{user.role}</div>
            </div>
          </div>

          <button
            type="button"
            onClick={handleSignOut}
            className="w-full inline-flex items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <LogOut className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/40"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative w-64 bg-white h-full flex flex-col border-r border-slate-200 z-10">
            <div className="px-4 py-4 border-b border-slate-200 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5 min-w-0">
                <BrandEmblem3D size="sm" />
                <BrandTitle3D variant="sidebar" />
              </div>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close navigation"
                className="p-1 rounded-md text-slate-500 hover:bg-slate-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="flex-1 p-3 space-y-1">
              {visibleNav.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.key;
                return (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => {
                      setActiveTab(item.key);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium ${
                      isActive ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600'
                    }`}
                  >
                    <Icon className="h-4 w-4" aria-hidden="true" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="p-4 border-t border-slate-200">
              <button
                type="button"
                onClick={handleSignOut}
                className="w-full inline-flex items-center justify-center gap-2 rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium text-slate-700"
              >
                <LogOut className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Sign Out</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Shell */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-white/90 backdrop-blur-md border-b border-slate-200 px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open navigation menu"
              className="lg:hidden p-1.5 rounded-lg border border-slate-300 text-slate-700"
            >
              <Menu className="h-4 w-4" />
            </button>
            <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-500 truncate">
              <span className="hidden sm:inline">Campus Facilities</span>
              <span className="hidden sm:inline" aria-hidden="true">
                /
              </span>
              <span className="font-display font-semibold text-slate-900 truncate">
                {activeNavLabel}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="hidden md:block">
              <ThemeSelector theme={theme} onChange={setTheme} />
            </div>
            <button
              type="button"
              onClick={() => setActiveTab('register')}
              className="inline-flex items-center gap-1.5 rounded-lg theme-btn-primary px-3.5 py-2 text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer"
            >
              <ClipboardPlus className="h-3.5 w-3.5" aria-hidden="true" />
              <span>New Request</span>
            </button>
          </div>
        </header>

        {toast && (
          <div className="mx-4 sm:mx-6 mt-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs font-medium text-emerald-800 flex items-center justify-between gap-3">
            <span className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span>{toast}</span>
            </span>
            <button
              type="button"
              onClick={() => setToast('')}
              aria-label="Dismiss notification"
              className="text-emerald-700 hover:text-emerald-900 cursor-pointer"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

        <main className="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto">
          {activeTab === 'overview' && (
            <DashboardView
              user={user}
              themeId={theme}
              analytics={analytics}
              recentComplaints={recentComplaints}
              loading={dashboardLoading}
              onNavigate={(t) => setActiveTab(t as TabKey)}
              onInspectComplaint={handleInspectComplaint}
            />
          )}

          {activeTab === 'register' && (
            <RegisterComplaintView
              token={token}
              staffDirectory={staffDirectory}
              onCreated={(created) => {
                refreshWorkspace(token);
                showToast(`Registered maintenance request ${created.complaint_id}.`);
                setActiveTab('complaints');
              }}
            />
          )}

          {activeTab === 'complaints' && (
            <ComplaintsView
              token={token}
              user={user}
              staffDirectory={staffDirectory}
              initialComplaintId={inspectComplaintId}
              onClearInitialId={() => setInspectComplaintId(null)}
              onDataChanged={(msg) => {
                refreshWorkspace(token);
                showToast(msg);
              }}
            />
          )}

          {activeTab === 'warnings' && (
            <WarningsView
              analytics={analytics}
              onInspectComplaint={handleInspectComplaint}
            />
          )}

          {activeTab === 'analytics' && <AnalyticsView token={token} themeId={theme} />}

          {activeTab === 'reports' && (
            <ReportsDataView
              token={token}
              user={user}
              onDataChanged={(msg) => {
                refreshWorkspace(token);
                showToast(msg);
              }}
            />
          )}

          {activeTab === 'users' && user.role === 'Administrator' && (
            <UsersView
              token={token}
              currentUser={user}
              onDataChanged={(msg) => {
                refreshWorkspace(token);
                showToast(msg);
              }}
            />
          )}
        </main>
      </div>
    </div>
  );
}
