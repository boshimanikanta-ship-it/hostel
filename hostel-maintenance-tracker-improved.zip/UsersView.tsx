import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { UserPlus } from 'lucide-react';
import { apiRequest, ApiError } from '../api';
import type { AuthUser, StaffDirectoryItem, UserRole } from '../types';

interface UsersViewProps {
  token: string;
  currentUser: AuthUser;
  onDataChanged: (message: string) => void;
}

export function UsersView({ token, currentUser, onDataChanged }: UsersViewProps) {
  const [users, setUsers] = useState<StaffDirectoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');

  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('Maintenance Staff');
  const [department, setDepartment] = useState('Electrical & Plumbing');
  const [password, setPassword] = useState('');
  const [creating, setCreating] = useState(false);

  const loadUsers = useCallback(async () => {
    setLoading(true);
    try {
      const list = await apiRequest<StaffDirectoryItem[]>('/api/users', { token });
      setUsers(list);
    } catch (err) {
      setErrorMsg(err instanceof ApiError ? err.message : 'Unable to load users.');
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    loadUsers();
  }, [loadUsers]);

  async function handleCreateUser(e: FormEvent) {
    e.preventDefault();
    setErrorMsg('');
    setCreating(true);
    try {
      await apiRequest('/api/users', {
        method: 'POST',
        token,
        body: {
          username: username.trim(),
          full_name: fullName.trim(),
          email: email.trim(),
          role,
          department: department.trim(),
          password,
        },
      });
      setUsername('');
      setFullName('');
      setEmail('');
      setPassword('');
      await loadUsers();
      onDataChanged(`Created ${role} account.`);
    } catch (err) {
      setErrorMsg(err instanceof ApiError ? err.message : 'Failed to create user.');
    } finally {
      setCreating(false);
    }
  }

  async function handleToggle(targetId: number) {
    setErrorMsg('');
    try {
      await apiRequest(`/api/users/${targetId}/toggle`, {
        method: 'PATCH',
        token,
      });
      await loadUsers();
      onDataChanged('Updated account access state.');
    } catch (err) {
      setErrorMsg(err instanceof ApiError ? err.message : 'Unable to toggle user status.');
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <section className="lg:col-span-7 bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200">
          <h1 className="font-display text-lg font-bold text-slate-900">
            Staff & Role Access Directory
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage Administrator and Maintenance Staff accounts stored in SQLite.
          </p>
        </div>

        {loading ? (
          <div className="p-6 space-y-3">
            <div className="h-10 bg-slate-100 rounded animate-pulse" />
            <div className="h-10 bg-slate-100 rounded animate-pulse" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
                  <th className="py-3 px-4">Name & Username</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map((u) => (
                  <tr key={u.id}>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900">{u.full_name}</div>
                      <div className="font-mono text-xs text-slate-500">@{u.username}</div>
                    </td>
                    <td className="py-3 px-4 text-xs font-semibold text-indigo-700 whitespace-nowrap">
                      {u.role}
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-600">{u.department}</td>
                    <td className="py-3 px-4 text-xs font-medium whitespace-nowrap">
                      <span className={u.is_active ? 'text-emerald-700' : 'text-slate-400'}>
                        {u.is_active ? 'Active' : 'Disabled'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      {u.id !== currentUser.id ? (
                        <button
                          type="button"
                          onClick={() => handleToggle(u.id)}
                          className="text-xs font-medium text-slate-700 hover:text-indigo-700 cursor-pointer"
                        >
                          {u.is_active ? 'Deactivate' : 'Activate'}
                        </button>
                      ) : (
                        <span className="text-xs text-slate-400">Current Session</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <div>
          <h2 className="font-display text-base font-bold text-slate-900">
            Provision Staff Account
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Create a new Maintenance Staff or Administrator login with salted scrypt password hashing.
          </p>
        </div>

        {errorMsg && (
          <div className="rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs text-red-700">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleCreateUser} className="space-y-3.5">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Username *</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="e.g. staff_devon"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              required
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Full Name *</label>
            <input
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="e.g. Devon Brooks"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Role</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as UserRole)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
              >
                <option value="Maintenance Staff">Maintenance Staff</option>
                <option value="Administrator">Administrator</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Department</label>
              <input
                type="text"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="staff@campus-hostels.edu"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Password (min 6 chars) *
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              required
              minLength={6}
            />
          </div>

          <button
            type="submit"
            disabled={creating}
            className="w-full inline-flex items-center justify-center gap-2 rounded-lg theme-btn-primary px-4 py-2.5 text-xs font-semibold disabled:opacity-60 cursor-pointer"
          >
            <UserPlus className="h-4 w-4" aria-hidden="true" />
            <span>{creating ? 'Creating Account...' : 'Create User Account'}</span>
          </button>
        </form>
      </section>
    </div>
  );
}
