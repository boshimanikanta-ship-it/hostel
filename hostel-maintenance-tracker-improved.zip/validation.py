"""Centralized defensive input validation for Hostel Maintenance Tracker."""

import re
from datetime import datetime
from typing import Any

from config import (
    ALLOWED_CATEGORIES,
    ALLOWED_PRIORITIES,
    ALLOWED_ROLES,
    ALLOWED_STATUSES,
)

STUDENT_NAME_RE = re.compile(r"^[A-Za-z][A-Za-z\s'.-]{1,79}$")
STUDENT_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9\-_]{2,23}$")
HOSTEL_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9\s&'.-]{1,79}$")
BLOCK_NUMBER_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9\s-]{0,15}$")
ROOM_NUMBER_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9\-]{0,11}$")
COMPLAINT_ID_RE = re.compile(r"^HMT-\d{4}-\d{4,6}$")
USERNAME_RE = re.compile(r"^[a-zA-Z0-9_.-]{3,32}$")


def parse_iso_date(value: str) -> datetime | None:
    if not isinstance(value, str):
        return None
    cleaned = value.strip()
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", cleaned):
        return None
    try:
        return datetime.strptime(cleaned, "%Y-%m-%d")
    except ValueError:
        return None


def sanitize_text(value: Any) -> str:
    if value is None:
        return ""
    if not isinstance(value, str):
        value = str(value)
    return " ".join(value.strip().split())


def validate_complaint_payload(
    payload: dict[str, Any],
    *,
    require_complaint_id: bool = False,
    allow_any_status: bool = False,
) -> tuple[dict[str, Any], dict[str, str]]:
    """Validate and normalize a maintenance request payload."""
    errors: dict[str, str] = {}
    cleaned: dict[str, Any] = {}

    complaint_id = sanitize_text(payload.get("complaint_id", ""))
    if require_complaint_id:
        if not complaint_id:
            errors["complaint_id"] = "Complaint ID is required."
        elif not COMPLAINT_ID_RE.match(complaint_id):
            errors["complaint_id"] = "Complaint ID must match format HMT-YYYY-NNNN."
    elif complaint_id and not COMPLAINT_ID_RE.match(complaint_id):
        errors["complaint_id"] = "Complaint ID must match format HMT-YYYY-NNNN."
    cleaned["complaint_id"] = complaint_id

    student_name = sanitize_text(payload.get("student_name", ""))
    if not student_name:
        errors["student_name"] = "Student name is required."
    elif not STUDENT_NAME_RE.match(student_name):
        errors["student_name"] = (
            "Student name must be 2–80 characters using letters, spaces, hyphens, or apostrophes."
        )
    cleaned["student_name"] = student_name

    student_id = sanitize_text(payload.get("student_id", "")).upper()
    if not student_id:
        errors["student_id"] = "Student ID is required."
    elif not STUDENT_ID_RE.match(student_id):
        errors["student_id"] = "Student ID must be 3–24 alphanumeric characters (hyphens allowed)."
    cleaned["student_id"] = student_id

    hostel_name = sanitize_text(payload.get("hostel_name", ""))
    if not hostel_name:
        errors["hostel_name"] = "Hostel name is required."
    elif not HOSTEL_NAME_RE.match(hostel_name):
        errors["hostel_name"] = "Hostel name must be 2–80 valid characters."
    cleaned["hostel_name"] = hostel_name

    block_number = sanitize_text(payload.get("block_number", "")).upper()
    if not block_number:
        errors["block_number"] = "Block number is required."
    elif not BLOCK_NUMBER_RE.match(block_number):
        errors["block_number"] = "Block number must be 1–16 alphanumeric characters."
    cleaned["block_number"] = block_number

    room_number = sanitize_text(payload.get("room_number", "")).upper()
    if not room_number:
        errors["room_number"] = "Room number is required."
    elif not ROOM_NUMBER_RE.match(room_number):
        errors["room_number"] = (
            "Room number must be 1–12 alphanumeric characters (e.g., 104 or A-204)."
        )
    cleaned["room_number"] = room_number

    category = sanitize_text(payload.get("category", ""))
    if category not in ALLOWED_CATEGORIES:
        errors["category"] = f"Category must be one of: {', '.join(ALLOWED_CATEGORIES)}."
    cleaned["category"] = category

    description = sanitize_text(payload.get("description", ""))
    if not description:
        errors["description"] = "Problem description is required."
    elif len(description) < 10:
        errors["description"] = "Problem description must be at least 10 characters."
    elif len(description) > 1000:
        errors["description"] = "Problem description cannot exceed 1000 characters."
    cleaned["description"] = description

    priority = sanitize_text(payload.get("priority", ""))
    if priority not in ALLOWED_PRIORITIES:
        errors["priority"] = f"Priority must be one of: {', '.join(ALLOWED_PRIORITIES)}."
    cleaned["priority"] = priority

    submission_date_raw = sanitize_text(payload.get("submission_date", ""))
    submission_dt = parse_iso_date(submission_date_raw)
    if not submission_dt:
        errors["submission_date"] = "Submission date must be a valid YYYY-MM-DD date."
    cleaned["submission_date"] = submission_date_raw

    expected_date_raw = sanitize_text(payload.get("expected_resolution_date", ""))
    expected_dt = parse_iso_date(expected_date_raw)
    if not expected_dt:
        errors["expected_resolution_date"] = (
            "Expected resolution date must be a valid YYYY-MM-DD date."
        )
    elif submission_dt and expected_dt < submission_dt:
        errors["expected_resolution_date"] = (
            "Expected resolution date cannot be earlier than submission date."
        )
    cleaned["expected_resolution_date"] = expected_date_raw

    status = sanitize_text(payload.get("status", "Pending")) or "Pending"
    if allow_any_status:
        if status not in ALLOWED_STATUSES:
            errors["status"] = f"Status must be one of: {', '.join(ALLOWED_STATUSES)}."
    else:
        if status not in ALLOWED_STATUSES:
            errors["status"] = f"Status must be one of: {', '.join(ALLOWED_STATUSES)}."
    cleaned["status"] = status

    cleaned["assigned_staff"] = sanitize_text(payload.get("assigned_staff", ""))[:80]
    cleaned["resolution_notes"] = sanitize_text(payload.get("resolution_notes", ""))[:1000]
    cleaned["in_progress_at"] = payload.get("in_progress_at") or None
    cleaned["completed_at"] = payload.get("completed_at") or None

    return cleaned, errors


def validate_user_payload(payload: dict[str, Any]) -> tuple[dict[str, Any], dict[str, str]]:
    errors: dict[str, str] = {}
    username = sanitize_text(payload.get("username", "")).lower()
    full_name = sanitize_text(payload.get("full_name", ""))
    role = sanitize_text(payload.get("role", "Maintenance Staff"))
    password = payload.get("password", "")
    email = sanitize_text(payload.get("email", ""))
    department = sanitize_text(payload.get("department", "General Maintenance")) or "General Maintenance"

    if not USERNAME_RE.match(username):
        errors["username"] = "Username must be 3–32 characters (letters, numbers, ., _, -)."
    if not STUDENT_NAME_RE.match(full_name):
        errors["full_name"] = "Full name must be 2–80 valid characters."
    if role not in ALLOWED_ROLES:
        errors["role"] = f"Role must be one of: {', '.join(ALLOWED_ROLES)}."
    if not isinstance(password, str) or len(password) < 6:
        errors["password"] = "Password must be at least 6 characters."
    if email and not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
        errors["email"] = "Email address format is invalid."

    return {
        "username": username,
        "full_name": full_name,
        "role": role,
        "password": password,
        "email": email,
        "department": department,
    }, errors
