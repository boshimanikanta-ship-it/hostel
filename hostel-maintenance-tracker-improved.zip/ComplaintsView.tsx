import { useCallback, useEffect, useState, type FormEvent } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  Edit3,
  Eye,
  RotateCcw,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import { apiRequest, ApiError } from '../api';
import {
  CATEGORIES,
  HOSTEL_OPTIONS,
  PRIORITIES,
  STATUSES,
  WARNING_LEVELS,
  type AuthUser,
  type Complaint,
  type PaginatedComplaints,
  type StaffDirectoryItem,
} from '../types';

interface ComplaintsViewProps {
  token: string;
  user: AuthUser;
  staffDirectory: StaffDirectoryItem[];
  initialComplaintId: string | null;
  onClearInitialId: () => void;
  onDataChanged: (message: string) => void;
}

export function ComplaintsView({
  token,
  user,
  staffDirectory,
  initialComplaintId,
  onClearInitialId,
  onDataChanged,
}: ComplaintsViewProps) {
  const [keyword, setKeyword] = useState('');
  const [category, setCategory] = useState('');
  const [priority, setPriority] = useState('');
  const [status, setStatus] = useState('');
  const [warningLevel, setWarningLevel] = useState('');
  const [sortBy, setSortBy] = useState('submission_date');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [scope, setScope] = useState<'assigned' | 'all'>(
    user.role === 'Maintenance Staff' ? 'assigned' : 'all'
  );
  const [page, setPage] = useState(1);

  const [data, setData] = useState<PaginatedComplaints | null>(null);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');

  // Active modals
  const [detailComplaint, setDetailComplaint] = useState<Complaint | null>(null);
  const [statusModalItem, setStatusModalItem] = useState<Complaint | null>(null);
  const [editModalItem, setEditModalItem] = useState<Complaint | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Complaint | null>(null);

  // Status update modal state
  const [nextStatus, setNextStatus] = useState<'Pending' | 'In Progress' | 'Completed'>('In Progress');
  const [nextStaff, setNextStaff] = useState('');
  const [nextNotes, setNextNotes] = useState('');
  const [modalSaving, setModalSaving] = useState(false);
  const [modalError, setModalError] = useState('');

  // Edit modal state
  const [editForm, setEditForm] = useState<Record<string, string>>({});

  const fetchList = useCallback(async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      const params = new URLSearchParams();
      if (keyword.trim()) params.set('keyword', keyword.trim());
      if (category) params.set('category', category);
      if (priority) params.set('priority', priority);
      if (status) params.set('status', status);
      if (warningLevel) params.set('warning_level', warningLevel);
      params.set('sort_by', sortBy);
      params.set('sort_dir', sortDir);
      params.set('scope', scope);
      params.set('page', String(page));
      params.set('per_page', '12');

      const res = await apiRequest<PaginatedComplaints>(`/api/complaints?${params.toString()}`, {
        token,
      });
      setData(res);
    } catch (err) {
      setErrorMsg(err instanceof ApiError ? err.message : 'Failed to load complaints.');
    } finally {
      setLoading(false);
    }
  }, [token, keyword, category, priority, status, warningLevel, sortBy, sortDir, scope, page]);

  useEffect(() => {
    fetchList();
  }, [fetchList]);

  const openDetails = useCallback(
    async (complaintId: string) => {
      try {
        const detail = await apiRequest<Complaint>(`/api/complaints/${complaintId}`, { token });
        setDetailComplaint(detail);
      } catch (err) {
        setErrorMsg(err instanceof ApiError ? err.message : 'Unable to load complaint details.');
      }
    },
    [token]
  );

  useEffect(() => {
    if (initialComplaintId) {
      openDetails(initialComplaintId);
      onClearInitialId();
    }
  }, [initialComplaintId, openDetails, onClearInitialId]);

  function openStatusModal(item: Complaint) {
    setStatusModalItem(item);
    setNextStatus(item.status);
    setNextStaff(item.assigned_staff || (user.role === 'Maintenance Staff' ? user.full_name : ''));
    setNextNotes(item.resolution_notes || '');
    setModalError('');
  }

  async function handleStatusSubmit(e: FormEvent) {
    e.preventDefault();
    if (!statusModalItem) return;
    setModalSaving(true);
    setModalError('');
    try {
      const updated = await apiRequest<Complaint>(
        `/api/complaints/${statusModalItem.complaint_id}/status`,
        {
          method: 'PATCH',
          token,
          body: {
            status: nextStatus,
            assigned_staff: nextStaff,
            resolution_notes: nextNotes,
          },
        }
      );
      setStatusModalItem(null);
      if (detailComplaint?.complaint_id === updated.complaint_id) {
        setDetailComplaint(updated);
      }
      await fetchList();
      onDataChanged(`Updated ${updated.complaint_id} status to ${updated.status}.`);
    } catch (err) {
      setModalError(err instanceof ApiError ? err.message : 'Status update failed.');
    } finally {
      setModalSaving(false);
    }
  }

  function openEditModal(item: Complaint) {
    setEditModalItem(item);
    setEditForm({
      student_name: item.student_name,
      student_id: item.student_id,
      hostel_name: item.hostel_name,
      block_number: item.block_number,
      room_number: item.room_number,
      category: item.category,
      priority: item.priority,
      status: item.status,
      submission_date: item.submission_date,
      expected_resolution_date: item.expected_resolution_date,
      assigned_staff: item.assigned_staff || '',
      description: item.description,
      resolution_notes: item.resolution_notes || '',
    });
    setModalError('');
  }

  async function handleEditSubmit(e: FormEvent) {
    e.preventDefault();
    if (!editModalItem) return;
    setModalSaving(true);
    setModalError('');
    try {
      const updated = await apiRequest<Complaint>(
        `/api/complaints/${editModalItem.complaint_id}`,
        {
          method: 'PUT',
          token,
          body: editForm,
        }
      );
      setEditModalItem(null);
      if (detailComplaint?.complaint_id === updated.complaint_id) {
        setDetailComplaint(updated);
      }
      await fetchList();
      onDataChanged(`Saved updates for ${updated.complaint_id}.`);
    } catch (err) {
      setModalError(err instanceof ApiError ? err.message : 'Update failed.');
    } finally {
      setModalSaving(false);
    }
  }

  async function handleDeleteConfirm() {
    if (!deleteTarget) return;
    setModalSaving(true);
    try {
      await apiRequest(`/api/complaints/${deleteTarget.complaint_id}`, {
        method: 'DELETE',
        token,
      });
      const removedId = deleteTarget.complaint_id;
      setDeleteTarget(null);
      if (detailComplaint?.complaint_id === removedId) {
        setDetailComplaint(null);
      }
      await fetchList();
      onDataChanged(`Deleted complaint ${removedId}.`);
    } catch (err) {
      setErrorMsg(err instanceof ApiError ? err.message : 'Delete failed.');
      setDeleteTarget(null);
    } finally {
      setModalSaving(false);
    }
  }

  function resetFilters() {
    setKeyword('');
    setCategory('');
    setPriority('');
    setStatus('');
    setWarningLevel('');
    setSortBy('submission_date');
    setSortDir('desc');
    setPage(1);
  }

  const hasFilters = Boolean(keyword || category || priority || status || warningLevel);
  const staffOptions = Array.from(
    new Set([
      ...staffDirectory.filter((s) => s.role === 'Maintenance Staff').map((s) => s.full_name),
      'Marcus Vance',
      'Devon Brooks',
      'Priya Nair',
      'Elena Rostova',
      'Tariq Al-Mansoor',
    ])
  );

  return (
    <div className="space-y-5">
      {/* Search & Multi-Filter Bar */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-lg font-bold text-slate-900">
              Maintenance Records & Search
            </h1>
            <p className="text-xs text-slate-500">
              Search by complaint ID, student name, room, block, or description. Combine filters freely.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {user.role === 'Maintenance Staff' && (
              <div className="inline-flex items-center p-1 bg-slate-100 rounded-lg">
                <button
                  type="button"
                  onClick={() => {
                    setScope('assigned');
                    setPage(1);
                  }}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    scope === 'assigned'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  My Queue
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setScope('all');
                    setPage(1);
                  }}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    scope === 'all'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  All Records
                </button>
              </div>
            )}

            {hasFilters && (
              <button
                type="button"
                onClick={resetFilters}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Clear Filters</span>
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-6 gap-3">
          <div className="md:col-span-2 relative">
            <Search
              className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="text"
              value={keyword}
              onChange={(e) => {
                setKeyword(e.target.value);
                setPage(1);
              }}
              placeholder="Search ID, student, room, block, issue..."
              aria-label="Search maintenance records"
              className="w-full rounded-lg border border-slate-300 pl-9 pr-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-100"
            />
          </div>

          <select
            value={category}
            onChange={(e) => {
              setCategory(e.target.value);
              setPage(1);
            }}
            aria-label="Filter by category"
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 focus:border-indigo-600 focus:outline-none"
          >
            <option value="">All Categories</option>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <select
            value={priority}
            onChange={(e) => {
              setPriority(e.target.value);
              setPage(1);
            }}
            aria-label="Filter by priority"
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 focus:border-indigo-600 focus:outline-none"
          >
            <option value="">All Priorities</option>
            {PRIORITIES.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>

          <select
            value={status}
            onChange={(e) => {
              setStatus(e.target.value);
              setPage(1);
            }}
            aria-label="Filter by status"
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 focus:border-indigo-600 focus:outline-none"
          >
            <option value="">All Statuses</option>
            {STATUSES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>

          <select
            value={warningLevel}
            onChange={(e) => {
              setWarningLevel(e.target.value);
              setPage(1);
            }}
            aria-label="Filter by warning level"
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 focus:border-indigo-600 focus:outline-none"
          >
            <option value="">All Warning States</option>
            {WARNING_LEVELS.map((w) => (
              <option key={w} value={w}>
                {w}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-1 text-xs text-slate-600">
          <span className="tabular-nums font-medium">
            Showing {data ? data.items.length : 0} of {data ? data.total : 0} matching record(s)
          </span>
          <div className="flex items-center gap-2">
            <span>Sort by:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              aria-label="Sort field"
              className="rounded-md border border-slate-300 bg-white px-2.5 py-1 text-xs text-slate-800"
            >
              <option value="submission_date">Submission Date</option>
              <option value="expected_resolution_date">Expected Resolution Date</option>
              <option value="priority">Priority Severity</option>
              <option value="complaint_id">Complaint ID</option>
            </select>
            <button
              type="button"
              onClick={() => setSortDir((d) => (d === 'desc' ? 'asc' : 'desc'))}
              className="rounded-md border border-slate-300 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              {sortDir === 'desc' ? 'Newest / Highest' : 'Oldest / Lowest'}
            </button>
          </div>
        </div>
      </section>

      {errorMsg && (
        <div
          role="alert"
          className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
        >
          {errorMsg}
        </div>
      )}

      {/* Main Records Table */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-6 space-y-3">
            {Array.from({ length: 6 }).map((_, idx) => (
              <div key={idx} className="h-10 bg-slate-100 rounded animate-pulse" />
            ))}
          </div>
        ) : !data || data.items.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <p className="text-sm font-medium text-slate-700">
              No maintenance complaints match the active filters.
            </p>
            <p className="text-xs text-slate-500">
              Adjust your keyword or clear active filters to inspect all records.
            </p>
            {hasFilters && (
              <button
                type="button"
                onClick={resetFilters}
                className="inline-flex items-center gap-1.5 rounded-lg theme-btn-primary px-4 py-2 text-xs font-semibold cursor-pointer"
              >
                Reset All Filters
              </button>
            )}
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
                    <th className="py-3 px-4">Complaint ID</th>
                    <th className="py-3 px-4">Student & Location</th>
                    <th className="py-3 px-4">Category & Issue</th>
                    <th className="py-3 px-4">Priority</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Warning</th>
                    <th className="py-3 px-4">Due Date</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {data.items.map((item) => (
                    <tr key={item.complaint_id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-mono text-xs font-semibold text-indigo-700 tabular-nums whitespace-nowrap">
                        {item.complaint_id}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900">{item.student_name}</div>
                        <div className="text-xs text-slate-500">
                          {item.hostel_name} · {item.block_number}-{item.room_number}
                        </div>
                      </td>
                      <td className="py-3 px-4 max-w-xs">
                        <div className="text-xs font-medium text-slate-700">{item.category}</div>
                        <div className="text-xs text-slate-500 truncate">{item.description}</div>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span
                          className={`text-xs font-semibold ${
                            item.priority === 'Critical'
                              ? 'text-red-700'
                              : item.priority === 'High'
                                ? 'text-amber-700'
                                : item.priority === 'Medium'
                                  ? 'text-blue-700'
                                  : 'text-slate-600'
                          }`}
                        >
                          {item.priority}
                        </span>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1 text-xs font-medium ${
                            item.status === 'Completed'
                              ? 'text-emerald-700'
                              : item.status === 'In Progress'
                                ? 'text-blue-700'
                                : 'text-amber-700'
                          }`}
                        >
                          {item.status === 'Completed' ? (
                            <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
                          ) : (
                            <Clock className="h-3.5 w-3.5" aria-hidden="true" />
                          )}
                          <span>{item.status}</span>
                        </span>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1 text-xs font-semibold ${
                            item.warning_level === 'Critical'
                              ? 'text-red-700'
                              : item.warning_level === 'Overdue'
                                ? 'text-rose-600'
                                : item.warning_level === 'Attention Required'
                                  ? 'text-amber-700'
                                  : 'text-emerald-700'
                          }`}
                        >
                          {item.warning_level !== 'Normal' && (
                            <AlertCircle className="h-3.5 w-3.5" aria-hidden="true" />
                          )}
                          <span>{item.warning_level}</span>
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-xs text-slate-600 tabular-nums whitespace-nowrap">
                        {item.expected_resolution_date}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => openDetails(item.complaint_id)}
                            title="View Details"
                            className="p-1.5 rounded-md text-slate-600 hover:bg-slate-100 hover:text-slate-900 cursor-pointer"
                          >
                            <Eye className="h-4 w-4" aria-hidden="true" />
                          </button>
                          <button
                            type="button"
                            onClick={() => openStatusModal(item)}
                            className="px-2.5 py-1 rounded-md text-xs font-medium text-indigo-700 hover:bg-indigo-50 cursor-pointer"
                          >
                            Update Status
                          </button>
                          {user.role === 'Administrator' && (
                            <>
                              <button
                                type="button"
                                onClick={() => openEditModal(item)}
                                title="Edit Complaint"
                                className="p-1.5 rounded-md text-slate-600 hover:bg-slate-100 hover:text-slate-900 cursor-pointer"
                              >
                                <Edit3 className="h-4 w-4" aria-hidden="true" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeleteTarget(item)}
                                title="Delete Complaint"
                                className="p-1.5 rounded-md text-red-600 hover:bg-red-50 cursor-pointer"
                              >
                                <Trash2 className="h-4 w-4" aria-hidden="true" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination Bar */}
            <div className="px-5 py-3.5 border-t border-slate-200 flex items-center justify-between text-xs text-slate-600">
              <span className="tabular-nums">
                Page {data.page} of {data.total_pages} ({data.total} total records)
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={data.page <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
                >
                  <ChevronLeft className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Previous</span>
                </button>
                <button
                  type="button"
                  disabled={data.page >= data.total_pages}
                  onClick={() => setPage((p) => Math.min(data.total_pages, p + 1))}
                  className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
                >
                  <span>Next</span>
                  <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
                </button>
              </div>
            </div>
          </>
        )}
      </section>

      {/* Complaint Details Modal */}
      {detailComplaint && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-950/45 flex items-center justify-center p-4"
        >
          <div className="bg-white border border-slate-200 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-5">
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 pb-4">
              <div>
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <span className="font-mono font-semibold text-indigo-700">
                    {detailComplaint.complaint_id}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{detailComplaint.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>Priority: {detailComplaint.priority}</span>
                </div>
                <h2 className="font-display text-lg font-bold text-slate-900 mt-1">
                  {detailComplaint.hostel_name} · Block {detailComplaint.block_number}, Room{' '}
                  {detailComplaint.room_number}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setDetailComplaint(null)}
                aria-label="Close details"
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <span className="text-slate-500 block">Student</span>
                <span className="font-medium text-slate-900">
                  {detailComplaint.student_name} ({detailComplaint.student_id})
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Current Status</span>
                <span className="font-semibold text-slate-900">{detailComplaint.status}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Warning Threshold</span>
                <span className="font-semibold text-slate-900">
                  {detailComplaint.warning_level}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Submitted Date</span>
                <span className="font-mono text-slate-900">{detailComplaint.submission_date}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Expected Resolution</span>
                <span className="font-mono text-slate-900">
                  {detailComplaint.expected_resolution_date}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Assigned Staff</span>
                <span className="font-medium text-slate-900">
                  {detailComplaint.assigned_staff || 'Unassigned'}
                </span>
              </div>
            </div>

            <div className="space-y-1.5">
              <span className="text-xs font-medium text-slate-500 block">Problem Description</span>
              <p className="text-sm text-slate-800 leading-relaxed bg-slate-50 border border-slate-200 rounded-lg p-3.5">
                {detailComplaint.description}
              </p>
            </div>

            {detailComplaint.resolution_notes && (
              <div className="space-y-1.5">
                <span className="text-xs font-medium text-slate-500 block">Resolution Notes</span>
                <p className="text-sm text-slate-800 bg-emerald-50/60 border border-emerald-200 rounded-lg p-3.5">
                  {detailComplaint.resolution_notes}
                </p>
              </div>
            )}

            {detailComplaint.history && detailComplaint.history.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-slate-200">
                <h3 className="text-xs font-semibold text-slate-700">Status Change Timeline</h3>
                <div className="space-y-2">
                  {detailComplaint.history.map((h) => (
                    <div
                      key={h.id}
                      className="flex items-start justify-between gap-4 text-xs bg-slate-50 rounded-lg px-3 py-2"
                    >
                      <div>
                        <span className="font-semibold text-slate-900">
                          {h.old_status ? `${h.old_status} → ${h.new_status}` : h.new_status}
                        </span>
                        <span className="text-slate-500"> · by {h.changed_by}</span>
                        {h.notes && <p className="text-slate-600 mt-0.5">{h.notes}</p>}
                      </div>
                      <span className="font-mono text-slate-400 shrink-0 tabular-nums">
                        {h.changed_at}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => openStatusModal(detailComplaint)}
                className="rounded-lg theme-btn-primary px-4 py-2 text-xs font-semibold cursor-pointer"
              >
                Update Status / Assign
              </button>
              <button
                type="button"
                onClick={() => setDetailComplaint(null)}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Update Status Modal */}
      {statusModalItem && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-950/45 flex items-center justify-center p-4"
        >
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-base font-bold text-slate-900">
                Update Status · {statusModalItem.complaint_id}
              </h2>
              <button
                type="button"
                onClick={() => setStatusModalItem(null)}
                aria-label="Close status modal"
                className="p-1 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {modalError && (
              <div className="mb-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
                {modalError}
              </div>
            )}

            <form onSubmit={handleStatusSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Workflow Status
                </label>
                <select
                  value={nextStatus}
                  onChange={(e) =>
                    setNextStatus(e.target.value as 'Pending' | 'In Progress' | 'Completed')
                  }
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900"
                >
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Assigned Maintenance Staff
                </label>
                <select
                  value={nextStaff}
                  onChange={(e) => setNextStaff(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900"
                >
                  <option value="">Unassigned</option>
                  {staffOptions.map((name) => (
                    <option key={name} value={name}>
                      {name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Progress / Resolution Notes
                </label>
                <textarea
                  rows={3}
                  value={nextNotes}
                  onChange={(e) => setNextNotes(e.target.value)}
                  placeholder="Describe repair parts used, diagnostics, or next steps..."
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setStatusModalItem(null)}
                  className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={modalSaving}
                  className="rounded-lg theme-btn-primary px-4 py-2 text-xs font-semibold disabled:opacity-60 cursor-pointer"
                >
                  {modalSaving ? 'Saving...' : 'Save Status Update'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Admin Full Edit Modal */}
      {editModalItem && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-950/45 flex items-center justify-center p-4"
        >
          <div className="bg-white border border-slate-200 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-base font-bold text-slate-900">
                Edit Record · {editModalItem.complaint_id}
              </h2>
              <button
                type="button"
                onClick={() => setEditModalItem(null)}
                aria-label="Close edit modal"
                className="p-1 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {modalError && (
              <div className="mb-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
                {modalError}
              </div>
            )}

            <form onSubmit={handleEditSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Student Name
                  </label>
                  <input
                    type="text"
                    value={editForm.student_name || ''}
                    onChange={(e) => setEditForm({ ...editForm, student_name: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Student ID
                  </label>
                  <input
                    type="text"
                    value={editForm.student_id || ''}
                    onChange={(e) => setEditForm({ ...editForm, student_id: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Hostel Name
                  </label>
                  <select
                    value={editForm.hostel_name || ''}
                    onChange={(e) => setEditForm({ ...editForm, hostel_name: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
                  >
                    {HOSTEL_OPTIONS.map((h) => (
                      <option key={h} value={h}>
                        {h}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Block</label>
                    <input
                      type="text"
                      value={editForm.block_number || ''}
                      onChange={(e) => setEditForm({ ...editForm, block_number: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Room</label>
                    <input
                      type="text"
                      value={editForm.room_number || ''}
                      onChange={(e) => setEditForm({ ...editForm, room_number: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                      required
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Category</label>
                  <select
                    value={editForm.category || ''}
                    onChange={(e) => setEditForm({ ...editForm, category: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Priority</label>
                  <select
                    value={editForm.priority || ''}
                    onChange={(e) => setEditForm({ ...editForm, priority: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
                  >
                    {PRIORITIES.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Submission Date
                  </label>
                  <input
                    type="date"
                    value={editForm.submission_date || ''}
                    onChange={(e) => setEditForm({ ...editForm, submission_date: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Expected Resolution Date
                  </label>
                  <input
                    type="date"
                    value={editForm.expected_resolution_date || ''}
                    onChange={(e) =>
                      setEditForm({ ...editForm, expected_resolution_date: e.target.value })
                    }
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Problem Description
                </label>
                <textarea
                  rows={3}
                  value={editForm.description || ''}
                  onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditModalItem(null)}
                  className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={modalSaving}
                  className="rounded-lg theme-btn-primary px-4 py-2 text-xs font-semibold disabled:opacity-60 cursor-pointer"
                >
                  {modalSaving ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-950/45 flex items-center justify-center p-4"
        >
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 space-y-4">
            <h2 className="font-display text-base font-bold text-slate-900">
              Confirm Record Deletion
            </h2>
            <p className="text-sm text-slate-600">
              Are you sure you want to permanently delete{' '}
              <span className="font-mono font-semibold text-slate-900">
                {deleteTarget.complaint_id}
              </span>{' '}
              ({deleteTarget.hostel_name} {deleteTarget.room_number})? This action is recorded in
              the audit trail and cannot be undone.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={modalSaving}
                onClick={handleDeleteConfirm}
                className="rounded-lg bg-red-600 px-4 py-2 text-xs font-semibold text-white hover:bg-red-700 disabled:opacity-60 cursor-pointer"
              >
                {modalSaving ? 'Deleting...' : 'Delete Complaint'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
