"""Analytics and executive summary calculations from SQLite complaint records."""

import math
from collections import defaultdict
from datetime import date, datetime
from pathlib import Path
from typing import Any

from backend.database import get_connection
from backend.validation import parse_iso_date
from backend.warning_system import enrich_records_with_warnings
from config import ALLOWED_CATEGORIES, ALLOWED_PRIORITIES, ALLOWED_STATUSES


def compute_analytics(
    *,
    start_date: str = "",
    end_date: str = "",
    hostel_name: str = "",
    reference_date: date | None = None,
    db_path: Path | None = None,
) -> dict[str, Any]:
    clauses: list[str] = []
    params: list[Any] = []
    if start_date:
        clauses.append("submission_date >= ?")
        params.append(start_date)
    if end_date:
        clauses.append("submission_date <= ?")
        params.append(end_date)
    if hostel_name:
        clauses.append("hostel_name = ?")
        params.append(hostel_name)

    where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    conn = get_connection(db_path)
    try:
        rows = conn.execute(
            f"SELECT * FROM complaints {where_sql} ORDER BY submission_date ASC",
            tuple(params),
        ).fetchall()
    finally:
        conn.close()

    records = enrich_records_with_warnings([dict(r) for r in rows], reference_date=reference_date)
    total = len(records)

    status_counts = {s: 0 for s in ALLOWED_STATUSES}
    category_counts = {c: 0 for c in ALLOWED_CATEGORIES}
    priority_counts = {p: 0 for p in ALLOWED_PRIORITIES}
    warning_counts = {"Normal": 0, "Attention Required": 0, "Overdue": 0, "Critical": 0}
    monthly_counts: dict[str, dict[str, int]] = defaultdict(
        lambda: {"total": 0, "completed": 0, "pending": 0, "in_progress": 0}
    )
    hostel_counts: dict[str, int] = defaultdict(int)
    resolution_days: list[float] = []
    overdue_total = 0

    for rec in records:
        status = rec["status"]
        category = rec["category"]
        priority = rec["priority"]
        w_level = rec["warning_level"]

        status_counts[status] = status_counts.get(status, 0) + 1
        category_counts[category] = category_counts.get(category, 0) + 1
        priority_counts[priority] = priority_counts.get(priority, 0) + 1
        warning_counts[w_level] = warning_counts.get(w_level, 0) + 1
        hostel_counts[rec["hostel_name"]] += 1

        if w_level in ("Overdue", "Critical") and status != "Completed":
            # Count explicitly overdue items accurately
            exp_dt = parse_iso_date(rec.get("expected_resolution_date", ""))
            today = reference_date or date.today()
            if exp_dt and exp_dt.date() < today:
                overdue_total += 1

        month_key = rec["submission_date"][:7] if len(rec["submission_date"]) >= 7 else "Unknown"
        monthly_counts[month_key]["total"] += 1
        if status == "Completed":
            monthly_counts[month_key]["completed"] += 1
        elif status == "In Progress":
            monthly_counts[month_key]["in_progress"] += 1
        else:
            monthly_counts[month_key]["pending"] += 1

        if status == "Completed":
            sub_dt = parse_iso_date(rec.get("submission_date", ""))
            comp_raw = rec.get("completed_at") or rec.get("updated_at") or ""
            comp_date_part = comp_raw[:10]
            comp_dt = parse_iso_date(comp_date_part)
            if sub_dt and comp_dt:
                diff = max(0.0, float((comp_dt - sub_dt).days))
                resolution_days.append(diff)

    avg_resolution_days = (
        round(math.fsum(resolution_days) / len(resolution_days), 2)
        if resolution_days
        else 0.0
    )
    completion_pct = round((status_counts["Completed"] / total) * 100.0, 1) if total > 0 else 0.0

    sorted_months = sorted(k for k in monthly_counts.keys() if k != "Unknown")
    monthly_trends = [
        {"month": m, **monthly_counts[m]} for m in sorted_months
    ]

    return {
        "total_complaints": total,
        "pending_complaints": status_counts["Pending"],
        "in_progress_complaints": status_counts["In Progress"],
        "completed_complaints": status_counts["Completed"],
        "overdue_complaints": overdue_total,
        "completion_percentage": completion_pct,
        "average_resolution_days": avg_resolution_days,
        "status_breakdown": status_counts,
        "category_breakdown": category_counts,
        "priority_breakdown": priority_counts,
        "warning_breakdown": warning_counts,
        "hostel_breakdown": dict(sorted(hostel_counts.items())),
        "monthly_trends": monthly_trends,
    }
