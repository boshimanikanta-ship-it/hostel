"""Threshold warning engine for overdue, critical, and anomalous maintenance records."""

from datetime import date, datetime
from typing import Any

from backend.validation import parse_iso_date


def evaluate_record_warning(
    record: dict[str, Any], reference_date: date | None = None
) -> tuple[str, list[str]]:
    """Calculate warning label and explicit reasons from actual record dates and values."""
    today = reference_date or date.today()
    status = record.get("status", "Pending")
    priority = record.get("priority", "Medium")
    sub_dt = parse_iso_date(record.get("submission_date", ""))
    exp_dt = parse_iso_date(record.get("expected_resolution_date", ""))

    reasons: list[str] = []

    if not sub_dt or not exp_dt:
        reasons.append("Invalid or missing date format")
        return "Attention Required", reasons

    if exp_dt < sub_dt:
        reasons.append("Expected date precedes submission date")
        return "Critical", reasons

    if status == "Completed":
        return "Normal", []

    sub_date = sub_dt.date()
    exp_date = exp_dt.date()
    days_overdue = (today - exp_date).days
    days_until_due = (exp_date - today).days
    pending_age = (today - sub_date).days

    if days_overdue > 3 or (priority == "Critical" and days_overdue > 0):
        reasons.append(f"Overdue by {days_overdue} days")
        if priority == "Critical":
            reasons.append("Critical priority")
        return "Critical", reasons

    if priority == "Critical":
        reasons.append("Critical priority")
        if days_until_due <= 1:
            reasons.append("Immediate deadline")
        return "Critical", reasons

    if days_overdue > 0:
        reasons.append(f"Overdue by {days_overdue} day{'s' if days_overdue != 1 else ''}")
        return "Overdue", reasons

    if days_until_due <= 2:
        if days_until_due == 0:
            reasons.append("Due today")
        else:
            reasons.append(f"Due in {days_until_due} day{'s' if days_until_due != 1 else ''}")

    if status == "Pending" and pending_age > 5:
        reasons.append(f"Pending for {pending_age} days")

    if priority == "High" and days_until_due <= 3 and "Due" not in " ".join(reasons):
        reasons.append("High priority approaching target")

    if reasons:
        return "Attention Required", reasons

    return "Normal", []


def enrich_records_with_warnings(
    records: list[dict[str, Any]], reference_date: date | None = None
) -> list[dict[str, Any]]:
    enriched: list[dict[str, Any]] = []
    for rec in records:
        level, reasons = evaluate_record_warning(rec, reference_date=reference_date)
        copy = dict(rec)
        copy["warning_level"] = level
        copy["warning_reasons"] = reasons
        enriched.append(copy)
    return enriched


def summarize_warnings(
    records: list[dict[str, Any]], reference_date: date | None = None
) -> dict[str, Any]:
    enriched = enrich_records_with_warnings(records, reference_date=reference_date)
    counts = {"Normal": 0, "Attention Required": 0, "Overdue": 0, "Critical": 0}
    flagged: list[dict[str, Any]] = []
    for rec in enriched:
        level = rec["warning_level"]
        counts[level] = counts.get(level, 0) + 1
        if level != "Normal":
            flagged.append(rec)
    priority_rank = {"Critical": 0, "Overdue": 1, "Attention Required": 2}
    flagged.sort(
        key=lambda r: (
            priority_rank.get(r["warning_level"], 9),
            r.get("expected_resolution_date", ""),
        )
    )
    return {"counts": counts, "flagged": flagged}
