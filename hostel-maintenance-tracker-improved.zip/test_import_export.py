"""Unit tests for CSV/JSON import, export, backup, restore, and error handling."""

import tempfile
import unittest
import json
import sqlite3
from pathlib import Path

from backend.database import init_db, seed_sample_data
from backend.import_export import (
    export_complaints_csv,
    export_complaints_json,
    import_csv_content,
    restore_json_backup,
)
from backend.reports import generate_report_bundle
from backend.complaint_service import list_complaints


class TestImportExport(unittest.TestCase):
    def setUp(self) -> None:
        self.tmpdir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.tmpdir.name) / "test_io.db"
        init_db(self.db_path)

    def tearDown(self) -> None:
        self.tmpdir.cleanup()

    def test_csv_import_and_duplicate_detection(self) -> None:
        csv_text = "\n".join(
            [
                "complaint_id,student_name,student_id,hostel_name,block_number,room_number,category,description,priority,submission_date,expected_resolution_date,status",
                "HMT-2026-9001,Test Student,STU-90001,North Wing Hall,A,A-101,Electrical,Ceiling light fixture flickering constantly.,Medium,2026-11-15,2026-11-20,Pending",
                "HMT-2026-9001,Duplicate Student,STU-90002,North Wing Hall,A,A-102,Plumbing,Pipe dripping under washbasin.,High,2026-11-15,2026-11-20,Pending",
                "HMT-2026-9002,Bad Row,STU-90003,North Wing Hall,A,!!BAD!!,InvalidCat,Short,Urgent,2026-11-20,2026-11-10,Pending",
            ]
        )
        res = import_csv_content(csv_text, db_path=self.db_path)
        self.assertEqual(res["total_processed"], 3)
        self.assertEqual(res["imported_count"], 1)
        self.assertEqual(res["rejected_count"], 2)

        # Re-importing same CSV detects DB duplicate
        res2 = import_csv_content(csv_text, db_path=self.db_path)
        self.assertEqual(res2["imported_count"], 0)
        self.assertEqual(res2["rejected_count"], 3)

    def test_corrupted_json_restore_and_missing_file(self) -> None:
        bad_json = restore_json_backup("{not-valid-json", db_path=self.db_path)
        self.assertFalse(bad_json["success"])
        self.assertIn("Corrupted", bad_json["error"])

        missing_res = seed_sample_data(
            db_path=self.db_path, sample_path=Path(self.tmpdir.name) / "missing.json"
        )
        self.assertEqual(missing_res["inserted"], 0)

    def test_json_restore_rebuilds_status_history_and_timestamps(self) -> None:
        payload = {
            "records": [{
                "complaint_id": "HMT-2026-9901",
                "student_name": "Test Student",
                "student_id": "STU-99001",
                "hostel_name": "North Wing Hall",
                "block_number": "A",
                "room_number": "A-101",
                "category": "Electrical",
                "description": "Ceiling light fixture flickering constantly.",
                "priority": "High",
                "submission_date": "2026-11-15",
                "expected_resolution_date": "2026-11-20",
                "status": "Completed",
            }]
        }
        result = restore_json_backup(json.dumps(payload), actor="restore_test", db_path=self.db_path)
        self.assertTrue(result["success"])
        self.assertEqual(result["restored_count"], 1)

        conn = sqlite3.connect(self.db_path)
        try:
            complaint = conn.execute(
                "SELECT in_progress_at, completed_at FROM complaints WHERE complaint_id = ?",
                ("HMT-2026-9901",),
            ).fetchone()
            history = conn.execute(
                "SELECT old_status, new_status, changed_by FROM status_history WHERE complaint_id = ?",
                ("HMT-2026-9901",),
            ).fetchone()
        finally:
            conn.close()
        self.assertIsNotNone(complaint[0])
        self.assertIsNotNone(complaint[1])
        self.assertEqual(history, (None, "Completed", "restore_test"))

    def test_exports_and_reports(self) -> None:
        seed_sample_data(db_path=self.db_path)
        records = list_complaints(per_page=100, db_path=self.db_path)["items"]
        csv_out = export_complaints_csv(records)
        json_out = export_complaints_json(records)
        self.assertIn("HMT-2026-0001", csv_out)
        self.assertIn("HMT-2026-0001", json_out)

        for fmt in ("csv", "json", "markdown", "txt"):
            content, _, fname = generate_report_bundle(fmt, db_path=self.db_path)
            self.assertTrue(len(content) > 50)
            self.assertTrue(fname.startswith("hostel_"))


if __name__ == "__main__":
    unittest.main()
