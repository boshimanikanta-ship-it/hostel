"""Interactive terminal interface (CLI) for Hostel Maintenance Tracker."""

import getpass
from datetime import date
from pathlib import Path

from backend.analytics import compute_analytics
from backend.complaint_service import (
    create_complaint,
    get_complaint_detail,
    list_complaints,
    update_complaint_status,
)
from backend.database import get_connection, init_db, seed_sample_data, verify_password
from backend.import_export import import_csv_content
from backend.reports import generate_report_bundle
from backend.validation import parse_iso_date
from backend.warning_system import summarize_warnings
from config import ALLOWED_CATEGORIES, ALLOWED_PRIORITIES, ALLOWED_STATUSES


def prompt_non_empty(label: str, default: str | None = None) -> str:
    while True:
        suffix = f" [{default}]" if default else ""
        raw = input(f"{label}{suffix}: ").strip()
        if not raw and default:
            return default
        if raw:
            return raw
        print("  ! Input cannot be blank. Please try again.")


def prompt_choice(label: str, choices: tuple[str, ...], default: str | None = None) -> str:
    print(f"\n{label}:")
    for idx, item in enumerate(choices, start=1):
        print(f"  {idx}. {item}")
    while True:
        suffix = f" [default: {default}]" if default else ""
        raw = input(f"Select option (1-{len(choices)} or name){suffix}: ").strip()
        if not raw and default:
            return default
        if raw.isdigit():
            pos = int(raw) - 1
            if 0 <= pos < len(choices):
                return choices[pos]
        for item in choices:
            if raw.lower() == item.lower():
                return item
        print(f"  ! Invalid choice. Enter a number 1-{len(choices)}.")


def prompt_date(label: str, default: str | None = None) -> str:
    while True:
        suffix = f" [{default}]" if default else ""
        raw = input(f"{label} (YYYY-MM-DD){suffix}: ").strip()
        if not raw and default:
            return default
        if parse_iso_date(raw):
            return raw
        print("  ! Invalid date format. Use YYYY-MM-DD.")


def print_complaints_table(records: list[dict]) -> None:
    if not records:
        print("\n  (No matching maintenance records found.)")
        return
    header = (
        f"{'ID':<14} | {'Student':<18} | {'Location':<18} | {'Category':<14} | "
        f"{'Priority':<8} | {'Status':<11} | {'Warning':<18} | {'Due Date':<10}"
    )
    print("\n" + header)
    print("-" * len(header))
    for rec in records:
        loc = f"{rec['hostel_name'][:10]} {rec['block_number']}-{rec['room_number']}"
        print(
            f"{rec['complaint_id']:<14} | {rec['student_name'][:18]:<18} | "
            f"{loc[:18]:<18} | {rec['category']:<14} | {rec['priority']:<8} | "
            f"{rec['status']:<11} | {rec['warning_level']:<18} | {rec['expected_resolution_date']:<10}"
        )


def cli_authenticate() -> str:
    conn = get_connection()
    try:
        user_count = conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"]
    finally:
        conn.close()

    if user_count == 0:
        print("\n[CLI Setup] No users provisioned yet. Operating in local maintenance CLI mode.")
        return "cli_operator"

    print("\n--- Staff Sign-In (press Enter to continue as local CLI operator if unconfigured) ---")
    username = input("Username: ").strip().lower()
    if not username:
        return "cli_operator"
    password = getpass.getpass("Password: ")
    conn = get_connection()
    try:
        user = conn.execute(
            "SELECT username, password_hash, is_active FROM users WHERE username = ?",
            (username,),
        ).fetchone()
    finally:
        conn.close()
    if user and user["is_active"] and verify_password(password, user["password_hash"]):
        print(f"Authenticated as {user['username']}.")
        return user["username"]
    print("Authentication failed. Continuing in read-only/local verification or retry.")
    return "cli_operator"


def handle_register(actor: str) -> None:
    print("\n=== Register New Maintenance Request ===")
    today_str = date.today().isoformat()
    payload = {
        "student_name": prompt_non_empty("Student Name"),
        "student_id": prompt_non_empty("Student ID"),
        "hostel_name": prompt_non_empty("Hostel Name", "North Wing Hall"),
        "block_number": prompt_non_empty("Block Number", "A"),
        "room_number": prompt_non_empty("Room Number"),
        "category": prompt_choice("Complaint Category", ALLOWED_CATEGORIES),
        "description": prompt_non_empty("Problem Description (min 10 chars)"),
        "priority": prompt_choice("Priority Level", ALLOWED_PRIORITIES, "Medium"),
        "submission_date": prompt_date("Submission Date", today_str),
        "expected_resolution_date": prompt_date("Expected Resolution Date"),
        "status": "Pending",
        "assigned_staff": input("Assigned Staff (optional): ").strip(),
    }
    created, errors = create_complaint(payload, actor=actor)
    if errors:
        print("\nValidation failed:")
        for field, msg in errors.items():
            print(f"  - {field}: {msg}")
        return
    print(f"\nRegistered successfully: {created['complaint_id']} (Status: {created['status']})")


def handle_view_all() -> None:
    page = 1
    while True:
        res = list_complaints(page=page, per_page=15)
        print(
            f"\n=== Maintenance Records (Page {res['page']}/{res['total_pages']}, Total: {res['total']}) ==="
        )
        print_complaints_table(res["items"])
        if res["total_pages"] <= 1:
            break
        cmd = input("\n[n] Next page, [p] Prev page, [Enter] Back to menu: ").strip().lower()
        if cmd == "n" and page < res["total_pages"]:
            page += 1
        elif cmd == "p" and page > 1:
            page -= 1
        else:
            break


def handle_search() -> None:
    print("\n=== Search Complaints ===")
    kw = input("Keyword (ID, student, room, block, description) [optional]: ").strip()
    cat = input(f"Category ({', '.join(ALLOWED_CATEGORIES)}) [optional]: ").strip()
    pri = input(f"Priority ({', '.join(ALLOWED_PRIORITIES)}) [optional]: ").strip()
    st = input(f"Status ({', '.join(ALLOWED_STATUSES)}) [optional]: ").strip()
    res = list_complaints(keyword=kw, category=cat, priority=pri, status=st, per_page=100)
    print(f"\nFound {res['total']} matching record(s):")
    print_complaints_table(res["items"])


def handle_status_update(actor: str) -> None:
    print("\n=== Update Complaint Status ===")
    cid = prompt_non_empty("Complaint ID (e.g. HMT-2026-0024)").upper()
    existing = get_complaint_detail(cid)
    if not existing:
        print(f"  ! Complaint '{cid}' not found.")
        return
    print(f"Current Status: {existing['status']} | Priority: {existing['priority']} | Room: {existing['room_number']}")
    new_status = prompt_choice("New Status", ALLOWED_STATUSES, existing["status"])
    staff = input(f"Assigned Staff [{existing.get('assigned_staff') or 'unassigned'}]: ").strip()
    notes = input("Resolution / Progress Notes (optional): ").strip()
    updated, errs = update_complaint_status(
        cid,
        new_status,
        assigned_staff=staff if staff else None,
        resolution_notes=notes if notes else None,
        actor=actor,
    )
    if errs:
        print(f"  ! Update error: {errs}")
        return
    print(f"Updated {updated['complaint_id']} -> {updated['status']} (Warning: {updated['warning_level']})")


def handle_executive_summary() -> None:
    summary = compute_analytics()
    all_items = list_complaints(per_page=500)["items"]
    warnings = summarize_warnings(all_items)

    print("\n=== Executive Maintenance Summary ===")
    print(f"  Total Complaints       : {summary['total_complaints']}")
    print(f"  Pending                : {summary['pending_complaints']}")
    print(f"  In Progress            : {summary['in_progress_complaints']}")
    print(f"  Completed              : {summary['completed_complaints']} ({summary['completion_percentage']}%)")
    print(f"  Overdue                : {summary['overdue_complaints']}")
    print(f"  Avg Resolution Time    : {summary['average_resolution_days']} days")
    print("\n  Category Breakdown:")
    for k, v in summary["category_breakdown"].items():
        print(f"    - {k:<16}: {v}")
    print("\n  Warning Thresholds:")
    for k, v in warnings["counts"].items():
        print(f"    - {k:<18}: {v}")


def handle_export_reports() -> None:
    print("\n=== Export Maintenance Report ===")
    fmt = prompt_choice("Report Format", ("csv", "json", "markdown", "txt"), "markdown")
    _, _, fname = generate_report_bundle(fmt, save_to_disk=True)
    print(f"Report saved to exports/{fname}")


def handle_import_csv(actor: str) -> None:
    print("\n=== Import CSV Dataset ===")
    path_str = prompt_non_empty("Path to CSV file", "data/sample_complaints.csv")
    csv_path = Path(path_str)
    if not csv_path.exists():
        print(f"  ! File not found: {csv_path}")
        return
    try:
        csv_text = csv_path.read_text(encoding="utf-8")
    except OSError as exc:
        print(f"  ! Failed to read file: {exc}")
        return
    result = import_csv_content(csv_text, actor=actor)
    print(
        f"Processed {result['total_processed']} rows -> "
        f"Imported: {result['imported_count']}, Rejected: {result['rejected_count']}"
    )
    for err in result["errors"][:10]:
        print(f"  Row {err['row']} ({err['complaint_id']}): {err['error']}")


def main() -> None:
    init_db()
    seed_sample_data()
    actor = cli_authenticate()

    while True:
        print("\n==========================================")
        print("  HOSTEL MAINTENANCE TRACKER — CLI CONSOLE  ")
        print("==========================================")
        print("  1. Register New Complaint")
        print("  2. View All Complaints")
        print("  3. Search Complaints")
        print("  4. Update Complaint Status")
        print("  5. Generate Executive Summary")
        print("  6. Export Reports")
        print("  7. Import CSV Dataset")
        print("  8. Exit")
        choice = input("\nSelect an option (1-8): ").strip()

        if choice == "1":
            handle_register(actor)
        elif choice == "2":
            handle_view_all()
        elif choice == "3":
            handle_search()
        elif choice == "4":
            handle_status_update(actor)
        elif choice == "5":
            handle_executive_summary()
        elif choice == "6":
            handle_export_reports()
        elif choice == "7":
            handle_import_csv(actor)
        elif choice == "8":
            print("Exiting Hostel Maintenance Tracker CLI.")
            break
        else:
            print("  ! Please enter a valid option from 1 to 8.")


if __name__ == "__main__":
    main()
