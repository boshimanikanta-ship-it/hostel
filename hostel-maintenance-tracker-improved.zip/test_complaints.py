"""Unit tests for complaint CRUD, search, status transitions, and persistence."""

import tempfile
import unittest
from pathlib import Path

from backend.complaint_service import (
    create_complaint,
    delete_complaint,
    get_complaint_detail,
    list_complaints,
    update_complaint_status,
)
from backend.database import init_db, seed_sample_data


class TestComplaints(unittest.TestCase):
    def setUp(self) -> None:
        self.tmpdir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.tmpdir.name) / "test_hostel.db"
        init_db(self.db_path)

    def tearDown(self) -> None:
        self.tmpdir.cleanup()

    def test_register_search_update_delete_and_persistence(self) -> None:
        created, errs = create_complaint(
            {
                "student_name": "Maya Lin",
                "student_id": "STU-24028",
                "hostel_name": "South Courtyard",
                "block_number": "B",
                "room_number": "B-204",
                "category": "Plumbing",
                "description": "Cold-water pipe coupling dripping continuously onto tile.",
                "priority": "High",
                "submission_date": "2026-11-18",
                "expected_resolution_date": "2026-11-22",
            },
            actor="admin",
            db_path=self.db_path,
        )
        self.assertEqual(errs, {})
        self.assertIsNotNone(created)
        cid = created["complaint_id"]
        self.assertTrue(cid.startswith("HMT-2026-"))

        # Search by keyword + category
        search_res = list_complaints(
            keyword="Maya", category="Plumbing", db_path=self.db_path
        )
        self.assertEqual(search_res["total"], 1)

        # Status workflow: Pending -> In Progress -> Completed
        in_prog, errs2 = update_complaint_status(
            cid, "In Progress", assigned_staff="Devon Brooks", db_path=self.db_path
        )
        self.assertEqual(errs2, {})
        self.assertEqual(in_prog["status"], "In Progress")
        self.assertIsNotNone(in_prog["in_progress_at"])

        completed, errs3 = update_complaint_status(
            cid,
            "Completed",
            resolution_notes="Replaced compression gasket.",
            db_path=self.db_path,
        )
        self.assertEqual(errs3, {})
        self.assertEqual(completed["status"], "Completed")
        self.assertIsNotNone(completed["completed_at"])
        self.assertEqual(len(completed["history"]), 3)

        # Verify persistence across fresh DB lookup
        reloaded = get_complaint_detail(cid, db_path=self.db_path)
        self.assertEqual(reloaded["status"], "Completed")

        # Delete
        self.assertTrue(delete_complaint(cid, db_path=self.db_path))
        self.assertIsNone(get_complaint_detail(cid, db_path=self.db_path))

    def test_repeatable_sample_seeding(self) -> None:
        first = seed_sample_data(db_path=self.db_path)
        self.assertEqual(first["inserted"], 40)
        second = seed_sample_data(db_path=self.db_path)
        self.assertEqual(second["inserted"], 0)
        self.assertEqual(second["skipped"], 40)


if __name__ == "__main__":
    unittest.main()
