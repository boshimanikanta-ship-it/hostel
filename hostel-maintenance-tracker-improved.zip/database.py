"""SQLite database initialization, password hashing, and transaction helpers."""

import hashlib
import hmac
import json
import os
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from config import DATA_DIR, DB_PATH, EXPORTS_DIR, SAMPLE_JSON_PATH


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def hash_password(password: str, salt: str | None = None) -> str:
    """Hash password with scrypt in a format compatible with Node crypto.scryptSync."""
    chosen_salt = salt or secrets.token_hex(16)
    derived = hashlib.scrypt(
        password.encode("utf-8"),
        salt=chosen_salt.encode("utf-8"),
        n=16384,
        r=8,
        p=1,
        dklen=64,
    )
    return f"scrypt:{chosen_salt}:{derived.hex()}"


def verify_password(password: str, stored_hash: str) -> bool:
    if not stored_hash or not stored_hash.startswith("scrypt:"):
        return False
    parts = stored_hash.split(":", 2)
    if len(parts) != 3:
        return False
    _, salt, expected_hex = parts
    candidate = hash_password(password, salt=salt)
    return hmac.compare_digest(candidate, f"scrypt:{salt}:{expected_hex}")


def ensure_directories() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    EXPORTS_DIR.mkdir(parents=True, exist_ok=True)


def get_connection(db_path: Path | None = None) -> sqlite3.Connection:
    target = db_path or DB_PATH
    target.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(target), timeout=15.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    return conn


@contextmanager
def transaction(db_path: Path | None = None) -> Iterator[sqlite3.Connection]:
    conn = get_connection(db_path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db(db_path: Path | None = None) -> None:
    ensure_directories()
    with transaction(db_path) as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                full_name TEXT NOT NULL,
                email TEXT DEFAULT '',
                role TEXT NOT NULL CHECK(role IN ('Administrator', 'Maintenance Staff')),
                department TEXT DEFAULT 'General Maintenance',
                password_hash TEXT NOT NULL,
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS complaints (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                complaint_id TEXT UNIQUE NOT NULL,
                student_name TEXT NOT NULL,
                student_id TEXT NOT NULL,
                hostel_name TEXT NOT NULL,
                block_number TEXT NOT NULL,
                room_number TEXT NOT NULL,
                category TEXT NOT NULL CHECK(category IN (
                    'Electrical', 'Plumbing', 'Cleaning', 'Furniture',
                    'Internet/Wi-Fi', 'Bathroom', 'Water Supply', 'Other'
                )),
                description TEXT NOT NULL,
                priority TEXT NOT NULL CHECK(priority IN ('Low', 'Medium', 'High', 'Critical')),
                submission_date TEXT NOT NULL,
                expected_resolution_date TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending', 'In Progress', 'Completed')),
                assigned_staff TEXT DEFAULT '',
                resolution_notes TEXT DEFAULT '',
                in_progress_at TEXT DEFAULT NULL,
                completed_at TEXT DEFAULT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS status_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                complaint_id TEXT NOT NULL,
                old_status TEXT,
                new_status TEXT NOT NULL,
                changed_by TEXT NOT NULL,
                notes TEXT DEFAULT '',
                changed_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action TEXT NOT NULL,
                actor TEXT NOT NULL,
                target_id TEXT DEFAULT '',
                details TEXT DEFAULT '',
                created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_complaints_status ON complaints(status);
            CREATE INDEX IF NOT EXISTS idx_complaints_category ON complaints(category);
            CREATE INDEX IF NOT EXISTS idx_complaints_priority ON complaints(priority);
            CREATE INDEX IF NOT EXISTS idx_complaints_sub_date ON complaints(submission_date);
            """
        )

        # Optional automated provisioning if environment passcodes are supplied
        admin_pass = os.environ.get("HOSTEL_ADMIN_PASSCODE", "").strip()
        if admin_pass:
            existing_admin = conn.execute(
                "SELECT id FROM users WHERE username = ?", ("admin",)
            ).fetchone()
            pw_hash = hash_password(admin_pass)
            if existing_admin:
                conn.execute(
                    "UPDATE users SET password_hash = ?, is_active = 1 WHERE username = ?",
                    (pw_hash, "admin"),
                )
            else:
                conn.execute(
                    """
                    INSERT INTO users (username, full_name, email, role, department, password_hash, is_active, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, 1, ?)
                    """,
                    (
                        "admin",
                        "Dr. Elena Mercer",
                        "warden@campus-hostels.edu",
                        "Administrator",
                        "Campus Housing Administration",
                        pw_hash,
                        utc_now_iso(),
                    ),
                )

        staff_pass = os.environ.get("HOSTEL_STAFF_PASSCODE", "").strip()
        if staff_pass:
            existing_staff = conn.execute(
                "SELECT id FROM users WHERE username = ?", ("staff_marcus",)
            ).fetchone()
            pw_hash = hash_password(staff_pass)
            if existing_staff:
                conn.execute(
                    "UPDATE users SET password_hash = ?, is_active = 1 WHERE username = ?",
                    (pw_hash, "staff_marcus"),
                )
            else:
                conn.execute(
                    """
                    INSERT INTO users (username, full_name, email, role, department, password_hash, is_active, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, 1, ?)
                    """,
                    (
                        "staff_marcus",
                        "Marcus Vance",
                        "mvance@campus-hostels.edu",
                        "Maintenance Staff",
                        "Electrical & Plumbing",
                        pw_hash,
                        utc_now_iso(),
                    ),
                )


def seed_sample_data(
    db_path: Path | None = None, sample_path: Path | None = None, actor: str = "system"
) -> dict[str, int]:
    """Seed sample dataset idempotently without duplicating existing records."""
    source = sample_path or SAMPLE_JSON_PATH
    if not source.exists():
        return {"inserted": 0, "skipped": 0, "total": 0}

    with source.open("r", encoding="utf-8") as fh:
        records = json.load(fh)

    if not isinstance(records, list):
        raise ValueError("Sample JSON must contain an array of complaint records.")

    inserted = 0
    skipped = 0
    now = utc_now_iso()

    with transaction(db_path) as conn:
        for item in records:
            cid = item.get("complaint_id", "").strip()
            if not cid:
                skipped += 1
                continue
            exists = conn.execute(
                "SELECT 1 FROM complaints WHERE complaint_id = ?", (cid,)
            ).fetchone()
            if exists:
                skipped += 1
                continue
            conn.execute(
                """
                INSERT INTO complaints (
                    complaint_id, student_name, student_id, hostel_name,
                    block_number, room_number, category, description,
                    priority, submission_date, expected_resolution_date,
                    status, assigned_staff, resolution_notes,
                    in_progress_at, completed_at, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    cid,
                    item["student_name"],
                    item["student_id"],
                    item["hostel_name"],
                    item["block_number"],
                    item["room_number"],
                    item["category"],
                    item["description"],
                    item["priority"],
                    item["submission_date"],
                    item["expected_resolution_date"],
                    item.get("status", "Pending"),
                    item.get("assigned_staff", ""),
                    item.get("resolution_notes", ""),
                    item.get("in_progress_at"),
                    item.get("completed_at"),
                    item.get("created_at") or now,
                    item.get("updated_at") or now,
                ),
            )
            conn.execute(
                """
                INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes, changed_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    cid,
                    None,
                    item.get("status", "Pending"),
                    actor,
                    "Seeded from sample dataset",
                    item.get("created_at") or now,
                ),
            )
            inserted += 1

        if inserted > 0:
            conn.execute(
                "INSERT INTO audit_logs (action, actor, target_id, details, created_at) VALUES (?, ?, ?, ?, ?)",
                (
                    "SEED_SAMPLE_DATA",
                    actor,
                    "complaints",
                    f"Inserted {inserted} sample records ({skipped} skipped).",
                    now,
                ),
            )

    return {"inserted": inserted, "skipped": skipped, "total": len(records)}
